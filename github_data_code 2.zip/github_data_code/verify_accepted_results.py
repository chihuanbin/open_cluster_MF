from pathlib import Path
import json
r=Path(__file__).resolve().parent
d=json.loads((r/'historical/outputs/phase4/A2_REALDATA_RESULTS.json').read_text())
assert d['n_clusters']==156
assert f"{d['M1_gamma_median']:.4f}"=='0.0613'
assert [f"{x:.4f}" for x in d['M1_gamma_16_84']]==['0.0294','0.0913']
assert f"{d['P_gamma_gt_0']:.5f}"=='0.97469'
assert d['P_gamma_gt_0'] <= .975
assert f"{d['delta_ELPD_M1_minus_M0']:.3f}"=='-4.237'
print('Retained values verified; directional NOT MET; predictive NOT ADJUDICABLE; effect NOT EVALUABLE; conjunction DID NOT PASS.')
print('No posterior fitting, predictive evaluation or new analysis performed.')

s=json.loads((r/'accepted_results.json').read_text())
q=s['dissolution']
assert q['sample_funnel']==[163,162,157,156]
assert q['directional']=='NOT MET'
assert q['predictive']=='NOT ADJUDICABLE'
assert q['standardized_effect']=='NOT EVALUABLE'
assert q['conjunction']=='DID NOT PASS'
with (r/'accepted_diagnostics/realdata_visualization.csv').open() as f:
    import csv
    assert len(list(csv.DictReader(f)))==156
print('Final accepted classifications and 156-row plotting table verified.')
