#!/usr/bin/env python3
"""Importance-recycling ESS/Pareto diagnostics across hyperposterior draws."""
from __future__ import annotations
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'outputs/phase3'; sys.path.insert(0,str(ROOT/'scripts'))
from h2_5_decomposition import load_raw_chains, truncate_to_published  # noqa: E402
from hierarchical_mimo_summary import read_catalog  # noqa: E402
from full_hyperposterior import broken_mu  # noqa: E402
from psis_loo_models import psislw  # noqa: E402

def main():
    d=read_catalog(ROOT/'data/mimo_catalog/table3.dat',prime_only=True); chains=truncate_to_published(load_raw_chains(d,ROOT/'data/mimo_chains_prime'))
    dr=np.load(OUT/'posterior_joint_broken.npy'); dr=dr[::max(1,len(dr)//100)][:100]
    records=[]
    for j in range(len(chains)):
        ess=[]; ks=[]
        for p in dr:
            sig=np.exp(p[-1]); lw=chains[j]['logw']-0.5*((chains[j]['alpha']-broken_mu(chains[j]['tau'],p))/sig)**2-np.log(sig*np.sqrt(2*np.pi)); lw,k=psislw(lw); q=np.exp(lw); ess.append(1/np.sum(q*q)/len(q)); ks.append(k)
        records.append({'cluster_index':j,'cluster':str(d.iloc[j].cluster),'essfrac_q05':float(np.quantile(ess,.05)),'essfrac_median':float(np.median(ess)),'essfrac_q95':float(np.quantile(ess,.95)),'pareto_k_q05':float(np.nanquantile(ks,.05)),'pareto_k_median':float(np.nanmedian(ks)),'pareto_k_q95':float(np.nanquantile(ks,.95))})
    tab=pd.DataFrame(records); tab.to_csv(OUT/'importance_diagnostics_by_cluster.csv',index=False)
    result={'status':'PHASE3-IMPORTANCE-DIAGNOSTICS-COMPLETE','n_clusters':len(tab),'n_hyperdraws':len(dr),'chain_engine':'raw FITS logwt plus population density','median_of_cluster_median_essfrac':float(tab.essfrac_median.median()),'n_clusters_q05_essfrac_lt_0p1':int((tab.essfrac_q05<.1).sum()),'n_clusters_q05_essfrac_lt_0p2':int((tab.essfrac_q05<.2).sum()),'max_pareto_k_q95':float(tab.pareto_k_q95.max()),'n_clusters_pareto_k_q95_gt_0p7':int((tab.pareto_k_q95>.7).sum()),'note':'Raw-chain diagnostics; low-ESS clusters are flagged, not deleted.'}
    (OUT/'importance_diagnostics.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result,indent=2))
if __name__=='__main__': main()
