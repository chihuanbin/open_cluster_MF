#!/usr/bin/env python3
"""Cluster-level PSIS-LOO audit for Phase III hyperposteriors.

This implementation follows the standard Pareto-tail smoothing construction
with a generalized-Pareto fit to the largest importance ratios.  It operates
on saved hyperposterior draws and reports the cluster as the unit of
prediction.  It is intentionally independent of ArviZ so the audit is not
coupled to a user-level cache directory.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from scipy.stats import genpareto
from scipy.optimize import minimize
from scipy.special import logsumexp

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from h2_5_decomposition import load_raw_chains, truncate_to_published  # noqa: E402
from hierarchical_mimo_summary import read_catalog  # noqa: E402
from full_hyperposterior import AuditModel  # noqa: E402


def psislw(log_ratios):
    """Return smoothed normalized log weights and Pareto k."""
    lr = np.asarray(log_ratios, float)
    n = len(lr)
    if n < 20 or not np.all(np.isfinite(lr)):
        w = lr - logsumexp(lr); return w, np.nan
    lw = lr - np.max(lr)
    order = np.argsort(lw)
    # Standard adaptive tail size, bounded away from the bulk and endpoint.
    m = int(min(max(20, 3 * np.sqrt(n)), n // 2))
    tail_idx = order[-m:]
    threshold = lw[order[-m - 1]]
    excess = np.maximum(np.exp(lw[tail_idx] - threshold) - 1.0, 0.0)
    try:
        # Fast method-of-moments GPD fit.  Repeated maximum-likelihood GPD
        # fits are unnecessarily expensive for the 163 x hyperdraw audit.
        m1 = float(np.mean(excess)); v1 = float(np.var(excess, ddof=1))
        if m1 <= 0 or not np.isfinite(m1) or not np.isfinite(v1): raise ValueError
        k = 0.5 * (1.0 - m1 * m1 / v1) if v1 > m1 * m1 else -0.2
        k = float(np.clip(k, -0.5, 1.5)); scale = float(max(m1 * (1.0 - k), 1e-14))
        # Nearly constant ratios have a degenerate fitted scale.  They are
        # already Pareto-light; record k=0 and leave the ratios unchanged.
        if scale <= 1e-12 or np.max(excess) <= 1e-12:
            return lw - logsumexp(lw), 0.0
        probs = (np.arange(1, m + 1) - 0.5) / m
        # Invert the GPD CDF directly to avoid a distribution-fit overhead.
        if abs(k) < 1e-8: q = -scale * np.log1p(-probs)
        else: q = scale / k * ((1.0 - probs) ** (-k) - 1.0)
        sm = threshold + np.log1p(q)
        if not np.all(np.isfinite(sm)):
            # A negative-shape fit has a finite endpoint; ratios beyond that
            # endpoint are already lighter-tailed than the raw estimate.
            return lw - logsumexp(lw), float(k)
        sm = np.minimum(sm, np.max(lw))
        out = lw.copy(); out[tail_idx] = sm
        return out - logsumexp(out), float(k)
    except Exception:
        return lw - logsumexp(lw), np.nan


def psislw_exact(log_ratios):
    """Maximum-likelihood GPD version used for the final LOO table."""
    lr=np.asarray(log_ratios,float); n=len(lr)
    if n < 20 or not np.all(np.isfinite(lr)): return lr-logsumexp(lr), np.nan
    lw=lr-np.max(lr); order=np.argsort(lw); m=int(min(max(20,3*np.sqrt(n)),n//2)); idx=order[-m:]; threshold=lw[order[-m-1]]; excess=np.maximum(np.exp(lw[idx]-threshold)-1.,0.)
    if np.max(excess)<=1e-12: return lw-logsumexp(lw),0.0
    try:
        k,_loc,scale=genpareto.fit(excess,floc=0.0)
        if not np.isfinite(k) or not np.isfinite(scale) or scale<=1e-12: return lw-logsumexp(lw),0.0
        probs=(np.arange(1,m+1)-.5)/m; q=genpareto.ppf(probs,k,loc=0.0,scale=scale); sm=threshold+np.log1p(q)
        if not np.all(np.isfinite(sm)): return lw-logsumexp(lw),float(k)
        out=lw.copy(); out[idx]=np.minimum(sm,np.max(lw)); return out-logsumexp(out),float(k)
    except Exception: return lw-logsumexp(lw),np.nan


def pointwise_draws(d, chains, kind, model, draws, support=256, seed=20260906):
    obj = AuditModel(d, chains, model, kind, n_support=support, seed=seed)
    out = np.empty((len(draws), len(d)))
    for i, p in enumerate(draws): out[i] = obj.pointwise_loglike(p)
    return out


def main():
    root = ROOT; out = root / 'outputs/phase3'; n_use = 1500
    d = read_catalog(root / 'data/mimo_catalog/table3.dat', prime_only=True)
    chains = truncate_to_published(load_raw_chains(d, root / 'data/mimo_chains_prime'))
    rows=[]; lpd_rows=[]
    for kind in ('point','joint'):
        for model in ('constant','linear','broken'):
            path=out/f'posterior_{kind}_{model}.npy'
            # Use a contiguous post-burn-in block; the saved MCMC file is
            # already thinned and its walker-major layout makes striding by
            # four a poor diagnostic choice.
            draws=np.load(path); draws=draws[:n_use]
            ll=pointwise_draws(d,chains,kind,model,draws, support=256, seed=20260906)
            np.save(out/f'pointwise_loglik_{kind}_{model}.npy',ll)
            elpd=[]; ks=[]
            for j in range(ll.shape[1]):
                lw,k=psislw_exact(-ll[:,j]); elpd.append(float(logsumexp(ll[:,j]+lw))); ks.append(k)
            rows.append({'kind':kind,'model':model,'n_draws':len(draws),'elpd_loo':float(np.sum(elpd)),'se_approx':float(np.sqrt(len(elpd)*np.var(elpd,ddof=1))),'median_k':float(np.nanmedian(ks)),'max_k':float(np.nanmax(ks)),'n_k_gt_0p7':int(np.sum(np.asarray(ks)>0.7)),'n_k_gt_1':int(np.sum(np.asarray(ks)>1.0))})
            for j,(e,k) in enumerate(zip(elpd,ks)): lpd_rows.append({'kind':kind,'model':model,'cluster_index':j,'elpd_i':e,'pareto_k':k})
    sm=pd.DataFrame(rows); pp=pd.DataFrame(lpd_rows); sm.to_csv(out/'psis_loo_summary.csv',index=False); pp.to_csv(out/'psis_loo_pointwise.csv',index=False)
    # Paired model contrasts within each kind; SE uses cluster-level contrasts.
    contrasts=[]
    for kind in ('point','joint'):
        sub=pp[pp.kind==kind].pivot(index='cluster_index',columns='model',values='elpd_i')
        for a,b in [('linear','constant'),('broken','linear')]:
            z=sub[a]-sub[b]; contrasts.append({'kind':kind,'contrast':f'{a}-{b}','delta_elpd':float(z.sum()),'se_delta':float(np.sqrt(len(z)*np.var(z,ddof=1))),'z_score':float(z.sum()/np.sqrt(len(z)*np.var(z,ddof=1)))})
    pd.DataFrame(contrasts).to_csv(out/'psis_loo_contrasts.csv',index=False)
    (out/'psis_loo_provenance.json').write_text(json.dumps({'status':'PHASE3-PSIS-LOO-COMPLETE','unit':'cluster','n_clusters':len(d),'posterior_draws_used':n_use,'psislw':'adaptive generalized-Pareto tail smoothing; independent implementation','joint_support_points':256,'caveat':'joint likelihood uses fixed weighted joint support-point quadrature from the saved hyperposterior provenance'},indent=2)+'\n')
    print(sm.to_string(index=False)); print(pd.DataFrame(contrasts).to_string(index=False))


if __name__=='__main__': main()
