#!/usr/bin/env python3
"""Posterior-predictive summaries for Phase III models."""
from __future__ import annotations
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'outputs/phase3'; sys.path.insert(0,str(ROOT/'scripts'))
from hierarchical_mimo_summary import read_catalog  # noqa: E402
from h2_5_decomposition import load_raw_chains  # noqa: E402
from full_hyperposterior import broken_mu  # noqa: E402

def main():
    d=read_catalog(ROOT/'data/mimo_catalog/table3.dat',prime_only=True); tau=d.logage50.to_numpy(float); y=d.alpha50.to_numpy(float)
    rows=[]; rng=np.random.default_rng(20260906)
    for kind in ('point','joint'):
        for model in ('constant','linear','broken'):
            dr=np.load(OUT/f'posterior_{kind}_{model}.npy'); dr=dr[::max(1,len(dr)//2000)][:2000]; rep=[]
            for p in dr:
                if model=='constant': mu=np.full(len(tau),p[0])
                elif model=='linear': mu=p[0]+p[1]*(tau-8.5)
                else: mu=broken_mu(tau,p)
                rep.append(mu+rng.normal(0,np.exp(p[-1]),len(tau)))
            rep=np.asarray(rep); young=tau<8.4771; old=tau>9.2; mid=(tau>=8.6)&(tau<=9.2)
            stats={'kind':kind,'model':model,'obs_young_mean':float(y[young].mean()),'rep_young_mean':float(rep[:,young].mean()),'obs_young_sd':float(y[young].std(ddof=1)),'rep_young_sd':float(rep[:,young].std(axis=1).mean()),'obs_old_mean':float(y[old].mean()),'rep_old_mean':float(rep[:,old].mean()),'obs_mid_mean':float(y[mid].mean()),'rep_mid_mean':float(rep[:,mid].mean()),'obs_min':float(y.min()),'rep_min_q05':float(np.quantile(rep.min(axis=1),.05)),'obs_max':float(y.max()),'rep_max_q95':float(np.quantile(rep.max(axis=1),.95))}
            rows.append(stats)
    pd.DataFrame(rows).to_csv(OUT/'ppc_summary.csv',index=False)
    (OUT/'ppc_provenance.json').write_text(json.dumps({'status':'PHASE3-PPC-COMPLETE','n_rep_draws':2000,'young_definition':'logAge<8.4771 (300 Myr)','mid_definition':'8.6<=logAge<=9.2','old_definition':'logAge>9.2'},indent=2)+'\n')
    print(pd.DataFrame(rows).to_string(index=False))
if __name__=='__main__': main()
