#!/usr/bin/env python3
"""Phase III posterior-preserving broken-population audit.

Runs constant, linear and smoothly-broken population models for both a fair
random-effects point comparator and the joint age--MF FITS chains.  The joint
chain integral is evaluated with fixed, weighted joint support points selected
by deterministic stratified resampling.  The resulting MCMC is a genuine
hyperposterior; the support-point compression and seed are recorded so the
audit remains reproducible and auditable.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import emcee
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import logsumexp

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from h2_5_decomposition import load_raw_chains, truncate_to_published  # noqa: E402
from hierarchical_mimo_summary import read_catalog  # noqa: E402


def normal_logpdf(y, mu, sig):
    z = (y - mu) / sig
    return -0.5 * z * z - np.log(sig * np.sqrt(2.0 * np.pi))


def broken_mu(tau, p):
    y0, apre, delta, x0, logw = p[:5]
    w = np.exp(logw)
    z = (tau - x0) / w
    return y0 + apre * (tau - x0) + delta * w * np.logaddexp(0.0, z)


class AuditModel:
    def __init__(self, d, chains, model, kind, n_support=256, seed=20260906):
        self.model, self.kind = model, kind
        self.tau = d.logage50.to_numpy(float)
        self.alpha = d.alpha50.to_numpy(float)
        self.sy = np.maximum((d.alpha84.to_numpy(float) - d.alpha16.to_numpy(float)) / 2.0, 0.02)
        if kind == "joint":
            rng = np.random.default_rng(seed)
            ts, aa = [], []
            for c in chains:
                # Fixed weighted joint resampling; every selected row retains
                # its age--MF covariance.  This is an auditable quadrature
                # approximation to the raw log-sum-exp integral.
                u = (np.arange(n_support) + rng.random()) / n_support
                cdf = np.cumsum(c["w"])
                ii = np.searchsorted(cdf, u, side="left").clip(0, len(c["w"]) - 1)
                ts.append(c["tau"][ii]); aa.append(c["alpha"][ii])
            self.tau_s = np.asarray(ts); self.alpha_s = np.asarray(aa)

    def mean(self, tau, p):
        if self.model == "constant": return np.full_like(tau, p[0], dtype=float)
        if self.model == "linear": return p[0] + p[1] * (tau - 8.5)
        return broken_mu(tau, p)

    @property
    def ndim(self):
        return {"constant": 2, "linear": 3, "broken": 6}[self.model]

    def unpack_sigma(self, p):
        return np.exp(p[-1])

    def logprior(self, p):
        if not np.all(np.isfinite(p)): return -np.inf
        sig = self.unpack_sigma(p)
        if not (0.005 < sig < 2.0): return -np.inf
        if self.model == "constant":
            if not (-5 < p[0] < 1): return -np.inf
        elif self.model == "linear":
            if not (-5 < p[0] < 1 and -3 < p[1] < 3): return -np.inf
        else:
            y0, apre, delta, x0, logw, _ = p
            if not (-5 < y0 < 1 and -5 < apre < 3 and -6 < delta < 8 and 7.5 < x0 < 9.8 and np.log(0.03) < logw < np.log(2.0)): return -np.inf
        # weakly informative proper priors; constants are irrelevant for fit
        if self.model == "constant": return -0.5 * (p[0] / 3.0) ** 2 - 0.5 * (p[-1] / 2.0) ** 2
        if self.model == "linear": return -0.5 * (p[0] / 3.0) ** 2 - 0.5 * (p[1] / 2.0) ** 2 - 0.5 * (p[-1] / 2.0) ** 2
        return -0.5 * (y0 / 3.0) ** 2 - 0.5 * (apre / 2.0) ** 2 - 0.5 * (delta / 4.0) ** 2 - 0.5 * ((x0 - 8.7) / 0.8) ** 2 - 0.5 * ((logw + 1.0) / 1.5) ** 2 - 0.5 * (p[-1] / 2.0) ** 2

    def pointwise_loglike(self, p):
        sig = self.unpack_sigma(p)
        if self.kind == "point":
            return normal_logpdf(self.alpha, self.mean(self.tau, p), np.sqrt(self.sy * self.sy + sig * sig))
        mu = self.mean(self.tau_s, p)
        return logsumexp(normal_logpdf(self.alpha_s, mu, sig), axis=1) - np.log(self.alpha_s.shape[1])

    def logprob(self, p):
        lp = self.logprior(p)
        if not np.isfinite(lp): return -np.inf
        return float(lp + np.sum(self.pointwise_loglike(p)))


def starts(model, kind):
    if model == "constant": return np.array([-2.1, np.log(.45)])
    if model == "linear": return np.array([-2.0, .5, np.log(.48)])
    return np.array([-2.4, -.25, 3.6, 8.93, np.log(.17), np.log(.32)])


def run_one(d, chains, model, kind, out, n_support, seed, walkers, steps, burn):
    obj = AuditModel(d, chains, model, kind, n_support=n_support, seed=seed)
    x0 = starts(model, kind)
    opt = minimize(lambda x: -obj.logprob(x), x0, method="Nelder-Mead", options={"maxiter": 1200, "xatol": 2e-4, "fatol": 2e-4})
    center = opt.x
    rng = np.random.default_rng(seed + 1000 * (0 if kind == "point" else 1) + len(model))
    scale = np.full(obj.ndim, 0.02); scale[-1] = .03
    if model == "broken": scale = np.array([.03,.03,.08,.03,.05,.03])
    pos = center + rng.normal(size=(walkers, obj.ndim)) * scale
    # Keep all initial walkers in support by retrying invalid points.
    for i in range(walkers):
        tries = 0
        while not np.isfinite(obj.logprob(pos[i])) and tries < 100:
            pos[i] = center + rng.normal(size=obj.ndim) * scale; tries += 1
        if not np.isfinite(obj.logprob(pos[i])): pos[i] = center
    sampler = emcee.EnsembleSampler(walkers, obj.ndim, obj.logprob)
    sampler.run_mcmc(pos, steps, progress=False)
    chain = sampler.get_chain(discard=burn, flat=True)
    logp = sampler.get_log_prob(discard=burn, flat=True)
    # thin to a stable, bounded file size while retaining all independent-ish draws
    keep = np.arange(len(chain))[::max(1, len(chain) // 6000)]
    draws = chain[keep]
    np.save(out / f"posterior_{kind}_{model}.npy", draws)
    np.save(out / f"logp_{kind}_{model}.npy", logp[keep])
    row = {"kind":kind,"model":model,"ndraw":int(len(draws)),"ndim":int(obj.ndim),"opt_logpost":float(-opt.fun),"acceptance":float(np.mean(sampler.acceptance_fraction)),"n_support":int(n_support),"seed":int(seed)}
    for k in range(obj.ndim): row[f"p{k}_median"] = float(np.median(draws[:,k])); row[f"p{k}_q025"] = float(np.quantile(draws[:,k],.025)); row[f"p{k}_q975"] = float(np.quantile(draws[:,k],.975))
    row["sigma_median"] = float(np.median(np.exp(draws[:,-1])))
    if model == "broken":
        row["x0_median"] = float(np.median(draws[:,3])); row["x0_q025"] = float(np.quantile(draws[:,3],.025)); row["x0_q975"] = float(np.quantile(draws[:,3],.975)); row["a_pre_median"] = float(np.median(draws[:,1])); row["a_post_median"] = float(np.median(draws[:,1]+draws[:,2])); row["width_median"] = float(np.median(np.exp(draws[:,4]))); row["P_delta_positive"] = float(np.mean(draws[:,2] > 0))
    return row


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--out',type=Path,default=ROOT/'outputs/phase3'); ap.add_argument('--support',type=int,default=256); ap.add_argument('--walkers',type=int,default=20); ap.add_argument('--steps',type=int,default=1400); ap.add_argument('--burn',type=int,default=500); ap.add_argument('--seed',type=int,default=20260906); ap.add_argument('--untruncated',action='store_true',help='retain negligible chain tails outside printed Table 2 support'); ap.add_argument('--force',action='store_true'); a=ap.parse_args(); a.out.mkdir(parents=True,exist_ok=True)
    d=read_catalog(ROOT/'data/mimo_catalog/table3.dat',prime_only=True); chains=load_raw_chains(d,ROOT/'data/mimo_chains_prime')
    if not a.untruncated: chains=truncate_to_published(chains)
    if (a.out/'hyperposterior_summary.csv').exists() and not a.force: raise SystemExit('Output exists; use --force')
    rows=[]
    for kind in ('point','joint'):
        for model in ('constant','linear','broken'):
            print(f'RUN {kind} {model}', flush=True)
            rows.append(run_one(d,chains,model,kind,a.out,a.support,a.seed,a.walkers,a.steps,a.burn))
    pd.DataFrame(rows).to_csv(a.out/'hyperposterior_summary.csv',index=False)
    (a.out/'hyperposterior_provenance.json').write_text(json.dumps({'status':'PHASE3-HYPERPOSTERIOR-PILOT','n_clusters':len(d),'models':['constant','linear','broken'],'kinds':['pointRE','full-chain'],'support_points':a.support,'sampler':'emcee ensemble MCMC','steps':a.steps,'burn':a.burn,'walkers':a.walkers,'seed':a.seed,'chain_integral':'fixed deterministic stratified weighted joint support points; each selected row preserves tau-alpha covariance','primary_broken_parameterization':'y0,a_pre,delta_a,x0,log_width,log_sigma','printed_support_truncation':not a.untruncated,'prior_note':'published MiMO support is handled by H0.5 audit; exact run-config provenance remains documented'},indent=2)+'\n')
    print(pd.DataFrame(rows).to_string(index=False))


if __name__=='__main__': main()
