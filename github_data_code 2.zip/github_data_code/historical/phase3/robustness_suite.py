#!/usr/bin/env python3
"""Influence and subset robustness audit from the saved hyperposterior."""
from __future__ import annotations
import json
from pathlib import Path
import argparse
import sys
import numpy as np
import pandas as pd
from scipy.special import logsumexp

ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'outputs/phase3'

def weighted_quantile(x,w,q):
    o=np.argsort(x); x=x[o]; w=w[o]; return float(np.interp(q,np.cumsum(w),x))

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--all-draws',action='store_true'); a=ap.parse_args()
    dr_all=np.load(OUT/'posterior_joint_broken.npy'); dr=dr_all if a.all_draws else dr_all[:1500]
    ll_path=OUT/('pointwise_loglik_joint_broken_all.npy' if a.all_draws else 'pointwise_loglik_joint_broken.npy')
    if not ll_path.exists():
        sys.path.insert(0,str(ROOT/'scripts'))
        from h2_5_decomposition import load_raw_chains, truncate_to_published
        from hierarchical_mimo_summary import read_catalog
        from full_hyperposterior import AuditModel
        d0=read_catalog(ROOT/'data/mimo_catalog/table3.dat',prime_only=True); c0=truncate_to_published(load_raw_chains(d0,ROOT/'data/mimo_chains_prime'))
        obj=AuditModel(d0,c0,'broken','joint',n_support=256,seed=20260906); ll=np.empty((len(dr),len(d0)))
        for i,p in enumerate(dr): ll[i]=obj.pointwise_loglike(p)
        np.save(ll_path,ll)
    else: ll=np.load(ll_path)
    n=min(len(dr),len(ll)); dr=dr[:n]; ll=ll[:n]
    n=min(len(dr),len(ll)); dr=dr[:n]; ll=ll[:n]; x0=dr[:,3]
    base=float(np.median(x0)); rec=[]
    for j in range(ll.shape[1]):
        lw=-ll[:,j]; lw-=logsumexp(lw); q=np.exp(lw); rec.append({'cluster_index':j,'x0_loo_median':weighted_quantile(x0,q,.5),'delta_x0':weighted_quantile(x0,q,.5)-base,'max_loo_weight':float(q.max())})
    loo=pd.DataFrame(rec); loo.to_csv(OUT/'x0_influence_approx.csv',index=False)
    # Age-defined subset deletion using the same fixed full posterior draws.
    # This is a diagnostic, not a substitute for refitting the subset.
    tau=pd.read_csv(ROOT/'data/mimo_catalog/table3.dat',sep='\\s+',comment='#',header=None) if False else None
    # Recover ordering from the saved pointwise matrix and catalog parser.
    sys.path.insert(0,str(ROOT/'scripts'))
    from hierarchical_mimo_summary import read_catalog
    d=read_catalog(ROOT/'data/mimo_catalog/table3.dat',prime_only=True); ages=d.logage50.to_numpy(float)
    order=np.argsort(ages); groups={'youngest10':order[:max(1,int(.1*len(order)))],'oldest10':order[-max(1,int(.1*len(order))):]}
    subset=[]
    for name,idx in groups.items():
        lw=-ll[:,idx].sum(axis=1); lw-=logsumexp(lw); q=np.exp(lw); subset.append({'subset':name,'n_removed':len(idx),'x0_subset_median':weighted_quantile(x0,q,.5),'delta_x0':weighted_quantile(x0,q,.5)-base})
    pd.DataFrame(subset).to_csv(OUT/'x0_age_subset_influence.csv',index=False)
    result={'status':'PHASE3-ROBUSTNESS-COMPLETE-PILOT','base_x0_median':base,'max_abs_approx_loo_delta_x0':float(np.max(np.abs(loo.delta_x0))),'cluster_at_max_abs_delta':int(loo.iloc[np.argmax(np.abs(loo.delta_x0))].cluster_index),'youngest10_delta_x0':float(subset[0]['delta_x0']),'oldest10_delta_x0':float(subset[1]['delta_x0']),'note':'Influence is posterior reweighting from the full joint broken fit; targeted refits remain required for low-ESS clusters.'}
    (OUT/'robustness_summary.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result,indent=2))
if __name__=='__main__': main()
