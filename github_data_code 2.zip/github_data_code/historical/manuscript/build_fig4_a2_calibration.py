import csv
from pathlib import Path
import matplotlib.pyplot as plt

root = Path(__file__).resolve().parents[1]
src = root / "outputs/phase4/A2_FULL_LIKELIHOOD_POWER.csv"
out = root / "manuscript/tex/figures/fig4_a2_calibration.pdf"
rows = list(csv.DictReader(src.open()))
x = [float(r["gamma_star"]) for r in rows]
y = [float(r["combined_power"]) for r in rows]
fig, ax = plt.subplots(figsize=(5.2, 2.8))
ax.plot(x, y, "o-", color="#1f4e79", lw=1.8)
ax.axhline(0.8, color="#888", ls="--", lw=1, label="target power = 0.80")
ax.axvline(0.6, color="#b22222", ls=":", lw=1.2, label=r"target $\gamma^\star=0.6$")
ax.set(xlim=(-0.02, 1.02), ylim=(-0.02, 1.05), xlabel=r"standardized effect $\gamma^\star$", ylabel="combined detection fraction")
ax.set_title("Outcome-blind A2 calibration")
ax.legend(frameon=False, fontsize=8, loc="lower right")
fig.tight_layout()
fig.savefig(out)
fig.savefig(out.with_suffix(".png"), dpi=180)
plt.close(fig)
