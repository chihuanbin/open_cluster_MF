from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

root=Path(__file__).resolve().parents[1]
d=pd.read_csv(root/'outputs/phase4/clock_freeze_A.csv')
fig,ax=plt.subplots(1,2,figsize=(7.4,3.1))
for a,ycol,title,rho,med in [(ax[0],'tdiss_orbit_average_Myr_50','Orbit-average',0.9723,0.0133),(ax[1],'tdiss_bm03_apo_Myr_50','BM03 apocentre',0.9464,0.0382)]:
    x=d.tdiss_li_current_Myr_50.to_numpy(); y=d[ycol].to_numpy()
    a.scatter(x,y,s=10,alpha=.55,color='#275d8c'); lo=min(x.min(),y.min()); hi=max(x.max(),y.max()); a.plot([lo,hi],[lo,hi],color='#777',lw=.8,ls='--')
    a.set_xscale('log'); a.set_yscale('log'); a.set_xlabel(r'Li-current $t_{\rm diss}$ (Myr)'); a.set_ylabel(fr'{title} $t_{{\rm diss}}$ (Myr)'); a.text(0.04,0.96,fr'$\rho={rho:.4f}$\nmedian $|\Delta\log t|={med:.4f}$ dex',transform=a.transAxes,ha='left',va='top',fontsize=8,bbox=dict(facecolor='white',alpha=.8,edgecolor='none',pad=1.5))
fig.tight_layout(); fig.savefig(root/'manuscript/tex/figures/fig2_clock_validation.pdf'); fig.savefig(root/'manuscript/tex/figures/fig2_clock_validation.png',dpi=180); plt.close(fig)
