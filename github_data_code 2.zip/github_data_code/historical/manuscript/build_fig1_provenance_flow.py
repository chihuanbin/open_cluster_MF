from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

root = Path(__file__).resolve().parents[1]
out = root / 'manuscript/tex/figures/fig1_provenance_flow.pdf'
labels = [
    '163 MF-Prime', '162 HR24 matches', '157 orbit-quality',
    '156 CLOCK_FREEZE_A', 'Freeze B: age/logwt only',
    'A1: Dperp=0.297571 < 0.3000\nOutcome locked',
    'A2 synthetic calibration\nQ95=1.0245', 'Rule hash',
    'First alpha access\nM0/M1/M2', 'A2 PRIMARY FAIL'
]
fig, ax = plt.subplots(figsize=(5.4, 7.8))
ax.set_xlim(0, 1); ax.set_ylim(0, len(labels)); ax.axis('off')
for i, lab in enumerate(labels):
    y = len(labels)-i-0.82
    fc = '#e8eef4' if i < 5 else ('#f4e8e8' if i in (5,9) else '#eef2e8')
    box = FancyBboxPatch((0.12, y), 0.76, 0.55, boxstyle='round,pad=0.02',
                         facecolor=fc, edgecolor='#4a4a4a', linewidth=0.8)
    ax.add_patch(box); ax.text(0.5, y+0.275, lab, ha='center', va='center', fontsize=9)
    if i < len(labels)-1:
        ax.annotate('', xy=(0.5, y-0.16), xytext=(0.5, y),
                    arrowprops=dict(arrowstyle='-|>', color='#666', lw=0.8))
fig.tight_layout(); fig.savefig(out); fig.savefig(out.with_suffix('.png'), dpi=180); plt.close(fig)
