import json
from pathlib import Path
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

root=Path(__file__).resolve().parents[1]; out=root/'manuscript/tex/figures'; out.mkdir(exist_ok=True)
r=json.loads((root/'outputs/phase4/A2_REALDATA_RESULTS.json').read_text()); b=json.loads((root/'outputs/phase4/A2_REALDATA_CALIBRATION_ENGINE.json').read_text()); g=r['M1_gamma_median']; lo,hi=r['M1_gamma_16_84']; de=b['delta_ELPD_real_calibration_engine']; th=1.0245
mpl.rcParams.update({'font.family':'sans-serif','font.size':9,'pdf.fonttype':42,'svg.fonttype':'none'})
fig = plt.figure(figsize=(7.2,3.35))
gs = GridSpec(2, 3, height_ratios=[4.2, 1.0], hspace=.55, wspace=.45)
ax = [fig.add_subplot(gs[0,0]), fig.add_subplot(gs[0,1]), fig.add_subplot(gs[0,2])]

# A: coefficient and directional criterion are deliberately separated.
a=ax[0]
a.errorbar([0],[g],yerr=[[g-lo],[hi-g]],fmt='o',color='#275d8c',capsize=4,lw=1.2)
a.axhline(0,color='#777',lw=.8,ls='--')
a.set_ylabel(r'$\gamma_d$ ($\alpha$ units / predictor SD)')
a.set_xticks([0],['M1']); a.set_title('Directional effect')
a.text(.04,.95,r'$P(\gamma_d>0)=0.97469$',transform=a.transAxes,va='top',fontsize=8)
a.text(.04,.84,r'criterion $>0.975$',transform=a.transAxes,va='top',fontsize=8.5)
a.text(.04,.70,'FAIL',transform=a.transAxes,va='top',fontsize=9,color='#8f3030',weight='bold')
a.grid(axis='y',alpha=.2)

# B: observed decision statistic versus the frozen critical value.
a=ax[1]
a.axvline(0,color='#777',lw=.8,ls='--')
a.axvline(th,color='#555',lw=1.2,ls='--')
a.plot(de,0,'o',color='#275d8c',ms=7,zorder=3)
a.annotate('0.684',xy=(de,0),xytext=(de,-.22),ha='center',fontsize=8,color='#275d8c')
a.text(th,.92,'$Q_{0.95}=1.0245$',transform=a.get_xaxis_transform(),ha='right',va='top',fontsize=8.5)
a.set_xlim(-.18,1.30); a.set_ylim(-.5,1); a.set_yticks([])
a.set_xlabel(r'$\Delta$ELPD (calibration engine)'); a.set_title('Matched predictive test')
a.text(.04,.16,r'$0.684<1.0245$',transform=a.transAxes,fontsize=8)
a.text(.04,.04,'FAIL',transform=a.transAxes,fontsize=9,color='#8f3030',weight='bold')

# C: explicit status box, not a pseudo-data panel.
a=ax[2]; a.axis('off')
a.text(.5,.90,'Effect-size gate',ha='center',va='top',fontsize=9,weight='bold',transform=a.transAxes)
a.text(.5,.58,'NOT\nEVALUABLE',ha='center',va='center',fontsize=12,color='#555',weight='bold',transform=a.transAxes)
a.text(.5,.16,'real-data outcome scale\nnot retained',ha='center',va='center',fontsize=8.5,color='#555',transform=a.transAxes)

# Overall conjunction strip.
summary=fig.add_subplot(gs[1,:]); summary.axis('off')
summary.add_patch(plt.Rectangle((0.01,.12),.98,.76,facecolor='#f2f2f2',edgecolor='#777',lw=.8,transform=summary.transAxes))
summary.text(.5,.63,'A2 conjunction: DID NOT PASS',ha='center',va='center',fontsize=10,weight='bold',transform=summary.transAxes)
summary.text(.5,.30,'Directional: FAIL   ·   Predictive: FAIL   ·   Effect-size: NOT EVALUABLE',ha='center',va='center',fontsize=8.5,transform=summary.transAxes)
fig.subplots_adjust(left=.08,right=.98,bottom=.08,top=.93)
fig.savefig(out/'fig5_a2_realdata.pdf',bbox_inches='tight')
fig.savefig(out/'fig5_a2_realdata.svg',bbox_inches='tight')
fig.savefig(out/'fig5_a2_realdata.png',dpi=600,bbox_inches='tight')
fig.savefig(out/'fig5_a2_realdata.tiff',dpi=600,bbox_inches='tight')
plt.close(fig)
