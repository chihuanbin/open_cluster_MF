"""Reporting-only effect-scale closure figure; no refit or new inference."""
from pathlib import Path
import matplotlib as mpl
import matplotlib.pyplot as plt

mpl.rcParams.update({"font.family":"sans-serif", "font.size":8,
                     "axes.spines.top":False, "axes.spines.right":False,
                     "pdf.fonttype":42, "svg.fonttype":"none"})
root = Path(__file__).resolve().parents[1]
fig, ax = plt.subplots(1, 2, figsize=(7.1, 2.65), gridspec_kw={"width_ratios":[1.05,1.25]})

# Retained real-data reporting interval (not a reconstructed 95% interval).
a = ax[0]
a.errorbar([0], [0.0613433], yerr=[[0.0613433-0.0294393], [0.0912957-0.0613433]],
           fmt='o', color='#275d8c', ms=5, capsize=3, lw=1.2)
a.axhline(0, color='#777', lw=.8, ls='--')
a.set_xlim(-.65,.65); a.set_xticks([0]); a.set_xticklabels(['M1'])
a.set_ylabel(r'Native $\alpha$ units per predictor SD')
a.set_title('Retained real-data coefficient')
a.text(.04,.08,'median = 0.0613\n16--84% interval retained', transform=a.transAxes, fontsize=7,
       bbox=dict(facecolor='white', edgecolor='none', alpha=.85))

# Scale definitions and missing bridge information.
a = ax[1]
a.axis('off')
a.text(0.02, .90, 'Effect-scale closure status', fontsize=9, weight='bold', transform=a.transAxes)
rows = [
    ('Predictor scale in M1', 'unit SD'),
    ('Calibration outcome scatter', '1.0 SD'),
    ('Real-data outcome scale', 'native α'),
    ('Posterior draws retained', 'No'),
    ('γ* real recoverable', 'Not evaluable'),
]
for i,(k,v) in enumerate(rows):
    y=.72-i*.135
    a.text(.02,y,k,transform=a.transAxes,fontsize=7.8)
    a.text(.98,y,v,transform=a.transAxes,fontsize=7.8,ha='right',
           color='#9b2c2c' if 'No' in v or 'Not' in v else '#222')
    a.plot([.02,.98],[y-.035,y-.035],transform=a.transAxes,color='#dddddd',lw=.6)
a.text(.02,.04,'The outcome-standardized 0.30 gate is not compared\nwith the native coefficient.',
       transform=a.transAxes,fontsize=7.5,color='#9b2c2c')
fig.tight_layout(w_pad=2.0)
out = root/'manuscript/tex/figures/fig6_effect_scale_audit'
fig.savefig(str(out)+'.pdf', bbox_inches='tight')
fig.savefig(str(out)+'.svg', bbox_inches='tight')
fig.savefig(str(out)+'.png', dpi=600, bbox_inches='tight')
fig.savefig(str(out)+'.tiff', dpi=600, bbox_inches='tight')
plt.close(fig)
