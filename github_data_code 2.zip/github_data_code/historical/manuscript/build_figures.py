#!/usr/bin/env python3
"""Build compact, manuscript-ready audit figures from frozen Phase III outputs."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "manuscript" / "figures"
OUT.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({"font.size": 9, "axes.titlesize": 10, "figure.dpi": 150})

def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / f"{name}.png", dpi=300, bbox_inches="tight")
    fig.savefig(OUT / f"{name}.pdf", bbox_inches="tight")
    plt.close(fig)

def fig_weighting():
    d = pd.read_csv(ROOT / "outputs/h2_6_weighting_audit/weight_tempering_path.csv")
    fig, ax = plt.subplots(figsize=(5.2, 3.3))
    ax.plot(d["kappa"], d["beta1"], "o-", lw=1.8, ms=4, color="#275d8c")
    ax.axhline(0.198536, color="#b44", ls="--", lw=1, label="measurement-only IV")
    ax.axhline(0.513275, color="#333", ls=":", lw=1.2, label="random-effects point")
    ax.set(xlabel=r"weight tempering $\kappa$", ylabel=r"linear slope $\beta_1$",
           title="Linear slope is a weighting-dependent estimand")
    ax.legend(frameon=False, fontsize=8)
    save(fig, "fig1_weighting_estimand")

def broken_mu(t, p):
    y0, apre, delta, x0, logw = p[:5]
    w = np.exp(logw)
    z = (t - x0) / w
    return y0 + apre * (t - x0) + delta * w * np.logaddexp(0, z)

def fig_chronology():
    p = np.load(ROOT / "outputs/phase3/posterior_point_broken.npy")
    j = np.load(ROOT / "outputs/phase3/posterior_joint_broken.npy")
    t = np.linspace(7.7, 9.8, 300)
    fig, (ax, bx) = plt.subplots(1, 2, figsize=(7.2, 3.1), gridspec_kw={"width_ratios":[1.5,1]})
    for arr, color, label in [(p, "#275d8c", "Point-RE"), (j, "#b44", "Full-chain")]:
        idx = np.linspace(0, len(arr)-1, min(500, len(arr))).astype(int)
        curves = np.array([broken_mu(t, arr[k]) for k in idx])
        q = np.quantile(curves, [0.025, 0.5, 0.975], axis=0)
        ax.fill_between(t, q[0], q[2], color=color, alpha=.16)
        ax.plot(t, q[1], color=color, lw=2, label=label)
    ax.set(xlabel=r"$\log_{10}(t/\mathrm{yr})$", ylabel=r"population $\alpha$",
           title="Broken chronology")
    ax.legend(frameon=False, fontsize=8)
    bx.hist(p[:,3], bins=35, density=True, color="#275d8c", alpha=.45, label="Point-RE")
    bx.hist(j[:,3], bins=35, density=True, histtype="step", lw=1.8, color="#b44", label="Full-chain")
    bx.axvline(8.955, color="#222", lw=1, ls="--")
    bx.set(xlabel=r"turnover $x_0$", yticks=[], title=r"$\Delta x_0=0.0006$ dex")
    bx.legend(frameon=False, fontsize=8)
    save(fig, "fig2_broken_chronology")

def fig_loo():
    d = pd.read_csv(ROOT / "outputs/phase3/psis_loo_contrasts.csv")
    fig, ax = plt.subplots(figsize=(5.5, 3.2))
    labels = ["linear − constant", "broken − linear"]
    y = np.arange(len(labels))
    colors = {"point":"#275d8c", "joint":"#b44"}
    for off, kind in [(-.12, "point"), (.12, "joint")]:
        sub = d[d.kind == kind].set_index("contrast")
        vals = [sub.loc[x, "delta_elpd"] for x in ["linear-constant", "broken-linear"]]
        err = [sub.loc[x, "se_delta"] for x in ["linear-constant", "broken-linear"]]
        ax.errorbar(vals, y + off, xerr=err, fmt="o", capsize=3, lw=1.2, color=colors[kind], label=kind)
    ax.axvline(0, color="#444", lw=.8)
    ax.set_yticks(y, labels); ax.set_xlabel(r"$\Delta$ ELPD (cluster-level PSIS-LOO)")
    ax.set_title("Both comparators prefer the broken relation")
    ax.legend(frameon=False)
    save(fig, "fig3_psis_loo")

def fig_diagnostics():
    ess = pd.read_csv(ROOT / "outputs/phase3/importance_diagnostics_by_cluster.csv")
    infl = pd.read_csv(ROOT / "outputs/phase3/x0_influence_approx.csv")
    fig, (ax, bx) = plt.subplots(1, 2, figsize=(7.2, 3.1))
    ax.hist(ess["essfrac_median"], bins=30, color="#777", alpha=.8)
    ax.axvline(.1, color="#b44", ls="--", lw=1, label="ESS/N=.1")
    ax.axvline(.2, color="#275d8c", ls=":", lw=1.2, label="ESS/N=.2")
    ax.set(xlabel="importance ESS fraction", ylabel="clusters", title="Recycling diagnostics")
    ax.legend(frameon=False, fontsize=8)
    if "delta_x0" in infl:
        bx.scatter(infl.index, infl["delta_x0"], s=8, color="#275d8c")
        bx.axhline(0, color="#444", lw=.8)
        bx.set(xlabel="cluster index", ylabel=r"approx. $\Delta x_0$", title="Influence warning")
    save(fig, "fig4_diagnostics")

if __name__ == "__main__":
    fig_weighting(); fig_chronology(); fig_loo(); fig_diagnostics()
    print(f"Wrote figures to {OUT}")
