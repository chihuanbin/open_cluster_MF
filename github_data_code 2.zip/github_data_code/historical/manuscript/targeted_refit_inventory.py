#!/usr/bin/env python3
"""Inventory the targeted-refit feasibility and write an auditable decision.

The public chain archive contains posterior rows, but a fresh MiMO fit also
requires the cluster CMD, photometric uncertainties, the auxiliary field CMD,
and the isochrone HDF5 model. This script checks those inputs explicitly rather
than silently substituting an unmatched Gaia query.
"""
from pathlib import Path
import hashlib
import json
import pandas as pd
from astropy.io import fits

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "manuscript"

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def main():
    diag = pd.read_csv(ROOT / "outputs/phase3/importance_diagnostics_by_cluster.csv")
    low = diag.sort_values(["essfrac_q05", "essfrac_median"]).head(10)
    low.to_csv(OUT / "targeted_refit_candidates.csv", index=False)
    archive = ROOT / "cluster_params_posterior_chains.html"
    chain_dir = ROOT / "data/mimo_chains_prime"
    with fits.open(chain_dir / f"post_chain_{low.iloc[0].cluster}.fits") as hdul:
        cols = list(hdul[1].columns.names)
        nrows = int(len(hdul[1].data))
        header_keys = {k: hdul[1].header[k] for k in hdul[1].header if k in {"DATE", "CREATOR", "ORIGIN", "EXTNAME", "NAXIS2"}}
    required = {
        "cluster_CMD_with_photometric_errors": False,
        "auxiliary_field_CMD_with_errors": False,
        "isochrone_model_h5": False,
        "MiMO_likelihood_source": True,
        "public_posterior_chain": True,
    }
    result = {
        "status": "PUBLIC_CHAIN_AUDIT_REQUIRED",
        "candidate_count": 10,
        "candidates": low[["cluster", "essfrac_q05", "essfrac_median", "essfrac_q95"]].to_dict("records"),
        "required_inputs": required,
        "available_chain_columns": cols,
        "sample_chain_rows_for_first_candidate": nrows,
        "sample_chain_header_metadata": header_keys,
        "archive_sha256": sha256(archive),
        "archive_path": str(archive),
        "chain_dir": str(chain_dir),
        "why_no_refit": "The workspace has posterior chains, catalog summaries, membership positions, and cluster astrometric selection parameters, but not the original CMD photometry/errors, auxiliary field CMDs, or iso_model.h5. A new Gaia query would not reproduce the frozen MiMO input and would not be a targeted refit.",
        "action": "Do not fabricate refit outputs. Keep the manuscript explicitly scoped as a public-chain audit unless the original PaperData input bundle is obtained.",
    }
    (OUT / "targeted_refit_inventory.json").write_text(json.dumps(result, indent=2) + "\n")
    lines = [
        "# Targeted-refit inventory",
        "",
        "Status: **PUBLIC_CHAIN_AUDIT_REQUIRED**.",
        "",
        "The ten lowest-ESS candidates are listed in `targeted_refit_candidates.csv`.",
        "A fresh MiMO refit is not executable from the current workspace without",
        "the original cluster CMD photometry/errors, auxiliary field CMDs/errors,",
        "and the isochrone HDF5 model. The available `member_stars.fits` contains",
        "positions and membership probabilities only, so a new Gaia query would not",
        "reconstruct the frozen MiMO input sample.",
        "",
        "The manuscript therefore remains explicitly a **public-chain audit**.",
        "No refit result is claimed. If the original PaperData input bundle is later",
        "obtained, refit these ten clusters with the pinned configuration in",
        "`mimo_exact_provenance.md` and rerun Phase III before calling recycling",
        "unrestricted.",
    ]
    (OUT / "targeted_refit_inventory.md").write_text("\n".join(lines) + "\n")
    print(pd.DataFrame(result["candidates"]).to_string(index=False))
    print("Wrote", OUT / "targeted_refit_inventory.md")

if __name__ == "__main__":
    main()
