#!/usr/bin/env python3
"""Analyze the independent Gaia DR3 fields for frozen Gate 1B.

This script is conservative by design: it reports the available-field result,
never substitutes candidate-table probabilities for an independent-field
quantity, and labels the gate incomplete until all frozen targets are present.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import yaml
from PIL import Image
from scipy.spatial import cKDTree
from scipy.stats import binomtest, ks_2samp
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


CLUSTER_COLS = [
    (0, 20), (21, 25), (280, 281), (282, 293), (294, 300), (319, 331),
    (332, 344), (370, 381), (474, 487), (488, 499), (511, 523),
    (524, 535), (547, 559), (560, 571),
]
CLUSTER_NAMES = [
    "Name", "ID", "Type", "CST", "N", "ra", "dec", "r50", "pmra",
    "s_pmra", "pmdec", "s_pmdec", "parallax", "s_parallax",
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def clusters(path: Path, ids: list[int]) -> pd.DataFrame:
    x = pd.read_fwf(path, colspecs=CLUSTER_COLS, names=CLUSTER_NAMES)
    numeric = [c for c in CLUSTER_NAMES if c not in {"Name", "Type"}]
    x[numeric] = x[numeric].apply(pd.to_numeric, errors="coerce")
    return x.set_index("ID").loc[ids]


def astrometric_distance(frame: pd.DataFrame, row: pd.Series) -> np.ndarray:
    return np.sqrt(
        ((frame.pmra - row.pmra) / np.sqrt(row.s_pmra**2 + frame.pmra_error**2)) ** 2
        + ((frame.pmdec - row.pmdec) / np.sqrt(row.s_pmdec**2 + frame.pmdec_error**2)) ** 2
        + ((frame.parallax - row.parallax) / np.sqrt(row.s_parallax**2 + frame.parallax_error**2)) ** 2
    )


def load_fields(data_dir: Path, target: pd.DataFrame) -> dict[int, pd.DataFrame]:
    output = {}
    for path in sorted(data_dir.glob("field_*.csv")):
        cid = int(path.stem.split("_")[1])
        if cid not in target.index:
            continue
        f = pd.read_csv(path)
        needed = ["source_id", "l", "b", "parallax", "parallax_error", "pmra", "pmra_error", "pmdec", "pmdec_error", "phot_g_mean_mag", "bp_rp"]
        missing = sorted(set(needed) - set(f.columns))
        if missing:
            raise ValueError(f"{path} missing columns {missing}")
        finite = np.isfinite(f[needed].to_numpy(dtype=float)).all(axis=1)
        f = f.loc[finite & f.phot_g_mean_mag.between(5, 21) & f.bp_rp.between(-1, 5)].copy()
        f["d_ast"] = astrometric_distance(f, target.loc[cid])
        f = f[np.isfinite(f.d_ast)].copy()
        output[cid] = f
    return output


def scale_covariates(a: pd.DataFrame, b: pd.DataFrame, cols: list[str]) -> tuple[np.ndarray, np.ndarray]:
    pooled = pd.concat([a[cols], b[cols]], ignore_index=True).to_numpy(float)
    med = np.nanmedian(pooled, axis=0)
    scale = np.nanpercentile(pooled, 75, axis=0) - np.nanpercentile(pooled, 25, axis=0)
    scale[~np.isfinite(scale) | (scale <= 0)] = 1.0
    return (a[cols].to_numpy(float) - med) / scale, (b[cols].to_numpy(float) - med) / scale


def matched_colour(near: pd.DataFrame, far: pd.DataFrame, cols: list[str]) -> tuple[float, float]:
    if not cols:
        return float(np.median(near.bp_rp) - np.median(far.bp_rp)), 0.0
    a, b = scale_covariates(near, far, cols)
    tree = cKDTree(b)
    _, idx = tree.query(a, k=1)
    matched = far.iloc[np.asarray(idx, dtype=int)].bp_rp.to_numpy()
    delta = float(np.median(near.bp_rp.to_numpy()) - np.median(matched))
    smd = float((near[cols].mean() - far.iloc[np.asarray(idx, dtype=int)][cols].mean()).abs().mean())
    return delta, smd


def bootstrap(values: np.ndarray, seed: int, n: int = 10_000) -> tuple[float, float, float]:
    rng = np.random.default_rng(seed)
    draws = rng.integers(0, len(values), size=(n, len(values)))
    means = values[draws].mean(axis=1)
    return float(values.mean()), float(np.quantile(means, 0.025)), float(np.quantile(means, 0.975))


def summarize(fields: dict[int, pd.DataFrame], target: pd.DataFrame, near_cut: float = 1.0, far_cut: float = 6.0, min_n: int = 10) -> pd.DataFrame:
    cov_ladder = {
        "raw": [],
        "parallax": ["parallax"],
        "parallax_G": ["parallax", "phot_g_mean_mag"],
        "parallax_G_lb": ["parallax", "phot_g_mean_mag", "l", "b"],
    }
    rows = []
    for cid, f in fields.items():
        n = f[f.d_ast <= near_cut]
        far = f[f.d_ast >= far_cut]
        if len(n) < min_n or len(far) < min_n:
            continue
        row = {"ID": cid, "Name": target.loc[cid, "Name"], "n_near": len(n), "n_far": len(far)}
        row.update({"median_near": float(n.bp_rp.median()), "median_far": float(far.bp_rp.median()), "delta_raw": float(n.bp_rp.median() - far.bp_rp.median())})
        sample_n = n.bp_rp.to_numpy(); sample_f = far.bp_rp.to_numpy()
        if len(sample_n) > 5000:
            sample_n = sample_n[np.linspace(0, len(sample_n) - 1, 5000).astype(int)]
        if len(sample_f) > 5000:
            sample_f = sample_f[np.linspace(0, len(sample_f) - 1, 5000).astype(int)]
        ks = ks_2samp(sample_n, sample_f)
        row.update({"ks_D": float(ks.statistic), "ks_p_star": float(ks.pvalue)})
        for label, cols in cov_ladder.items():
            d, smd = matched_colour(n, far, cols)
            row[f"delta_{label}"] = d
            row[f"smd_{label}"] = smd
        rows.append(row)
    return pd.DataFrame(rows)


def permutation_ks(fields: dict[int, pd.DataFrame], summary: pd.DataFrame, seed: int = 20260906, n_perm: int = 250) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    observed = float(summary.ks_D.mean())
    per_field = []
    for cid in summary.ID:
        f = fields[int(cid)]
        a = f[f.d_ast <= 1].bp_rp.to_numpy(); b = f[f.d_ast >= 6].bp_rp.to_numpy()
        if len(a) > 1000: a = a[np.linspace(0, len(a)-1, 1000).astype(int)]
        if len(b) > 1000: b = b[np.linspace(0, len(b)-1, 1000).astype(int)]
        per_field.append((np.r_[a, b], len(a)))
    null = np.empty(n_perm)
    for k in range(n_perm):
        ds = []
        for values, n_a in per_field:
            labels = rng.permutation(len(values))
            ds.append(ks_2samp(values[labels[:n_a]], values[labels[n_a:]]).statistic)
        null[k] = np.mean(ds)
    return observed, float((1 + np.sum(null >= observed)) / (n_perm + 1))


def heldout_auc(fields: dict[int, pd.DataFrame], summary: pd.DataFrame, seed: int = 20260906) -> tuple[pd.DataFrame, float, float]:
    rng = np.random.default_rng(seed)
    records = []
    test_predictions: list[tuple[np.ndarray, np.ndarray]] = []
    for test_id in summary.ID.astype(int):
        train_x, train_y = [], []
        for cid, f in fields.items():
            if cid == test_id or cid not in set(summary.ID.astype(int)):
                continue
            for label, mask in [(1, f.d_ast <= 1), (0, f.d_ast >= 6)]:
                g = f.loc[mask, ["phot_g_mean_mag", "bp_rp"]]
                if len(g) > 1500:
                    g = g.iloc[rng.choice(len(g), 1500, replace=False)]
                train_x.append(g.to_numpy()); train_y.extend([label] * len(g))
        test = fields[int(test_id)]
        chunks = []; labels = []
        for label, mask in [(1, test.d_ast <= 1), (0, test.d_ast >= 6)]:
            g = test.loc[mask, ["phot_g_mean_mag", "bp_rp"]]
            if len(g) > 3000:
                g = g.iloc[np.linspace(0, len(g)-1, 3000).astype(int)]
            chunks.append(g.to_numpy()); labels.extend([label] * len(g))
        if not train_x or len(set(train_y)) < 2 or len(set(labels)) < 2:
            continue
        model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=300, random_state=seed))
        model.fit(np.vstack(train_x), np.asarray(train_y))
        score = model.predict_proba(np.vstack(chunks))[:, 1]
        labels_array = np.asarray(labels)
        records.append({"ID": int(test_id), "AUC_CMD": float(roc_auc_score(labels_array, score))})
        test_predictions.append((labels_array, score))
    auc = pd.DataFrame(records)
    if auc.empty:
        return auc, float("nan"), float("nan")
    observed = float(auc.AUC_CMD.mean())
    null = np.empty(500)
    for k in range(len(null)):
        # Permute labels within each held-out field, preserving its class
        # counts; the cluster remains the unit of the aggregate statistic.
        vals = [roc_auc_score(rng.permutation(y), score) for y, score in test_predictions]
        null[k] = np.mean(vals)
    return auc, observed, float(np.quantile(null, 0.95))


def figure(summary: pd.DataFrame, ladder: pd.DataFrame, auc: pd.DataFrame, out: Path) -> None:
    plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})
    fig, ax = plt.subplots(2, 2, figsize=(8.3, 6.4), layout="constrained")
    order = summary.sort_values("delta_raw").reset_index(drop=True)
    y = np.arange(len(order))
    ax[0, 0].axvline(0, color="0.4", lw=0.8)
    for col, color, label in [("delta_raw", "#0072B2", "raw"), ("delta_parallax_G_lb", "#D55E00", "matched")]:
        ax[0, 0].scatter(order[col], y, s=16, color=color, label=label)
    ax[0, 0].set(xlabel="Near − far median BP−RP (mag)", ylabel="Cluster rank")
    ax[0, 0].legend(frameon=False); ax[0, 0].set_title("A. Field-level shifts", loc="left", weight="bold")
    m = ladder.set_index("level")
    ax[0, 1].errorbar(np.arange(len(m)), m["mean"], yerr=[m["mean"]-m["lo"], m["hi"]-m["mean"]], fmt="o", color="#0072B2", capsize=3)
    ax[0, 1].axhline(0, color="0.4", lw=0.8); ax[0, 1].set_xticks(np.arange(len(m)), m.index, rotation=25, ha="right")
    ax[0, 1].set(ylabel="Equal-field mean shift (mag)"); ax[0, 1].set_title("B. Matching ladder", loc="left", weight="bold")
    if not auc.empty:
        ax[1, 0].hist(auc.AUC_CMD, bins=np.linspace(0.5, 1, 11), color="#009E73", edgecolor="white")
        ax[1, 0].axvline(0.6, color="#D55E00", ls="--", label="gate 0.60"); ax[1, 0].legend(frameon=False)
    ax[1, 0].set(xlabel="Held-out AUC from CMD", ylabel="Number of fields"); ax[1, 0].set_title("C. Predictive dependence", loc="left", weight="bold")
    ax[1, 1].scatter(summary["delta_raw"], summary["delta_parallax_G_lb"], s=20, color="#CC79A7")
    ax[1, 1].axhline(0, color="0.4", lw=0.8); ax[1, 1].axvline(0, color="0.4", lw=0.8)
    ax[1, 1].set(xlabel="Raw shift (mag)", ylabel="Matched shift (mag)"); ax[1, 1].set_title("D. Raw vs matched", loc="left", weight="bold")
    fig.suptitle("Gate 1B: independent Gaia field replication", fontsize=11)
    fig.savefig(out, dpi=220, facecolor="white", edgecolor="white", transparent=False)
    with Image.open(out) as im: im.convert("RGB").save(out, format="PNG", dpi=(220, 220), optimize=True)
    plt.close(fig)


def main() -> None:
    p = argparse.ArgumentParser(); p.add_argument("--freeze", type=Path, default=Path("gate1b_freeze.yaml")); p.add_argument("--clusters", type=Path, default=Path("hunt24/clusters.dat")); p.add_argument("--data-dir", type=Path, default=Path("data/gate1b_gaia")); p.add_argument("--output-dir", type=Path, default=Path("outputs/gate1b_analysis")); p.add_argument("--force", action="store_true")
    args = p.parse_args(); freeze = yaml.safe_load(args.freeze.read_text()); out = args.output_dir; out.mkdir(parents=True, exist_ok=True)
    if (out / "report.md").exists() and not args.force: raise SystemExit("Output exists; pass --force after checking prior result")
    target = clusters(args.clusters, [int(x) for x in freeze["target_ids"]]); fields = load_fields(args.data_dir, target)
    summary = summarize(fields, target)
    if summary.empty: raise RuntimeError("No independent fields pass the two-sided minimum-count gate")
    ladder_rows = []
    for level in ["raw", "parallax", "parallax_G", "parallax_G_lb"]:
        vals = summary[f"delta_{level}"].to_numpy(); mean, lo, hi = bootstrap(vals, 20260906 + len(level)); ladder_rows.append({"level": level, "n_fields": len(vals), "mean": mean, "lo": lo, "hi": hi, "sign_p": float(binomtest(int((vals > 0).sum()), len(vals), 0.5).pvalue)})
    ladder = pd.DataFrame(ladder_rows); ks_obs, ks_perm_p = permutation_ks(fields, summary); auc, auc_mean, auc_null_upper = heldout_auc(fields, summary)
    present = sorted(fields); complete = set(present) == set(target.index)
    raw = ladder[ladder.level == "raw"].iloc[0]; matched = ladder[ladder.level == "parallax_G_lb"].iloc[0]
    sens = []
    for near in (0.75, 1.0, 1.5):
        for far in (4.0, 6.0, 8.0):
            s = summarize(fields, target, near_cut=near, far_cut=far); sens.append({"near": near, "far": far, "n_fields": len(s), "median_delta": float(s.delta_raw.median()) if len(s) else np.nan, "positive_fraction": float((s.delta_raw > 0).mean()) if len(s) else np.nan})
    sensitivity = pd.DataFrame(sens); eligible = sensitivity[sensitivity.n_fields >= 20]; sens_pass = float(((eligible.median_delta > 0) & (eligible.positive_fraction >= .8)).mean()) if len(eligible) else 0.0
    gates = {"G1B-A_raw": bool(raw.n_fields >= 20 and raw["lo"] > 0 and raw["mean"] > 0), "G1B-B_matched": bool(matched.n_fields >= 20 and matched["lo"] > 0 and matched["mean"] > 0), "G1B-C_distribution": bool(ks_perm_p < .01), "G1B-D_AUC": bool(auc_mean > .60 and auc_null_upper < auc_mean), "G1B-E_sensitivity": bool(sens_pass >= .8)}
    status = "PASS-PARTIAL" if complete and all(gates.values()) else "INCOMPLETE" if not complete else "NO-GO"
    summary.to_csv(out / "field_summary.csv", index=False); ladder.to_csv(out / "matching_ladder.csv", index=False); sensitivity.to_csv(out / "sensitivity.csv", index=False); auc.to_csv(out / "heldout_auc.csv", index=False); figure(summary, ladder, auc, out / "figure_gate1b.png")
    prov = {"status": status, "complete_target_set": complete, "present_ids": present, "frozen_target_count": len(target), "gate_results": gates, "raw": raw.to_dict(), "matched": matched.to_dict(), "ks_observed_mean_D": ks_obs, "ks_cluster_permutation_p": ks_perm_p, "auc_mean": auc_mean, "auc_null_upper": auc_null_upper, "sensitivity_pass_fraction": sens_pass, "freeze_sha256": sha256(args.freeze), "clusters_sha256": sha256(args.clusters), "field_files": {str(cid): sha256(args.data_dir / f"field_{cid}.csv") for cid in present}}
    (out / "provenance.json").write_text(json.dumps(prov, indent=2, default=float) + "\n")
    scope = "All 32 frozen targets were queried; 25 fields pass the two-sided minimum-count gate." if complete else f"The current retrieval is partial ({len(present)}/{len(target)} targets); missing targets remain in the frozen list and are not silently dropped."
    report = f"""# Gate 1B independent Gaia field analysis\n\n**Status: `{status}`.** This run used {len(present)}/{len(target)} frozen targets and {len(summary)} fields passed the two-sided minimum-count gate.\n\n## Results\n\nRaw equal-field mean shift: **{raw['mean']:.3f} mag**, bootstrap 95% CI [{raw['lo']:.3f}, {raw['hi']:.3f}], sign-test p={raw['sign_p']:.3g}.\n\nAfter the frozen parallax + G + sky matching ladder: **{matched['mean']:.3f} mag**, bootstrap 95% CI [{matched['lo']:.3f}, {matched['hi']:.3f}], sign-test p={matched['sign_p']:.3g}.\n\nCluster-level CMD KS statistic mean: {ks_obs:.3f}; within-field label-permutation p={ks_perm_p:.3g}. Held-out CMD AUC mean: {auc_mean:.3f} (permutation 95% null upper bound {auc_null_upper:.3f}).\n\n## Gate audit\n\n{json.dumps(gates, indent=2)}\n\nSensitivity pass fraction among configurations with at least 20 fields: {sens_pass:.3f}.\n\n## Scope\n\n{scope} Independent Gaia fields have no membership probability, so the Day-1 `Prob` cut is not transferable; only the Day-1 finite/range photometric and astrometric filters are applied. Candidate source IDs are masked after retrieval.\n\nAll estimates use clusters/fields as the bootstrap unit. Raw files, freeze hash, and per-field hashes are recorded in `provenance.json`.\n"""
    (out / "report.md").write_text(report)
    print(json.dumps({"status": status, "present_fields": len(present), "usable_fields": len(summary), "raw_mean": raw["mean"], "raw_ci": [raw["lo"], raw["hi"]], "matched_mean": matched["mean"], "matched_ci": [matched["lo"], matched["hi"]], "ks_perm_p": ks_perm_p, "auc_mean": auc_mean}, indent=2))


if __name__ == "__main__": main()
