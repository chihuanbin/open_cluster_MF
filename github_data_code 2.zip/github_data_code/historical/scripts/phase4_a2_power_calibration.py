#!/usr/bin/env python3
"""Outcome-blind Phase IV-A2 power calibration.

Synthetic outcomes only: no catalogue MF slopes, alpha uncertainties, or MiMO
chains are read.  The age term is a frozen smoothly-broken basis (fixed knot
and width from the pre-outcome design); the exposure coefficient is estimated
with the same basis in every realization.  This is a design calibration, not
an outcome analysis.
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]; OUT = ROOT / "outputs/phase4"

def broken_basis(t):
    x0, width = 8.95, 0.40
    z = (t - x0) / width
    return np.column_stack([np.ones(len(t)), t - x0, width * np.logaddexp(0, z)])

def fit_stats(y, X0, X1):
    n = len(y)
    b0 = np.linalg.lstsq(X0, y, rcond=None)[0]; e0 = y - X0 @ b0
    b1 = np.linalg.lstsq(X1, y, rcond=None)[0]; e1 = y - X1 @ b1
    h0 = np.sum(X0 * (X0 @ np.linalg.pinv(X0.T @ X0)), axis=1)
    h1 = np.sum(X1 * (X1 @ np.linalg.pinv(X1.T @ X1)), axis=1)
    s20 = np.sum(e0 * e0) / (n - X0.shape[1]); s21 = np.sum(e1 * e1) / (n - X1.shape[1])
    loo0 = -0.5 * ((e0 / np.maximum(1-h0, 1e-6))**2 / s20 + np.log(2*np.pi*s20))
    loo1 = -0.5 * ((e1 / np.maximum(1-h1, 1e-6))**2 / s21 + np.log(2*np.pi*s21))
    cov = s21 * np.linalg.pinv(X1.T @ X1); se = np.sqrt(max(cov[-1,-1], 1e-12))
    return float(b1[-1]), float(b1[-1]/se), float(np.sum(loo1-loo0)), float(np.sqrt(len(y)*np.var(loo1-loo0, ddof=1)))

def main():
    b = pd.read_parquet(OUT / "CLOCK_FREEZE_B.parquet")
    tau = b.log_age_50.to_numpy(float); eta = b.eta_diss_50.to_numpy(float)
    age = broken_basis(tau)
    orth = eta - age @ np.linalg.lstsq(age, eta, rcond=None)[0]
    z = orth / orth.std(ddof=1)
    X1 = np.column_stack([age, z]); rng = np.random.default_rng(20260907)
    # Generic frozen outcome template: unit residual SD, no alpha-derived
    # measurement errors.  The baseline broken curve is deliberately generic.
    mu = age @ np.array([0.0, -0.15, 0.35]); sig = 1.0
    gammas = [0, .2, .4, .6, .8, 1.0]; sims = 1000
    raw = {g: [] for g in gammas}
    for g in gammas:
        for _ in range(sims):
            y = mu + g*z + rng.normal(0, sig, len(z))
            raw[g].append(fit_stats(y, age, X1))
    null_loo = np.array([x[2] for x in raw[0]])
    loo95 = float(np.quantile(null_loo, .95)); loo99 = float(np.quantile(null_loo, .99))
    rows=[]
    for g in gammas:
        x=np.asarray(raw[g]); coef=(x[:,0] > 0) & (x[:,1] > 1.96) & (x[:,0] > .3)
        pred=x[:,2] > loo95
        rows.append({"gamma_star":g,"n_sim":sims,"power_conditional_hardA":float(coef.mean()),
                     "power_null_calibrated_hardB":float(pred.mean()),
                     "power_combined_A_and_B":float((coef & pred).mean()),
                     "median_delta_elpd_proxy":float(np.median(x[:,2]))})
    # Combined-rule FPR is reported explicitly, not inferred from component rates.
    fpr = rows[0]["power_combined_A_and_B"]
    p06 = next(r for r in rows if r["gamma_star"] == .6)["power_combined_A_and_B"]
    result={"status":"PHASE_IV_A1_CLOSED_A2_POWER_CALIBRATED","outcome_blind":True,"alpha_read":False,
            "n_clusters":len(z),"n_sim_per_gamma":sims,"gamma_grid":gammas,
            "age_model":"fixed smoothly-broken basis; x0=8.95, width=0.40 dex",
            "outcome_template":"generic synthetic outcome; residual sigma=1; no alpha-derived measurement errors",
            "loo_statistic":"leave-one-out Gaussian score difference; design proxy, not real-data PSIS-LOO",
            "null_calibration":{"q95_delta_elpd":loo95,"q99_delta_elpd":loo99,"combined_rule_FPR":fpr},
            "power":rows,"target_gamma_0p6_combined_power":p06,
            "decision":"A2 outcome unlock remains CLOSED unless a future preregistered full-likelihood implementation reproduces FPR<=0.05 and power>=0.80; no alpha was accessed."}
    (OUT/'A2_POWER_CALIBRATION.json').write_text(json.dumps(result,indent=2)+'\n')
    pd.DataFrame(rows).to_csv(OUT/'A2_POWER_CALIBRATION.csv',index=False)
    (OUT/'A2_POWER_CALIBRATION.md').write_text("\n".join(["# Phase IV-A2 outcome-blind power calibration","", "Status: **A2 OPEN / OUTCOME STILL LOCKED**.", "", "Phase IV-A1 remains permanently closed with its original gates unchanged. This calibration uses synthetic outcomes only; no alpha or MiMO chain was read.", "", f"Null-calibrated Gaussian LOO-proxy threshold: Q95={loo95:.3f}; combined-rule FPR={fpr:.3f}.", f"Combined-rule power at gamma*=0.6: {p06:.3f}.", "", "The LOO statistic is a design proxy, not a formal real-data PSIS-LOO result. A2 cannot unlock outcome until a full-likelihood implementation reproduces the calibration with FPR<=0.05 and target power>=0.80.", "", pd.DataFrame(rows).to_string(index=False)])+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__': main()
