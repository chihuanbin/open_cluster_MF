#!/usr/bin/env python3
"""Validate Phase-IV Freeze A/B against the preregistered D1 gates."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", type=Path, default=ROOT / "outputs/phase4")
    args = ap.parse_args()
    rv = pd.read_csv(args.out / "systemic_rv_summary.csv")
    ast = pd.read_csv(args.out / "astrometric_covariance.csv")
    orbit = pd.read_csv(args.out / "orbit_mc_summary.csv")
    fa = pd.read_parquet(args.out / "CLOCK_FREEZE_A.parquet")
    fb = pd.read_parquet(args.out / "CLOCK_FREEZE_B.parquet") if (args.out / "CLOCK_FREEZE_B.parquet").exists() else None
    prov_b = json.loads((args.out / "CLOCK_PROVENANCE_B.json").read_text()) if (args.out / "CLOCK_PROVENANCE_B.json").exists() else {}
    rho_ext = np.nan
    if "trh_external_Zhang26_Myr" in fa:
        ok = fa.trh_external_Zhang26_Myr.notna()
        if ok.sum() >= 3:
            rho_ext = float(fa.loc[ok, ["trh_primary_Myr_50", "trh_external_Zhang26_Myr"]].corr(method="spearman").iloc[0, 1])
    radius_delta = float(np.nanmedian(np.abs(np.log10(
        pd.read_csv(args.out / "member_dynamics_summary.csv").Rh_mass_proj_fixed3r50_p07_pc /
        pd.read_csv(args.out / "member_dynamics_summary.csv").Rh_mass_proj_pc))))
    gates = {
        "D0_radius_coverage_ge150": len(ast) >= 150,
        "D0_radius_sensitivity_median_lt0p1dex": radius_delta < 0.1,
        "D1_RV_good_ge120": int(rv.rv_tier.isin(["A", "B"]).sum()) >= 120,
        "D1_orbit_pass_ge120": int(orbit.orbit_status.eq("PASS").sum()) >= 120,
        "D1_median_Rperi_fractional_sigma_lt0p25": float(orbit.loc[orbit.orbit_status.eq("PASS"), "Rperi_fractional_sigma"].median()) < 0.25,
        "D1_clock_A_ge120": len(fa) >= 120,
        "D1_external_trh_rank_rho_gt0p8": bool(np.isfinite(rho_ext) and rho_ext > 0.8),
        "outcome_absent_freeze_A": not any("alpha" in c.lower() for c in fa.columns),
        "outcome_absent_freeze_B": fb is None or not any("alpha" in c.lower() for c in fb.columns),
        "freeze_B_identifiable": prov_b.get("status") == "PASS_CLOCK_FREEZE_B_IDENTIFIABLE" if fb is not None else False,
    }
    report = {
        "status": "PASS_D1_FREEZE_VALIDATION" if all(gates.values()) else "D1_PARTIAL_OR_FAIL",
        "gates": gates, "diagnostics": {
            "n_RV_AB": int(rv.rv_tier.isin(["A", "B"]).sum()),
            "n_orbit_pass": int(orbit.orbit_status.eq("PASS").sum()),
            "median_Rperi_fractional_sigma": float(orbit.loc[orbit.orbit_status.eq("PASS"), "Rperi_fractional_sigma"].median()),
            "n_freeze_A": int(len(fa)), "n_freeze_B": int(len(fb)) if fb is not None else 0,
            "median_radius_primary_vs_inrj_all_dex": radius_delta,
            "rho_trh_primary_vs_external_Zhang26": rho_ext,
        },
        "hashes": {p.name: sha256(p) for p in [args.out / "CLOCK_FREEZE_A.parquet", args.out / "CLOCK_FREEZE_B.parquet"] if p.exists()},
    }
    (args.out / "D1_VALIDATION.json").write_text(json.dumps(report, indent=2) + "\n")
    (args.out / "D1_VALIDATION.md").write_text("\n".join([
        "# Phase IV D1 validation", "", f"Status: **{report['status']}**.", "",
        *[f"- {'PASS' if value else 'FAIL'}: `{key}`" for key, value in gates.items()],
    ]) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
