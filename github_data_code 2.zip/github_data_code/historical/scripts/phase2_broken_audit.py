#!/usr/bin/env python3
"""Phase-II apples-to-apples broken-relation audit for H-MiMO.

This is the first full-weighted-chain implementation of the original
smoothly-broken population relation. It intentionally stops short of a final
PSIS-LOO paper analysis: exact prior provenance is still an open H0.5 gate.
The joint likelihood uses every supplied nested-sampling weight via
per-cluster log-sum-exp; the point model uses the catalog medians and their
reported alpha uncertainties.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import logsumexp

from h2_5_decomposition import load_raw_chains, log_normal
from hierarchical_mimo_summary import read_catalog


def broken_mean(tau, pars):
    y0, a1, a2, x0, log_s = pars[:5]
    s = np.exp(log_s)
    z = s * (tau - x0)
    return y0 + a1 * (tau - x0) + (a2 - a1) * np.logaddexp(0.0, z) / s


def point_loglike(pars, d):
    sigma = np.exp(pars[-1])
    if not (0.005 <= sigma <= 2.0): return -np.inf
    tau = d.logage50.to_numpy(); alpha = d.alpha50.to_numpy()
    alpha_sd = np.maximum((d.alpha84.to_numpy() - d.alpha16.to_numpy()) / 2.0, 0.02)
    return float(np.sum(log_normal(alpha, broken_mean(tau, pars), np.sqrt(sigma**2 + alpha_sd**2))))


def joint_loglike(pars, chains):
    sigma = np.exp(pars[-1])
    if not (0.005 <= sigma <= 2.0): return -np.inf
    total = 0.0
    for c in chains:
        total += float(logsumexp(c["logw"] + log_normal(c["alpha"], broken_mean(c["tau"], pars), sigma)))
    return total


def fit(fun, start):
    # y0, a1, a2, x0, log_s, log_sigma
    bounds = [(-5, 1), (-5, 3), (-5, 3), (7, 10.2), (np.log(0.1), np.log(80)), (np.log(0.005), np.log(2))]
    # Powell respects bounds and is less sensitive than finite-difference
    # gradients to the log-sum-exp posterior integral.
    r = minimize(lambda x: -fun(x), start, method="Powell", bounds=bounds, options={"maxiter": 900, "xtol": 2e-5, "ftol": 2e-5})
    return r


def hessian(fun, x, h=2e-3):
    n = len(x); H = np.zeros((n, n)); f = lambda z: -fun(z); f0 = f(x)
    for i in range(n):
        ei = np.zeros(n); ei[i] = h
        H[i, i] = (f(x + ei) - 2*f0 + f(x - ei)) / h**2
        for j in range(i):
            ej = np.zeros(n); ej[j] = h
            H[i,j] = H[j,i] = (f(x+ei+ej)-f(x+ei-ej)-f(x-ei+ej)+f(x-ei-ej))/(4*h**2)
    return H


def laplace_draws(fun, x, n, seed):
    H = hessian(fun, x)
    cov = np.linalg.pinv(H)
    cov = (cov + cov.T) / 2
    # Numerical negative eigenvalues indicate a local approximation problem;
    # clip only for provisional summaries and record the clipping.
    vals, vecs = np.linalg.eigh(cov); clipped = bool(np.any(vals < 0)); vals = np.maximum(vals, 1e-10)
    cov = (vecs * vals) @ vecs.T
    rng = np.random.default_rng(seed)
    return rng.multivariate_normal(x, cov, size=n), cov, clipped


def pointwise_loglikes(draws, d, chains, kind):
    out = np.empty((len(draws), len(d)))
    alpha50 = d.alpha50.to_numpy(); tau50 = d.logage50.to_numpy(); alpha_sd = np.maximum((d.alpha84.to_numpy()-d.alpha16.to_numpy())/2.0, 0.02)
    for k, p in enumerate(draws):
        sig = np.exp(p[-1])
        if kind == "point":
            out[k] = log_normal(alpha50, broken_mean(tau50,p), np.sqrt(sig**2 + alpha_sd**2))
        else:
            for j,c in enumerate(chains): out[k,j] = logsumexp(c["logw"] + log_normal(c["alpha"], broken_mean(c["tau"],p), sig))
    return out


def importance_ess(chains, pars):
    """Per-cluster ESS of the population-prior recycling weights at MAP."""
    sigma = np.exp(pars[-1]); rows = []
    for j, c in enumerate(chains):
        lw = c["logw"] + log_normal(c["alpha"], broken_mean(c["tau"], pars), sigma)
        lw = lw - logsumexp(lw); q = np.exp(lw); ess = 1.0 / np.sum(q * q)
        rows.append({"cluster_index": j, "n_chain": len(q), "ess_imp": float(ess), "ess_frac": float(ess / len(q)), "max_weight": float(q.max())})
    return pd.DataFrame(rows)


def main():
    p = argparse.ArgumentParser(); p.add_argument("--catalog",type=Path,default=Path("data/mimo_catalog/table3.dat")); p.add_argument("--chain-dir",type=Path,default=Path("data/mimo_chains_prime")); p.add_argument("--output-dir",type=Path,default=Path("outputs/phase2_broken_audit")); p.add_argument("--posterior-draws",type=int,default=2000); p.add_argument("--seed",type=int,default=20260906); p.add_argument("--provisional-loo",action="store_true",help="run expensive non-PSIS predictive audit"); p.add_argument("--force",action="store_true")
    a=p.parse_args(); out=a.output_dir; out.mkdir(parents=True,exist_ok=True)
    if (out/'report.md').exists() and not a.force: raise SystemExit('Output exists; pass --force')
    d=read_catalog(a.catalog,prime_only=True); chains=load_raw_chains(d,a.chain_dir)
    start=np.array([-2.0,0.0,0.5,8.9,np.log(4.0),np.log(0.45)])
    rp=fit(lambda x: point_loglike(x,d),start); rj=fit(lambda x: joint_loglike(x,chains),rp.x)
    rows=[]
    for lab,r,fun in [('point_broken',rp,lambda x:point_loglike(x,d)),('joint_broken',rj,lambda x:joint_loglike(x,chains))]:
        rows.append({'model':lab,'y0':r.x[0],'a1':r.x[1],'a2':r.x[2],'x0':r.x[3],'s':np.exp(r.x[4]),'sigma_int':np.exp(r.x[5]),'loglike':-r.fun,'success':r.success,'nfev':r.nfev})
    pd.DataFrame(rows).to_csv(out/'broken_fits.csv',index=False)
    importance_ess(chains, rj.x).to_csv(out/'importance_ess_joint_broken_map.csv', index=False)
    summary=[]
    for lab,r,fun in [('point_broken',rp,lambda x:point_loglike(x,d)),('joint_broken',rj,lambda x:joint_loglike(x,chains))]:
        dr,cov,clipped=laplace_draws(fun,r.x,a.posterior_draws,a.seed+(0 if lab.startswith('point') else 1)); dr[:,3]=np.clip(dr[:,3],7,10.2); dr[:,4]=np.clip(dr[:,4],np.log(.1),np.log(80)); dr[:,5]=np.clip(dr[:,5],np.log(.005),np.log(2))
        summary.append({'model':lab,'x0_median':np.median(dr[:,3]),'x0_lo':np.quantile(dr[:,3],.025),'x0_hi':np.quantile(dr[:,3],.975),'P_a2_gt_a1':np.mean(dr[:,2]>dr[:,1]),'P_x0_8p7_9p1':np.mean((dr[:,3]>8.7)&(dr[:,3]<9.1)),'sigma_median':np.median(np.exp(dr[:,5])),'laplace_clipped':clipped})
        pd.DataFrame(dr,columns=['y0','a1','a2','x0','log_s','log_sigma']).to_csv(out/f'{lab}_laplace_draws.csv',index=False)
    pd.DataFrame(summary).to_csv(out/'broken_laplace_summary.csv',index=False)
    # This is deliberately opt-in: evaluating the raw weighted joint chains
    # for every Laplace draw is expensive and is not a substitute for PSIS.
    if a.provisional_loo:
        loo_rows=[]
        for lab,r,fun in [('point_broken',rp,lambda x:point_loglike(x,d)),('joint_broken',rj,lambda x:joint_loglike(x,chains))]:
            dr,_,_=laplace_draws(fun,r.x,a.posterior_draws,a.seed+(0 if lab.startswith('point') else 1)); ll=pointwise_loglikes(dr,d,chains,'point' if lab.startswith('point') else 'joint');
            loo_rows.append({'model':lab,'mean_log_predictive':float(np.sum(logsumexp(ll,axis=0)-np.log(ll.shape[0]))),'n_clusters':len(d)})
        pd.DataFrame(loo_rows).to_csv(out/'loo_provisional.csv',index=False)
    else:
        pd.DataFrame([{'model':'all','status':'not_run','reason':'H0.5 prior gate open; exact PSIS-LOO deferred'}]).to_csv(out/'loo_provisional.csv',index=False)
    prov={'status':'PHASE2-BROKEN-PILOT','n_clusters':len(d),'chain_engine':'original logwt logsumexp for joint_broken','point_engine':'catalog medians plus reported alpha errors','posterior_engine':'local Laplace draws; provisional only','pssis_loo':'not yet exact; loo_provisional.csv is a non-PSIS predictive audit','h0_5':'OPEN-TAIL-DISCREPANCY'}
    (out/'provenance.json').write_text(json.dumps(prov,indent=2)+'\n')
    p0,p1=rows[0],rows[1]
    s0,s1=summary[0],summary[1]
    report=f'''# H-MiMO Phase II broken-relation pilot

Status: **`PHASE2-BROKEN-PILOT`** on {len(d)} MF Prime clusters.

The same smoothly-broken mean relation was fitted to catalog medians (point) and to the full joint FITS chains (joint). The joint likelihood uses the original nested-sampling `logwt` values with per-cluster `logsumexp`.

| quantity | point | joint |
|---|---:|---:|
| x0 (MAP) | {p0['x0']:.4f} | {p1['x0']:.4f} |
| a1 | {p0['a1']:.4f} | {p1['a1']:.4f} |
| a2 | {p0['a2']:.4f} | {p1['a2']:.4f} |
| sigma_int | {p0['sigma_int']:.4f} | {p1['sigma_int']:.4f} |

Provisional Laplace summaries are in `broken_laplace_summary.csv`; they are not a replacement for a final MCMC/nested hyperposterior. The current point-to-joint transition shift is Δx0={p1['x0']-p0['x0']:+.4f} dex. This is not yet a chronology claim.

The H0.5 prior gate remains open because the supplied chain hard tails are slightly wider than the printed ranges. `loo_provisional.csv` is explicitly **not PSIS-LOO** and must not be used as the final model-selection gate; by default it records that predictive evaluation was deferred.
'''
    (out/'report.md').write_text(report)
    print(json.dumps({'status':prov['status'],'point':p0,'joint':p1,'laplace':summary},indent=2))


if __name__=='__main__': main()
