#!/usr/bin/env python3
"""Construct alpha-blind cluster astrometric covariance inputs.

HR24 supplies cluster mean astrometry and standard errors but no cluster-level
correlation matrix.  This script estimates the correlation matrix from the
Gaia member-level covariance terms for the frozen non-Jacobi structural sample
(``Prob>=0.7`` and projected radius below ``3*r50pc``), then scales it by the
HR24 standard errors plus predeclared systematic floors.  The primary orbit
distance remains the HR24 photometric-distance posterior; its covariance with
proper motion is unavailable and is explicitly treated as block diagonal.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
CS = {
    "name": (0, 20), "id": (21, 25), "RA": (319, 331), "DE": (332, 344),
    "r50pc": (418, 431), "pmRA": (474, 487), "e_pmRA": (500, 510),
    "pmDE": (511, 523), "e_pmDE": (536, 546), "Plx": (547, 559),
    "e_Plx": (572, 582), "dist16": (583, 598), "dist50": (599, 614),
    "dist84": (615, 631),
}
MS = {
    "id": (29, 33), "prob": (58, 78), "ra": (79, 103), "dec": (126, 148),
    "plx_pmra": (397, 420), "plx_pmde": (421, 444), "pmra_pmde": (445, 468),
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def num(line: bytes, sl: tuple[int, int]) -> float:
    try:
        value = line[sl[0]:sl[1]].decode("ascii", errors="ignore").strip()
        return float(value) if value and value != "?" else math.nan
    except ValueError:
        return math.nan


def read_clusters(path: Path, wanted: set[int]) -> dict[int, dict[str, float | str]]:
    out = {}
    with path.open("rb") as fh:
        for line in fh:
            hid = num(line, CS["id"])
            if not math.isfinite(hid) or int(hid) not in wanted:
                continue
            rec: dict[str, float | str] = {"name": line[CS["name"][0]:CS["name"][1]].decode("ascii", errors="ignore").strip()}
            for k, sl in CS.items():
                if k not in {"name", "id"}:
                    rec[k] = num(line, sl)
            out[int(hid)] = rec
    return out


def nearest_correlation(corr: np.ndarray) -> np.ndarray:
    corr = (corr + corr.T) / 2.0
    vals, vecs = np.linalg.eigh(corr)
    corr = (vecs * np.maximum(vals, 1e-6)) @ vecs.T
    sd = np.sqrt(np.diag(corr))
    corr = corr / np.outer(sd, sd)
    np.fill_diagonal(corr, 1.0)
    return corr


def weighted_mean(x: np.ndarray, w: np.ndarray) -> float:
    ok = np.isfinite(x) & np.isfinite(w) & (w > 0)
    return float(np.average(x[ok], weights=w[ok])) if ok.any() else 0.0


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--clusters", type=Path, default=ROOT / "hunt24/clusters.dat")
    ap.add_argument("--members", type=Path, default=ROOT / "hunt24/members_full.dat")
    ap.add_argument("--match", type=Path, default=ROOT / "outputs/phase4/clock_input_match.csv")
    ap.add_argument("--out", type=Path, default=ROOT / "outputs/phase4")
    ap.add_argument("--prob-min", type=float, default=0.7)
    ap.add_argument("--pm-floor", type=float, default=0.020, help="mas/yr systematic floor")
    ap.add_argument("--plx-floor", type=float, default=0.015, help="mas systematic floor")
    args = ap.parse_args(); args.out.mkdir(parents=True, exist_ok=True)

    match = pd.read_csv(args.match)
    match = match[match.match_status.eq("unique") & match.hunt_id.notna()]
    names = {int(r.hunt_id): str(r.cluster) for _, r in match.iterrows()}
    clusters = read_clusters(args.clusters, set(names))
    vals: dict[int, list[tuple[float, float, float, float]]] = {hid: [] for hid in names}
    with args.members.open("rb") as fh:
        for line in fh:
            hidf = num(line, MS["id"])
            if not math.isfinite(hidf) or int(hidf) not in clusters:
                continue
            hid = int(hidf); c = clusters[hid]
            p, ra, dec = num(line, MS["prob"]), num(line, MS["ra"]), num(line, MS["dec"])
            if not (math.isfinite(p) and p >= args.prob_min and math.isfinite(ra) and math.isfinite(dec)):
                continue
            ra1, ra2 = math.radians(ra), math.radians(float(c["RA"]))
            de1, de2 = math.radians(dec), math.radians(float(c["DE"]))
            hav = math.sin((de1 - de2) / 2) ** 2 + math.cos(de1) * math.cos(de2) * math.sin((ra1 - ra2) / 2) ** 2
            radius_pc = float(c["dist50"]) * 2.0 * math.asin(min(1.0, math.sqrt(max(0.0, hav))))
            if radius_pc > 3.0 * float(c["r50pc"]):
                continue
            vals[hid].append((p, num(line, MS["plx_pmra"]), num(line, MS["plx_pmde"]), num(line, MS["pmra_pmde"])))

    rows = []
    for hid in sorted(names):
        c = clusters[hid]
        a = np.asarray(vals[hid], dtype=float)
        if len(a):
            w = a[:, 0]
            r_plx_pmra = weighted_mean(a[:, 1], w)
            r_plx_pmde = weighted_mean(a[:, 2], w)
            r_pmra_pmde = weighted_mean(a[:, 3], w)
        else:
            r_plx_pmra = r_plx_pmde = r_pmra_pmde = 0.0
        # Stored order is pmRA, pmDE, parallax.
        corr_raw = np.array([[1.0, r_pmra_pmde, r_plx_pmra],
                             [r_pmra_pmde, 1.0, r_plx_pmde],
                             [r_plx_pmra, r_plx_pmde, 1.0]])
        corr = nearest_correlation(np.clip(corr_raw, -0.999, 0.999))
        sd = np.array([
            math.hypot(float(c["e_pmRA"]), args.pm_floor),
            math.hypot(float(c["e_pmDE"]), args.pm_floor),
            math.hypot(float(c["e_Plx"]), args.plx_floor),
        ])
        cov = corr * np.outer(sd, sd)
        rows.append({
            "cluster": names[hid], "hunt_id": hid, "n_astrometric_members": len(a),
            "RA_deg": c["RA"], "Dec_deg": c["DE"], "distance16_pc": c["dist16"],
            "distance50_pc": c["dist50"], "distance84_pc": c["dist84"],
            "pmRA_masyr": c["pmRA"], "pmDec_masyr": c["pmDE"], "parallax_mas": c["Plx"],
            "cov_pmra_pmra": cov[0, 0], "cov_pmra_pmdec": cov[0, 1], "cov_pmra_plx": cov[0, 2],
            "cov_pmdec_pmdec": cov[1, 1], "cov_pmdec_plx": cov[1, 2], "cov_plx_plx": cov[2, 2],
            "corr_pmra_pmdec": corr[0, 1], "corr_pmra_plx": corr[0, 2], "corr_pmdec_plx": corr[1, 2],
            "min_cov_eigenvalue": float(np.linalg.eigvalsh(cov).min()),
        })
    out = pd.DataFrame(rows)
    out.to_csv(args.out / "astrometric_covariance.csv", index=False)
    report = {
        "status": "PASS_ASTROMETRIC_COVARIANCE" if len(out) >= 150 and (out.min_cov_eigenvalue > 0).all() else "FAIL_ASTROMETRIC_COVARIANCE",
        "outcome_blind": True, "n_clusters": int(len(out)),
        "selection": f"Prob>={args.prob_min} and R<3*r50pc; no inrj selection",
        "systematic_floors": {"pm_masyr": args.pm_floor, "parallax_mas": args.plx_floor},
        "distance_model": "HR24 dist16/dist50/dist84 split-normal; block diagonal with proper motion",
        "correlation_model": "probability-weighted mean Gaia member covariance correlations, projected to nearest positive-definite correlation matrix",
        "inputs": {str(p): sha256(p) for p in [args.clusters, args.members, args.match]},
        "limitations": ["No published cluster-level distance-proper-motion covariance", "Systematic floors are frozen sensitivity parameters, not data-derived estimates"],
    }
    (args.out / "astrometric_covariance_provenance.json").write_text(json.dumps(report, indent=2) + "\n")
    (args.out / "astrometric_covariance.md").write_text("\n".join([
        "# Outcome-blind astrometric covariance", "", f"Status: **{report['status']}**; {len(out)} systems.",
        "Primary distance draws use the HR24 photometric-distance quantiles. Proper-motion/parallax correlations are reconstructed from high-probability members inside 3 r50 and the covariance is forced positive definite.",
        "The unavailable distance--proper-motion covariance is explicitly block diagonal; this is a stated sensitivity limitation.",
    ]) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
