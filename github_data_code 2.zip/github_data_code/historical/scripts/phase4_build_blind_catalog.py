#!/usr/bin/env python3
"""Merge independent Phase-IV inputs into an outcome-blind pilot catalogue.

This script intentionally reads only Hunt--Reffert products and the two
outcome-blind summaries produced by the Phase-IV input pipeline.  It never
opens MiMO chains, alpha values, or any alpha-derived quantity.  The output is
*not* a frozen physical-clock catalogue: the checked-in orbit table is a
low-MC path test and the reconstructed radius is projected.  A separate
freeze is required after independent 3-D deprojection and confirmatory orbit
Monte Carlo are available.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--match", type=Path, default=ROOT / "outputs/phase4/clock_input_match.csv")
    ap.add_argument("--member", type=Path, default=ROOT / "outputs/phase4/member_dynamics_summary.csv")
    ap.add_argument("--orbit", type=Path, default=ROOT / "outputs/phase4/orbit_mc_summary.csv")
    ap.add_argument("--rv", type=Path, default=ROOT / "outputs/phase4/systemic_rv_summary.csv")
    ap.add_argument("--out", type=Path, default=ROOT / "outputs/phase4")
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    match = pd.read_csv(args.match)
    match = match[match.match_status.eq("unique")].copy()
    member = pd.read_csv(args.member)
    orbit = pd.read_csv(args.orbit)
    rv = pd.read_csv(args.rv)
    for frame, name in ((member, "member"), (orbit, "orbit")):
        if frame.hunt_id.duplicated().any():
            raise SystemExit(f"{name} summary has duplicate hunt_id values")
    # HR24 accepted names and MiMO display aliases are not guaranteed to be
    # identical; the stable key is the HR24 internal identifier.
    d = match.merge(member, on=["hunt_id"], how="left", validate="one_to_one", suffixes=("", "_member"))
    d = d.merge(orbit, on=["hunt_id"], how="left", validate="one_to_one", suffixes=("", "_orbit"))
    d = d.merge(rv.drop(columns=["cluster"], errors="ignore"), on="hunt_id", how="left", validate="one_to_one", suffixes=("", "_robustrv"))

    # Keep a compact, stable schema.  Names make the provenance boundary
    # explicit: all quantities are independent HR24/member/orbit inputs.
    # The match table and member summary both retain HR24 reference columns;
    # pandas therefore suffixes duplicate names.  Use the match copy for
    # astrometry and the member copy for the independently reconstructed N/M
    # reference fields, with explicit fallbacks for future schema revisions.
    def col(*names: str) -> pd.Series:
        for name in names:
            if name in d.columns:
                return d[name]
        raise KeyError(f"None of the expected columns exist: {names}")

    out = pd.DataFrame({
        "cluster": d["cluster"],
        "hunt_id": d["hunt_id"],
        "N_hr24": col("hunt_N_x", "hunt_N_y", "hunt_N"),
        "NJ_hr24": col("hunt_NJ", "hunt_NJ_y", "hunt_NJ_x"),
        "MassJ_hr24_Msun": col("hunt_MassJ_x", "hunt_MassJ_y", "hunt_MassJ"),
        "MassJ_err_hr24_Msun": col("hunt_e_MassJ_x", "hunt_e_MassJ_y", "hunt_e_MassJ"),
        "MassTot_hr24_Msun": col("hunt_MassTot_x", "hunt_MassTot_y", "hunt_MassTot"),
        "MassTot_err_hr24_Msun": col("hunt_e_MassTot_x", "hunt_e_MassTot_y", "hunt_e_MassTot"),
        "N_eff_inrj": d["N_eff_inrj"],
        "M_obs_prob_M50_Msun": d["M_obs_prob_M50"],
        "N_eff_inrj_p07": d["N_eff_inrj_p07"],
        "M_obs_prob_M50_inrj_p07_Msun": d["M_obs_prob_M50_inrj_p07"],
        "N_eff_fixed3r50_p07": d["N_eff_fixed3r50_p07"],
        "M_obs_prob_M50_fixed3r50_p07_Msun": d["M_obs_prob_M50_fixed3r50_p07"],
        "Rh_number_proj_pc": d["Rh_number_proj_pc"],
        "Rh_mass_proj_pc": d["Rh_mass_proj_pc"],
        "Rh_number_proj_inrj_p07_pc": d["Rh_number_proj_inrj_p07_pc"],
        "Rh_mass_proj_inrj_p07_pc": d["Rh_mass_proj_inrj_p07_pc"],
        "Rh_number_proj_fixed3r50_p07_pc": d["Rh_number_proj_fixed3r50_p07_pc"],
        "Rh_mass_proj_fixed3r50_p07_pc": d["Rh_mass_proj_fixed3r50_p07_pc"],
        "Rh_mass_proj_primary_pc": d["Rh_mass_proj_fixed3r50_p07_pc"],
        "Rh_mass_3d_pc": np.nan,
        "RA_deg": col("hunt_RAdeg"),
        "Dec_deg": col("hunt_DEdeg"),
        "distance_pc": col("hunt_dist50"),
        "distance16_pc": col("hunt_dist16"),
        "distance84_pc": col("hunt_dist84"),
        "pmRA_masyr": col("hunt_pmRA"),
        "pmRA_err_masyr": col("hunt_s_pmRA"),
        "pmDec_masyr": col("hunt_pmDE"),
        "pmDec_err_masyr": col("hunt_s_pmDE"),
        "RV_member_weighted_kms": d["RV_weighted_mean_kms"],
        "RV_member_dispersion_kms": d["RV_weighted_dispersion_kms"],
        "RVsys_robust_kms": d["RVsys_kms"],
        "RVsys_robust_err_kms": d["RVsys_err_kms"],
        "n_RV_member": d["N_RV"],
        "n_RV_fixed3r50_p07": d["n_RV_fixed3r50_p07"],
        "RV_source": "HR24_member_Gaia_RVS",
        "Rperi_50_kpc": d["Rperi_kpc_50"],
        "Rapo_50_kpc": d["Rapo_kpc_50"],
        "eccentricity_50": d["orbit_eccentricity_50"],
        "zmax_50_kpc": d["zmax_kpc_50"],
        "R_current_50_kpc": d["Rcurrent_kpc_50"],
        "V_circular_current_50_kms": d["Vcirc_current_kms_50"],
        "orbit_status": d["orbit_status"],
        "n_orbit_mc_valid": d["n_mc_valid"],
        "n_orbit_mc_requested": d["n_mc_requested"],
    })
    out["quality_mass"] = np.where(np.isfinite(out["MassJ_hr24_Msun"]), "HR24_corrected", "observed_only")
    out["quality_radius"] = np.where(np.isfinite(out["Rh_mass_proj_primary_pc"]), "projected_nonJacobi_3r50_p07", "missing")
    out["quality_RV"] = d["rv_tier"].fillna("FAIL")
    out["quality_orbit"] = np.where(out["orbit_status"].eq("PASS"), "confirmatory_threshold", "pilot_or_missing")
    out["clock_freeze_status"] = "NOT_FROZEN"
    out.to_csv(args.out / "outcome_blind_dynamics_pilot.csv", index=False)

    report = {
        "status": "PILOT_OUTCOME_BLIND_CATALOG",
        "outcome_blind": True,
        "n_rows": int(len(out)),
        "n_member_ok": int(out["quality_radius"].eq("projected_member_reconstruction").sum()),
        "n_rv_preferred": int(out["quality_RV"].eq("preferred_ge3").sum()),
        "n_orbit_confirmatory": int(out["quality_orbit"].eq("confirmatory_threshold").sum()),
        "clock_freeze_status": "NOT_FROZEN",
        "inputs": {str(p): sha256(p) for p in (args.match, args.member, args.orbit, args.rv)},
        "definitions": {
            "mass_primary": "HR24 MassJ; observed-only probability-weighted Mass50 is retained as a circularity-control column",
            "radius": "primary projected half-mass radius uses Prob>=0.7 within 3*r50pc; inrj radii are sensitivities",
            "RV": "robust Student-t systemic RV from high-probability HR24 Gaia-RVS members",
            "orbit": "fixed-potential 5000-draw confirmatory output when orbit_status=PASS",
        },
        "exclusions": ["MiMO alpha", "MiMO posterior chains", "alpha-derived mass or membership", "t_rh", "t_diss"],
        "next_gate": "independent 3-D deprojection plus >=2000-draw orbit propagation before CLOCK_FREEZE",
    }
    (args.out / "outcome_blind_dynamics_pilot_provenance.json").write_text(json.dumps(report, indent=2) + "\n")
    (args.out / "outcome_blind_dynamics_pilot.md").write_text(
        "\n".join([
            "# Outcome-blind dynamics pilot catalogue", "",
            f"Status: **{report['status']}**; {report['n_rows']} matched systems.", "",
            f"Member reconstruction is available for {report['n_member_ok']} systems and preferred (>=3 member RVs) for {report['n_rv_preferred']}.",
            f"The checked-in orbit table has {report['n_orbit_confirmatory']} systems meeting the confirmatory MC threshold; this is expected to be zero for the two-draw path test.",
            "The catalogue contains no MiMO alpha, chain, or alpha-derived quantity. It is not a physical-clock result: the radius is projected, orbit propagation is pilot-scale, and t_rh/t_diss are intentionally absent.",
            "A CLOCK_FREEZE file must not be created until independent 3-D deprojection and >=2000-draw orbit propagation pass the pre-registered gates.",
        ]) + "\n"
    )
    print(json.dumps({k: report[k] for k in ("status", "n_rows", "n_member_ok", "n_rv_preferred", "n_orbit_confirmatory")}, indent=2))


if __name__ == "__main__":
    main()
