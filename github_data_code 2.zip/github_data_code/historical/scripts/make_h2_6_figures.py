#!/usr/bin/env python3
"""Create the frozen H2.6 weighting-path figure from audit outputs."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from PIL import Image

ROOT=Path('outputs/h2_6_weighting_audit'); OUT=ROOT/'figure_h2_6_weighting_path.png'
path=pd.read_csv(ROOT/'weight_tempering_path.csv'); comp=pd.read_csv(ROOT/'W0_W3_comparison.csv')
cat=pd.read_csv('outputs/h_mimo_summary/catalog_summary.csv'); w=(1/np.maximum((cat.alpha84-cat.alpha16)/2,.02)**2); w=w/w.max()
fig,(ax0,ax1)=plt.subplots(1,2,figsize=(9.2,3.8),layout='constrained')
ax0.plot(path.kappa,path.beta1,'o-',color='#0072B2',lw=2,ms=4)
for lab,col in [('W2_random_effects_point','#D55E00'),('W3_full_joint_chain','#009E73')]:
 r=comp[comp.model==lab].iloc[0]; ax0.axhline(r.beta1,color=col,ls='--',lw=1.5,label=f'{lab}: {r.beta1:.3f}')
ax0.set(xlabel=r'weight tempering $\kappa$',ylabel=r'linear slope $\beta_1$',title='Weighting path'); ax0.set_xlim(0,1); ax0.grid(alpha=.2); ax0.legend(frameon=False,fontsize=8)
ax1.scatter(cat.logage50,cat.alpha50,s=10+75*w,c=w,cmap='viridis',alpha=.7,edgecolors='none')
ax1.set(xlabel=r'$\log_{10}(age/yr)$',ylabel=r'$\alpha$',title='Precision weights'); ax1.grid(alpha=.2)
fig.savefig(OUT,dpi=240,facecolor='white',edgecolor='white'); plt.close(fig)
with Image.open(OUT) as im: im.convert('RGB').save(OUT,format='PNG',dpi=(240,240))
print(OUT)
