#!/usr/bin/env python3
"""Verify that stored Rcurrent corresponds to the observed t=0 phase space."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from galpy.orbit import Orbit

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--astrometry", type=Path, default=ROOT / "outputs/phase4/astrometric_covariance.csv")
    ap.add_argument("--draws", type=Path, default=ROOT / "outputs/phase4/orbit_draws")
    ap.add_argument("--out", type=Path, default=ROOT / "outputs/phase4")
    ap.add_argument("--max-clusters", type=int, default=20)
    args = ap.parse_args(); args.out.mkdir(parents=True, exist_ok=True)
    ast = pd.read_csv(args.astrometry).set_index("hunt_id")
    deltas = []
    used = 0
    for path in sorted(args.draws.glob("hunt_*.npz")):
        hid = int(path.stem.split("_")[1])
        if hid not in ast.index:
            continue
        d = np.load(path); n = min(100, len(d["Rcurrent_kpc"]))
        r = ast.loc[hid]
        vxvv = np.column_stack([np.full(n, r.RA_deg), np.full(n, r.Dec_deg),
                                d["distance_pc"][:n] / 1000.0, d["pmRA_masyr"][:n],
                                d["pmDec_masyr"][:n], d["RVsys_kms"][:n]])
        orbit = Orbit(vxvv, radec=True, ro=8.2, vo=232.0, zo=0.0208,
                      solarmotion=[11.1, 12.24, 7.25])
        direct = np.asarray(orbit.R(), dtype=float)
        stored = d["Rcurrent_kpc"][:n]
        deltas.extend(np.abs(direct - stored).tolist())
        used += 1
        if used >= args.max_clusters:
            break
    max_delta = float(np.max(deltas)) if deltas else np.nan
    report = {"status": "PASS_ORBIT_EPOCH" if deltas and max_delta < 1e-8 else "FAIL_ORBIT_EPOCH",
              "n_clusters": used, "n_draws": len(deltas), "max_abs_Rcurrent_delta_kpc": max_delta,
              "criterion_kpc": 1e-8, "outcome_blind": True}
    (args.out / "orbit_epoch_validation.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
