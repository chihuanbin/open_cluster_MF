#!/usr/bin/env python3
"""Outcome-blind Phase-IV D1.5 reconciliation and power audit.

This script never opens MiMO chains and never dereferences alpha_mf.  The
published Z26 extraction in this workspace contains only trelax/DynAge, so a
literal R0 recipe replication is explicitly reported as provenance-blocked
instead of being reconstructed from the interrupted full-table transfer.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import spearmanr, t

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/phase4"
G = 4.498502151575286e-3


def rho(a, b):
    ok = np.isfinite(a) & np.isfinite(b)
    return float(spearmanr(np.asarray(a)[ok], np.asarray(b)[ok]).statistic) if ok.sum() >= 3 else np.nan


def trh(N, M, r, gamma=0.4):
    ok = (N > 1 / gamma) & (M > 0) & (r > 0)
    out = np.full(len(np.asarray(N)), np.nan)
    out[ok] = 0.138 * N[ok] / np.log(gamma * N[ok]) * np.sqrt(r[ok] ** 3 / (G * M[ok]))
    return out


def main():
    m = pd.read_csv(OUT / "member_dynamics_summary.csv")
    a = pd.read_parquet(OUT / "CLOCK_FREEZE_A.parquet")
    b = pd.read_parquet(OUT / "CLOCK_FREEZE_B.parquet")
    d = m.merge(a, on=["hunt_id"], suffixes=("_member", "_a"), validate="one_to_one")
    d = d.merge(b[["hunt_id", "log_age_50", "eta_diss_50", "eta_diss_apo_50", "eta_diss_orbavg_50"]], on="hunt_id", validate="one_to_one")
    ext = d["trh_external_Zhang26_Myr"].to_numpy(float)

    # A transparent candidate ladder.  R0 here is the published comparator,
    # not a claimed exact replication; required Z26 fields are unavailable.
    r0 = trh(d.hunt_NJ.to_numpy(float), d.hunt_MassJ.to_numpy(float), d.hunt_r50pc.to_numpy(float) * 4 / 3)
    r1 = trh(d.hunt_NJ.to_numpy(float), d.hunt_MassJ.to_numpy(float), d.Rh_mass_proj_pc.to_numpy(float) * 4 / 3)
    r2 = trh(d.N_eff_inrj.to_numpy(float), d.hunt_MassJ.to_numpy(float), d.Rh_mass_proj_pc.to_numpy(float) * 4 / 3)
    r3 = trh(d.N_eff_inrj.to_numpy(float), d.M_obs_prob_M50.to_numpy(float), d.Rh_mass_proj_pc.to_numpy(float) * 4 / 3)
    ladder = {}
    for name, x, y in [("R0_R1", r0, r1), ("R1_R2", r1, r2), ("R2_R3", r2, r3)]:
        ok = np.isfinite(x) & np.isfinite(y)
        dz = np.log10(y[ok] / x[ok])
        ladder[name] = {"n": int(ok.sum()), "rho": rho(x, y), "median_delta_log10": float(np.median(dz)),
                        "median_abs_delta_log10": float(np.median(abs(dz)))}
    exact = {"status": "BLOCKED_MISSING_Z26_STRUCTURAL_FIELDS", "required": ["r50Jpc", "NJ", "MassJ", "mean stellar mass", "published constants"],
             "available_extraction": "clocks.tsv contains only ID, Name, trelax, DynAge; clusters.partial.tsv is interrupted and not used"}

    # Dissolution prescription stability (all are frozen, outcome-blind).
    ds = {}
    for col in ["tdiss_bm03_apo_Myr_50", "tdiss_orbit_average_Myr_50", "tdiss_observed_only_Myr_50"]:
        x = d.tdiss_li_current_Myr_50.to_numpy(float); y = d[col].to_numpy(float)
        ok = np.isfinite(x) & np.isfinite(y) & (x > 0) & (y > 0)
        dz = np.log10(y[ok] / x[ok])
        ds[col] = {"n": int(ok.sum()), "rho_vs_li_current": rho(x, y),
                   "median_abs_delta_log10": float(np.median(abs(dz)))}

    # D_perp cluster bootstrap on frozen predictor medians.
    tau = d.log_age_50.to_numpy(float); eta = d.eta_diss_50.to_numpy(float)
    X = np.column_stack([np.ones(len(tau)), tau, (tau - tau.mean()) ** 2])
    resid = eta - X @ np.linalg.lstsq(X, eta, rcond=None)[0]
    dperp = float(np.quantile(resid, .90) - np.quantile(resid, .10))
    rng = np.random.default_rng(20260907)
    boots = np.empty(5000)
    for i in range(len(boots)):
        ix = rng.integers(0, len(tau), len(tau)); tt = tau[ix]; ee = eta[ix]
        xx = np.column_stack([np.ones(len(tt)), tt, (tt - tt.mean()) ** 2])
        rr = ee - xx @ np.linalg.lstsq(xx, ee, rcond=None)[0]
        boots[i] = np.quantile(rr, .90) - np.quantile(rr, .10)
    boot = {"n": 5000, "d_perp": dperp, "q025": float(np.quantile(boots,.025)), "q50": float(np.quantile(boots,.5)), "q975": float(np.quantile(boots,.975)), "formal_gate": "FAIL (<0.3000 dex)"}

    # Synthetic outcome-blind power: age quadratic + gamma*z(exposure) + N(0,1).
    # Standardise the *fixed-age residual* so gamma_star is interpretable as
    # outcome SD per one SD of orthogonal exposure leverage.
    zeta_raw = eta - X @ np.linalg.lstsq(X, eta, rcond=None)[0]
    zeta = zeta_raw / zeta_raw.std(ddof=1)
    Z = np.column_stack([np.ones(len(tau)), tau, (tau - tau.mean()) ** 2, zeta])
    X0 = Z[:, :3]; out_power = []
    for gam in [0, .2, .4, .6, .8, 1.0]:
        hit_t = hit_elpd = 0
        for _ in range(1000):
            y = X0 @ rng.normal(size=3) + gam * zeta + rng.normal(size=len(tau))
            b1 = np.linalg.lstsq(Z, y, rcond=None)[0]; e1 = y - Z @ b1
            b0 = np.linalg.lstsq(X0, y, rcond=None)[0]; e0 = y - X0 @ b0
            s2 = np.sum(e1**2) / (len(y) - Z.shape[1]); cov = s2 * np.linalg.inv(Z.T @ Z)
            se = np.sqrt(cov[3,3]); stat = b1[3] / se
            hit_t += stat > t.ppf(.975, len(y) - Z.shape[1])
            # Gaussian held-out proxy: likelihood gain and its conventional 2SE.
            gain = len(y) * np.log(np.sum(e0**2) / np.sum(e1**2)) / 2
            se_gain = np.sqrt(2 * len(y))
            hit_elpd += gain > 2 * se_gain
        out_power.append({"gamma_star": gam, "n_sim": 1000, "power_Pgamma_gt_0975": hit_t / 1000, "power_deltaELPD_gt_2SE": hit_elpd / 1000})

    result = {"status": "D1.5_BORDERLINE_UNRESOLVED", "outcome_blind": True, "alpha_read": False,
              "exact_R0": exact, "relaxation_ladder": ladder, "dissolution_stability": ds,
              "fixed_age_bootstrap": boot, "synthetic_power": out_power,
              "power_elpd_method": "Gaussian likelihood-gain proxy, not PSIS-LOO; use only as a pre-outcome characterization",
              "decision": "Do not unlock alpha; retain original D_perp and rho gates as strict FAIL; do not call Phase IV physical NO-GO."}
    (OUT / "D1_5_RECONCILIATION.json").write_text(json.dumps(result, indent=2) + "\n")
    lines = ["# D1.5 relaxation-clock reconciliation", "", "Status: **D1.5_BORDERLINE_UNRESOLVED**.", "", "No MiMO alpha or posterior chain was read.", "", "## R0 provenance", "", "Exact Z26 recipe replication: **BLOCKED** because the local extraction lacks the required structural fields; the interrupted partial transfer was not used.", "", "## Results", "", f"Fixed-age D_perp = {dperp:.6f} dex; formal 0.3000-dex gate remains **FAIL**; bootstrap 95% interval [{boot['q025']:.6f}, {boot['q975']:.6f}]."]
    for k,v in ladder.items(): lines.append(f"- {k}: rho={v['rho']:.4f}, median delta={v['median_delta_log10']:.4f} dex, median |delta|={v['median_abs_delta_log10']:.4f} dex")
    for k,v in ds.items(): lines.append(f"- dissolution {k}: rho={v['rho_vs_li_current']:.4f}, median |delta|={v['median_abs_delta_log10']:.4f} dex")
    lines += ["", "Synthetic power results are in `D1_5_RECONCILIATION.json`; all simulations use synthetic outcomes and never the real alpha outcome."]
    (OUT / "D1_5_RECONCILIATION.md").write_text("\n".join(lines) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
