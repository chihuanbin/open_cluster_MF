#!/usr/bin/env python3
"""H2.6 weighting--estimand audit.

The audit is deliberately about estimands, not added model dimensions. It
quantifies inverse-variance weight concentration, traces the linear slope as
weights are tempered, compares measurement-only and random-effects point
likelihoods with the exact joint-chain hierarchy, and runs a broken-truth
projection closure. The broken simulations use the current broken pilot as a
stress truth and are therefore a mechanism diagnostic, not a scientific
measurement.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import logsumexp

from h2_5_decomposition import load_raw_chains, log_normal
from hierarchical_mimo_summary import read_catalog


def gini(x):
    x = np.sort(np.asarray(x, float)); n = len(x)
    return float((2 * np.arange(1, n + 1) - n - 1) @ x / (n * x.sum()))


def linear_fit(d, kappa=1.0, sigma_int=None):
    x = d.logage50.to_numpy() - 8.5; y = d.alpha50.to_numpy(); sy = np.maximum((d.alpha84.to_numpy()-d.alpha16.to_numpy())/2, .02)
    if sigma_int is None:
        w = sy ** (-2 * kappa)
    else:
        w = 1.0 / (sy * sy + sigma_int * sigma_int)
    X = np.column_stack([np.ones(len(x)), x]); b = np.linalg.solve(X.T @ (w[:, None] * X), X.T @ (w*y))
    return float(b[0]), float(b[1])


def random_effects_point(d):
    x=d.logage50.to_numpy()-8.5; y=d.alpha50.to_numpy(); sy=np.maximum((d.alpha84.to_numpy()-d.alpha16.to_numpy())/2,.02)
    def nll(p):
        b0,b1,ls=p; sig=np.exp(ls); var=sy*sy+sig*sig; z=(y-b0-b1*x)/np.sqrt(var); return .5*np.sum(z*z+np.log(2*np.pi*var))
    r=minimize(nll,[-2,.5,np.log(.5)],method='L-BFGS-B',bounds=[(-5,1),(-3,3),(np.log(.005),np.log(2))])
    return {'beta0':float(r.x[0]),'beta1':float(r.x[1]),'sigma_int':float(np.exp(r.x[2])),'success':bool(r.success),'nfev':int(r.nfev)}


def broken_mean(tau,p):
    y0,a1,a2,x0,ls=p[:5]; s=np.exp(ls); return y0+a1*(tau-x0)+(a2-a1)*np.logaddexp(0,s*(tau-x0))/s


def broken_point_fit(tau,y,sy,weighted):
    if weighted:
        # Measurement-only inverse-variance projection; sigma is fixed to a
        # negligible numerical floor to expose the estimand.
        def nll(p):
            z=(y-broken_mean(tau,p))/np.maximum(sy,.02); return .5*np.sum(z*z+np.log(2*np.pi*np.maximum(sy,.02)**2))
    else:
        def nll(p):
            z=y-broken_mean(tau,p); return .5*np.sum(z*z)
    start=np.array([-2.48,-.23,3.0,8.83,np.log(5.9)])
    r=minimize(nll,start,method='Powell',bounds=[(-5,1),(-5,3),(-5,5),(7,10.2),(np.log(.1),np.log(80))],options={'maxiter':260,'xtol':2e-4,'ftol':2e-4})
    return {'x0':float(r.x[3]),'a1':float(r.x[1]),'a2':float(r.x[2]),'success':bool(r.success)}


def main():
    p=argparse.ArgumentParser(); p.add_argument('--catalog',type=Path,default=Path('data/mimo_catalog/table3.dat')); p.add_argument('--chain-dir',type=Path,default=Path('data/mimo_chains_prime')); p.add_argument('--output-dir',type=Path,default=Path('outputs/h2_6_weighting_audit')); p.add_argument('--n-sim',type=int,default=1000); p.add_argument('--seed',type=int,default=20260906); p.add_argument('--force',action='store_true')
    a=p.parse_args(); out=a.output_dir; out.mkdir(parents=True,exist_ok=True)
    if (out/'report.md').exists() and not a.force: raise SystemExit('Output exists; pass --force')
    d=read_catalog(a.catalog,prime_only=True); sy=np.maximum((d.alpha84.to_numpy()-d.alpha16.to_numpy())/2,.02); tau=d.logage50.to_numpy(); alpha=d.alpha50.to_numpy()
    raw_w=sy**-2; w=raw_w/raw_w.sum(); order=np.argsort(w)[::-1]; metrics={'n_clusters':len(d),'n_eff':float(1/np.sum(w*w)),'top5_fraction':float(w[order[:5]].sum()),'top10_fraction':float(w[order[:10]].sum()),'gini':gini(w),'rho_weight_logage':float(np.corrcoef(w,tau)[0,1]),'rho_weight_alpha':float(np.corrcoef(w,alpha)[0,1])}
    # equal-weight residual reference
    b_ec=linear_fit(d,0); resid=alpha-(b_ec[0]+b_ec[1]*(tau-8.5)); metrics['rho_weight_equal_linear_residual']=float(np.corrcoef(w,resid)[0,1]); pd.DataFrame([metrics]).to_csv(out/'weight_metrics.csv',index=False)
    path=[]
    for k in np.linspace(0,1,11):
        b=linear_fit(d,float(k)); path.append({'kappa':float(k),'beta0':b[0],'beta1':b[1]})
    pd.DataFrame(path).to_csv(out/'weight_tempering_path.csv',index=False)
    # W0--W3 comparison. W3 is read from the exact joint-chain H2.5 result.
    chains=load_raw_chains(d,a.chain_dir)
    w0=linear_fit(d,0); w1=linear_fit(d,1); w2=random_effects_point(d)
    def joint_nll(p):
        sig=np.exp(p[-1]); total=0
        for c in chains: total-=float(logsumexp(c['logw']+log_normal(c['alpha'],p[0]+p[1]*(c['tau']-8.5),sig)))
        return total
    r3=minimize(joint_nll,[-2,.5,np.log(.5)],method='Nelder-Mead',options={'maxiter':400,'xatol':2e-5,'fatol':2e-5}); w3={'beta0':float(r3.x[0]),'beta1':float(r3.x[1]),'sigma_int':float(np.exp(r3.x[2]))}
    pd.DataFrame([{'model':'W0_equal_cluster','beta0':w0[0],'beta1':w0[1],'sigma_int':np.nan},{'model':'W1_measurement_only_IV','beta0':w1[0],'beta1':w1[1],'sigma_int':np.nan},{'model':'W2_random_effects_point','beta0':w2['beta0'],'beta1':w2['beta1'],'sigma_int':w2['sigma_int']},{'model':'W3_full_joint_chain','beta0':w3['beta0'],'beta1':w3['beta1'],'sigma_int':w3['sigma_int']}]).to_csv(out/'W0_W3_comparison.csv',index=False)
    # Broken-truth projection closure.
    truth=np.array([-2.478070147152565,-.23249443031964,3.0,8.830097125920625,np.log(5.868546176951814)])
    sig_truth=.3164438442162121; rng=np.random.default_rng(a.seed); sim=[]
    for rep in range(a.n_sim):
        ytrue=broken_mean(tau,truth)+rng.normal(0,sig_truth,len(d)); y=ytrue+rng.normal(0,sy)
        xiv=linear_fit(pd.DataFrame({'logage50':tau,'alpha50':y,'alpha16':y-sy,'alpha84':y+sy}),1)[1]
        xec=linear_fit(pd.DataFrame({'logage50':tau,'alpha50':y,'alpha16':y-sy,'alpha84':y+sy}),0)[1]
        biv=broken_point_fit(tau,y,sy,True); bec=broken_point_fit(tau,y,sy,False)
        sim.append({'rep':rep,'beta_iv':xiv,'beta_ec':xec,'x0_iv':biv['x0'],'x0_ec':bec['x0'],'a2_iv':biv['a2'],'a2_ec':bec['a2']})
    s=pd.DataFrame(sim); s.to_csv(out/'broken_truth_replicates.csv',index=False)
    simsum={'n_sim':a.n_sim,'truth_x0':truth[3],'truth_beta_linear_not_defined':True,'beta_iv_mean':float(s.beta_iv.mean()),'beta_ec_mean':float(s.beta_ec.mean()),'beta_iv_median':float(s.beta_iv.median()),'beta_ec_median':float(s.beta_ec.median()),'x0_iv_median':float(s.x0_iv.median()),'x0_ec_median':float(s.x0_ec.median()),'x0_iv_ec_median_difference':float(s.x0_iv.median()-s.x0_ec.median()),'x0_iv_q025':float(s.x0_iv.quantile(.025)),'x0_iv_q975':float(s.x0_iv.quantile(.975)),'x0_ec_q025':float(s.x0_ec.quantile(.025)),'x0_ec_q975':float(s.x0_ec.quantile(.975))}
    (out/'broken_truth_summary.json').write_text(json.dumps(simsum,indent=2)+'\n')
    prov={'status':'H2.6-COMPLETE-PILOT','n_clusters':len(d),'n_sim':a.n_sim,'seed':a.seed,'W3_engine':'raw logwt logsumexp','broken_truth':'joint-broken pilot MAP, a2 boundary retained at 3.0','caveat':'broken-truth projection fit is a mechanism audit; final H2.7 boundary and full hyperposterior remain pending'}
    (out/'provenance.json').write_text(json.dumps(prov,indent=2)+'\n')
    report=f'''# H2.6 Weighting--Estimand Audit

Status: **`H2.6-COMPLETE-PILOT`** on {len(d)} MF Prime clusters.

## Weight concentration

N_eff={metrics['n_eff']:.1f}; top-5 fraction={metrics['top5_fraction']:.3f}; top-10 fraction={metrics['top10_fraction']:.3f}; Gini={metrics['gini']:.3f}; rho(weight, log-age)={metrics['rho_weight_logage']:.3f}; rho(weight, alpha)={metrics['rho_weight_alpha']:.3f}; rho(weight, equal-cluster residual)={metrics['rho_weight_equal_linear_residual']:.3f}.

The complete kappa path is in `weight_tempering_path.csv` (kappa=0 equal-cluster, kappa=1 measurement-only inverse variance).

## W0--W3

`W0_W3_comparison.csv` compares equal-cluster, measurement-only, point random-effects, and exact joint-chain fits. The point random-effects likelihood uses variance $s_{{\\alpha,j}}^2+\\sigma_{{\\rm int}}^2$.

## Broken-truth closure

The fixed broken truth uses the joint pilot MAP (x0={truth[3]:.4f}, a1={truth[1]:.4f}, a2={truth[2]:.1f}, sigma={sig_truth:.4f}). Across {a.n_sim} simulations, the linear projections and recovered x0 distributions are in `broken_truth_summary.json`. This is a closure diagnostic, not a chronology measurement.
'''
    (out/'report.md').write_text(report)
    print(json.dumps({'status':prov['status'],'metrics':metrics,'W0_W3':pd.DataFrame([{'model':'W0','beta1':w0[1]},{'model':'W1','beta1':w1[1]},{'model':'W2','beta1':w2['beta1']},{'model':'W3','beta1':w3['beta1']}]).to_dict('records'),'broken_truth':simsum},indent=2))

if __name__=='__main__': main()
