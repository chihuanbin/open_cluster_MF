#!/usr/bin/env python3
"""Merge MiMO age only with CLOCK_FREEZE_A and create CLOCK_FREEZE_B.

This predictor-stage program accesses exactly two posterior-chain columns:
``log_age`` and ``logwt``. It never accesses ``alpha_mf``. Exposure draws and
the pre-outcome collinearity/identifiability gate are frozen before outcome
unlock.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd
from astropy.io import fits
from scipy.special import logsumexp
from scipy.stats import spearmanr

ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def norm(x: object) -> str:
    return re.sub(r"[^a-z0-9]", "", str(x).lower())


def weighted_age_draws(path: Path, n: int, rng: np.random.Generator) -> tuple[np.ndarray, np.ndarray]:
    with fits.open(path, memmap=True) as hdul:
        data = hdul[1].data
        # Outcome lock: these are the only FITS fields dereferenced.
        age = np.asarray(data["log_age"], dtype=float)
        logwt = np.asarray(data["logwt"], dtype=float)
    ok = np.isfinite(age) & np.isfinite(logwt)
    raw_index = np.flatnonzero(ok)
    age, logwt = age[ok], logwt[ok]
    prob = np.exp(logwt - logsumexp(logwt))
    local_index = rng.choice(len(age), size=n, replace=True, p=prob)
    return age[local_index], raw_index[local_index]


def q3(a: np.ndarray) -> tuple[float, float, float]:
    return tuple(map(float, np.quantile(a, [0.16, 0.50, 0.84])))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--freeze-a", type=Path, default=ROOT / "outputs/phase4/CLOCK_FREEZE_A.parquet")
    ap.add_argument("--clock-draws", type=Path, default=ROOT / "outputs/phase4/clock_draws")
    ap.add_argument("--chains", type=Path, default=ROOT / "data/mimo_chains_prime")
    ap.add_argument("--out", type=Path, default=ROOT / "outputs/phase4")
    ap.add_argument("--seed", type=int, default=20260906)
    args = ap.parse_args(); args.out.mkdir(parents=True, exist_ok=True)
    freeze = pd.read_parquet(args.freeze_a) if args.freeze_a.suffix == ".parquet" else pd.read_csv(args.freeze_a)
    chain_map = {norm(p.stem.removeprefix("post_chain_")): p for p in args.chains.glob("post_chain_*.fits")}
    rng = np.random.default_rng(args.seed)
    exposure_dir = args.out / "exposure_draws"; exposure_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    used_chains = []
    for _, row in freeze.sort_values("hunt_id").iterrows():
        chain = chain_map.get(norm(row.cluster))
        clock_path = args.clock_draws / f"hunt_{int(row.hunt_id):04d}.npz"
        if chain is None or not clock_path.exists():
            continue
        cd = np.load(clock_path)
        n = len(cd["trh_primary_Myr"])
        age, chain_row_index = weighted_age_draws(chain, n, rng)
        eta_rh = age - np.log10(cd["trh_primary_Myr"] * 1e6)
        eta_diss = age - np.log10(0.3 * cd["tdiss_li_current_Myr"] * 1e6)
        eta_diss_apo = age - np.log10(0.3 * cd["tdiss_bm03_apo_Myr"] * 1e6)
        eta_diss_orbavg = age - np.log10(0.3 * cd["tdiss_orbit_average_Myr"] * 1e6)
        np.savez_compressed(exposure_dir / f"hunt_{int(row.hunt_id):04d}.npz",
                            log_age=age, eta_rh=eta_rh, eta_diss=eta_diss,
                            eta_diss_apo=eta_diss_apo, eta_diss_orbavg=eta_diss_orbavg,
                            chain_row_index=chain_row_index)
        rec = row.to_dict()
        for name, arr in [("log_age", age), ("eta_rh", eta_rh),
                          ("eta_diss", eta_diss), ("eta_diss_apo", eta_diss_apo),
                          ("eta_diss_orbavg", eta_diss_orbavg)]:
            lo, med, hi = q3(arr)
            rec[f"{name}_16"] = lo; rec[f"{name}_50"] = med; rec[f"{name}_84"] = hi
        rows.append(rec); used_chains.append(chain)
    out = pd.DataFrame(rows)
    freeze_b = args.out / "CLOCK_FREEZE_B.parquet"
    out.to_parquet(freeze_b, index=False)

    tau = out.log_age_50.to_numpy(float)
    er = out.eta_rh_50.to_numpy(float); ed = out.eta_diss_50.to_numpy(float)
    eda = out.eta_diss_apo_50.to_numpy(float)
    # Outcome-blind quadratic residualisation; no alpha-adaptive smoothing.
    X = np.column_stack([np.ones(len(tau)), tau, np.square(tau - np.mean(tau))])
    residual = ed - X @ np.linalg.lstsq(X, ed, rcond=None)[0]
    residual_apo = eda - X @ np.linalg.lstsq(X, eda, rcond=None)[0]
    dynamic_range = float(np.quantile(residual, 0.90) - np.quantile(residual, 0.10))
    dynamic_range_apo = float(np.quantile(residual_apo, 0.90) - np.quantile(residual_apo, 0.10))
    status = "PASS_CLOCK_FREEZE_B_IDENTIFIABLE" if len(out) >= 120 and dynamic_range >= 0.3 else "IDENTIFIABILITY_BLOCKED"
    report = {
        "status": status, "outcome_locked": True, "n_clusters": int(len(out)),
        "allowed_chain_columns": ["log_age", "logwt"], "forbidden_outcome_column": "alpha_mf",
        "joint_posterior_preservation": "raw FITS row indices are frozen so future alpha unlock can preserve age-alpha pairing",
        "exposure_definitions": {"eta_rh": "log10(age/trh)",
                                 "eta_diss": "log10(age/[0.3*tdiss_Li_current])",
                                 "eta_diss_apo": "log10(age/[0.3*tdiss_BM03_apo])",
                                 "eta_diss_orbavg": "log10(age/[0.3*tdiss_orbit_average])"},
        "spearman": {"age_eta_rh": float(spearmanr(tau, er).statistic),
                     "age_eta_diss": float(spearmanr(tau, ed).statistic),
                     "eta_rh_eta_diss": float(spearmanr(er, ed).statistic)},
        "fixed_age_residual_P90_minus_P10_dex": dynamic_range,
        "fixed_age_residual_apo_P90_minus_P10_dex": dynamic_range_apo,
        "identifiability_threshold_dex": 0.3,
        "freeze_A": str(args.freeze_a), "freeze_A_sha256": sha256(args.freeze_a),
        "freeze_B": str(freeze_b), "freeze_B_sha256": sha256(freeze_b),
        "chain_manifest_sha256": hashlib.sha256("\n".join(f"{p.name}:{sha256(p)}" for p in sorted(used_chains)).encode()).hexdigest(),
        "exposure_draw_directory": str(exposure_dir),
    }
    (args.out / "CLOCK_PROVENANCE_B.json").write_text(json.dumps(report, indent=2) + "\n")
    (args.out / "CLOCK_FREEZE_B.sha256").write_text(f"{sha256(freeze_b)}  {freeze_b.name}\n")
    (args.out / "clock_freeze_B.md").write_text("\n".join([
        "# CLOCK FREEZE B: predictors only", "", f"Status: **{status}**; {len(out)} clusters.",
        f"Fixed-age dissolution-exposure P90-P10 range: {dynamic_range:.3f} dex (gate: >=0.3 dex).",
        "Only log_age and logwt were read from MiMO chains. alpha_mf remains locked and no alpha-clock statistic was calculated.",
        f"Frozen file SHA-256: `{sha256(freeze_b)}`.",
    ]) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
