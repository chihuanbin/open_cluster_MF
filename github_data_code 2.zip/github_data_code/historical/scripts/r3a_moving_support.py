#!/usr/bin/env python3
"""R3A moving-support estimand-drift falsification audit.

The generator contains an age-invariant mass function but changes the upper
observable mass support through a turn-off prescription.  The fitter is the
original single-alpha CMD mixture likelihood, with the correct age-dependent
support supplied.  This is deliberately a small audit, not a replacement
stellar-population model.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.special import logsumexp
from scipy.stats import norm
from PIL import Image


AGE_GRID = np.round(np.linspace(7.0, 9.7, 10), 1)
N_GRID = [80, 160, 320]
ALPHA_GRID = np.linspace(-4.0, -1.0, 31)
MASS_GRID = np.linspace(0.60, 8.0, 180)
M_LO = 0.60
G_LIMIT = 19.00
F_FIELD = 0.30
PRIMARY_SETTINGS = {
    "primary": {"fb": 0.30, "sig_g": 0.10, "sig_c": 0.035, "reps": 100},
}
SENSITIVITY_SETTINGS = {
    "fb_low": {"fb": 0.10, "sig_g": 0.10, "sig_c": 0.035, "reps": 50},
    "fb_high": {"fb": 0.50, "sig_g": 0.10, "sig_c": 0.035, "reps": 50},
    "phot_noisy": {"fb": 0.30, "sig_g": 0.16, "sig_c": 0.060, "reps": 50},
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def turnoff_mass(log_age: float) -> float:
    """Simple monotone turn-off prescription, bounded by the grid."""
    return float(np.clip(10.0 ** ((10.0 - log_age) / 3.3), 1.05, 8.0))


def stellar_means(mass: np.ndarray, log_age: float) -> tuple[np.ndarray, np.ndarray]:
    # Analytic isochrone surrogate: age changes the turn-off support and gives
    # a small, known colour shift, while mass controls the main sequence.
    g = 17.80 - 2.50 * np.log10(mass)
    colour = 1.10 - 0.28 * np.log10(mass) + 0.025 * (log_age - 8.0)
    return g, colour


def truth_logweights(mass: np.ndarray, family: str) -> np.ndarray:
    x = np.log(mass)
    if family == "T0":
        logw = -2.30 * x
    elif family.startswith("T1_c"):
        c = float(family.split("c")[-1])
        logw = -2.30 * x + c * x * x
    elif family == "T2_broken":
        mb, a1, a2 = 1.20, -1.80, -3.00
        logw = np.where(mass <= mb, a1 * x, a1 * np.log(mb) + a2 * (x - np.log(mb)))
    else:
        raise ValueError(f"unknown truth family: {family}")
    return logw - logsumexp(logw)


def log_gauss_2d(x: np.ndarray, mean: np.ndarray, sd: np.ndarray) -> np.ndarray:
    z = (x - mean) / sd
    return -0.5 * np.sum(z * z, axis=-1) - np.log(2.0 * np.pi * np.prod(sd))


def cluster_logpdf(cmd: np.ndarray, alpha: float, log_age: float, fb: float, sig_g: float, sig_c: float) -> np.ndarray:
    m = MASS_GRID[MASS_GRID <= turnoff_mass(log_age)]
    w = m ** alpha
    w /= np.sum(w)
    g, c = stellar_means(m, log_age)
    means = np.column_stack([g, c])
    sd = np.array([sig_g, sig_c])
    cmd_rep = np.broadcast_to(cmd[:, None, :], (len(cmd), len(m), 2))
    means_rep = np.broadcast_to(means[None, :, :], (len(cmd), len(m), 2))
    d_single = log_gauss_2d(cmd_rep, means_rep, sd)
    binary_means = means + np.array([-0.70, 0.16])
    binary_rep = np.broadcast_to(binary_means[None, :, :], (len(cmd), len(m), 2))
    d_binary = log_gauss_2d(cmd_rep, binary_rep, sd * 1.25)
    single = logsumexp(d_single + np.log(w)[None, :], axis=1)
    binary = logsumexp(d_binary + np.log(w)[None, :], axis=1)
    return np.logaddexp(np.log1p(-fb) + single, np.log(fb) + binary)


def field_logpdf(cmd: np.ndarray) -> np.ndarray:
    # Broad, fixed field component; field fraction is fixed in this audit so
    # that any trend is attributable to the mass-support parameterization.
    return log_gauss_2d(cmd, np.array([16.9, 1.35]), np.array([1.35, 0.60]))


def simulate(rng: np.random.Generator, n_cl: int, log_age: float, family: str, fb: float, sig_g: float, sig_c: float) -> tuple[np.ndarray, np.ndarray]:
    mmax = turnoff_mass(log_age)
    support = MASS_GRID[MASS_GRID <= mmax]
    p = np.exp(truth_logweights(support, family))
    masses = rng.choice(support, size=n_cl, p=p)
    g, c = stellar_means(masses, log_age)
    binary = rng.random(n_cl) < fb
    g[binary] -= 0.70
    c[binary] += 0.16
    cluster = np.column_stack([g + rng.normal(0, sig_g, n_cl), c + rng.normal(0, sig_c, n_cl)])
    n_field = int(round(n_cl * F_FIELD / (1.0 - F_FIELD)))
    field = rng.normal([16.9, 1.35], [1.35, 0.60], size=(n_field, 2))
    # Apply a fixed magnitude limit before the noise-free catalogue is passed
    # to the likelihood.  The selected mass support is then known to both
    # generator and fitter; the stochastic photometric errors are retained.
    observed = np.vstack([cluster, field])
    observed = observed[observed[:, 0] <= G_LIMIT]
    return observed, np.r_[np.ones(len(cluster), dtype=bool), np.zeros(n_field, dtype=bool)][np.flatnonzero(np.r_[cluster[:, 0], field[:, 0]] <= G_LIMIT)]


def fit_single_alpha(cmd: np.ndarray, log_age: float, fb: float, sig_g: float, sig_c: float) -> tuple[float, float, float, float]:
    # The likelihood uses the exact single-alpha model family, including the
    # age-dependent upper support and fixed observed field fraction.
    if len(cmd) == 0:
        return np.nan, np.nan, np.nan, np.nan
    logp = np.empty(len(ALPHA_GRID))
    log_field = field_logpdf(cmd)
    for i, alpha in enumerate(ALPHA_GRID):
        log_cl = cluster_logpdf(cmd, alpha, log_age, fb, sig_g, sig_c)
        logp[i] = np.sum(np.logaddexp(np.log1p(-F_FIELD) + log_cl, np.log(F_FIELD) + log_field))
    marg = np.exp(logp - logsumexp(logp))
    mean = float(np.sum(ALPHA_GRID * marg))
    cdf = np.cumsum(marg)
    lo = float(np.interp(0.025, cdf, ALPHA_GRID)); hi = float(np.interp(0.975, cdf, ALPHA_GRID))
    sigma = float(np.sqrt(np.sum(marg * (ALPHA_GRID - mean) ** 2)))
    return mean, lo, hi, sigma


def oracle_alpha(cmd: np.ndarray, labels: np.ndarray, log_age: float, fb: float, sig_g: float, sig_c: float) -> tuple[float, float, float, float]:
    x = cmd[labels]
    logp = np.array([np.sum(cluster_logpdf(x, a, log_age, fb, sig_g, sig_c)) for a in ALPHA_GRID])
    marg = np.exp(logp - logsumexp(logp)); mean = float(np.sum(ALPHA_GRID * marg)); cdf = np.cumsum(marg)
    lo = float(np.interp(0.025, cdf, ALPHA_GRID)); hi = float(np.interp(0.975, cdf, ALPHA_GRID)); sigma = float(np.sqrt(np.sum(marg * (ALPHA_GRID - mean) ** 2)))
    return mean, lo, hi, sigma


def run(args: argparse.Namespace) -> tuple[pd.DataFrame, dict]:
    rng = np.random.default_rng(args.seed)
    families = ["T0", "T1_c0.1", "T1_c0.2", "T1_c0.3", "T2_broken"]
    settings = dict(PRIMARY_SETTINGS)
    if not args.primary_only:
        settings.update(SENSITIVITY_SETTINGS)
    records: list[dict] = []
    for setting, cfg in settings.items():
        reps = args.reps if setting == "primary" else args.sens_reps
        for family in families:
            for n_cl in N_GRID:
                for log_age in AGE_GRID:
                    for rep in range(reps):
                        cmd, labels = simulate(rng, n_cl, log_age, family, cfg["fb"], cfg["sig_g"], cfg["sig_c"])
                        fit = fit_single_alpha(cmd, log_age, cfg["fb"], cfg["sig_g"], cfg["sig_c"])
                        ora = oracle_alpha(cmd, labels, log_age, cfg["fb"], cfg["sig_g"], cfg["sig_c"])
                        for model, vals in (("single_alpha", fit), ("oracle", ora)):
                            records.append({"setting": setting, "family": family, "N_cl": n_cl, "log_age": log_age, "rep": rep, "model": model, "alpha_hat": vals[0], "lo": vals[1], "hi": vals[2], "sigma": vals[3]})
    raw = pd.DataFrame(records)
    return raw, {"families": families, "settings": settings}


def main() -> None:
    p = argparse.ArgumentParser(); p.add_argument("--output-dir", type=Path, default=Path("outputs/r3a_moving_support")); p.add_argument("--reps", type=int, default=100); p.add_argument("--sens-reps", type=int, default=50); p.add_argument("--seed", type=int, default=20260906); p.add_argument("--primary-only", action="store_true"); p.add_argument("--force", action="store_true")
    args = p.parse_args(); out = args.output_dir; out.mkdir(parents=True, exist_ok=True)
    if (out / "report.md").exists() and not args.force: raise SystemExit("Output exists; pass --force after checking prior run")
    raw, meta = run(args); raw.to_csv(out / "r3a_results.csv", index=False)
    summary = raw.groupby(["setting", "family", "N_cl", "log_age", "model"], as_index=False).agg(alpha_hat=("alpha_hat", "mean"), lo=("lo", "mean"), hi=("hi", "mean"), sigma=("sigma", "mean"), n=("alpha_hat", "count"))
    summary.to_csv(out / "r3a_age_summary.csv", index=False)
    primary = summary[summary.setting == "primary"]
    curves = primary.groupby(["family", "N_cl", "model"], as_index=False).agg(dynamic_range=("alpha_hat", lambda x: float(x.max() - x.min())), mean_alpha=("alpha_hat", "mean"), mean_sigma=("sigma", "mean"))
    curves.to_csv(out / "r3a_dynamic_ranges.csv", index=False)
    t0 = curves[curves.family == "T0"]
    t0_pass = bool((t0.dynamic_range < 0.10).all())
    main_curves = curves[curves.family.isin(["T1_c0.1", "T1_c0.2", "T1_c0.3", "T2_broken"]) & (curves.model == "single_alpha")]
    main_go = bool((main_curves.dynamic_range > 0.20).any())
    robust = bool((main_curves.dynamic_range > 0.20).mean() >= 0.50)
    status = "GO-PILOT" if t0_pass and main_go and robust else "NO-GO"
    fig, axes = plt.subplots(1, 3, figsize=(11, 3.8), sharey=True, layout="constrained")
    panels = [("T0", "T0 exact-null"), ("T1_c0.3", "T1 curvature (c=0.3)"), ("T2_broken", "T2 fixed broken MF")]
    colours = {40: "#0072B2", 80: "#D55E00", 160: "#009E73"}
    for ax, (family, title) in zip(axes, panels):
        for n_cl, color in colours.items():
            d = primary[(primary.family == family) & (primary.N_cl == n_cl) & (primary.model == "single_alpha")].sort_values("log_age")
            ax.plot(d.log_age, d.alpha_hat, "o-", color=color, ms=3.5, label=f"N={n_cl}")
            o = primary[(primary.family == family) & (primary.N_cl == n_cl) & (primary.model == "oracle")].sort_values("log_age")
            ax.plot(o.log_age, o.alpha_hat, "--", color=color, alpha=0.45, lw=1)
        ax.set_title(title, loc="left", weight="bold"); ax.set_xlabel("log age [yr]"); ax.grid(alpha=.2)
    axes[0].set_ylabel("Recovered single-α"); axes[-1].legend(frameon=False, fontsize=8, loc="best")
    fig.suptitle("R3A: invariant MF truth under moving observable mass support", fontsize=11)
    fig_path = out / "figure_r3a_moving_support.png"; fig.savefig(fig_path, dpi=220, facecolor="white", edgecolor="white", transparent=False); plt.close(fig)
    with Image.open(fig_path) as im: im.convert("RGB").save(fig_path, format="PNG", dpi=(220, 220))
    prov = {"seed": args.seed, "primary_reps": args.reps, "sensitivity_reps": args.sens_reps, "age_grid": AGE_GRID.tolist(), "N_grid": N_GRID, "families": meta["families"], "settings": meta["settings"], "M_LO": M_LO, "G_LIMIT": G_LIMIT, "F_FIELD": F_FIELD, "T0_control": "max primary dynamic range < 0.10", "main_GO": "any T1/T2 single-alpha dynamic range > 0.20 and >=50% primary curves pass", "status": status}
    (out / "provenance.json").write_text(json.dumps(prov, indent=2) + "\n")
    report = f"""# R3A moving-support estimand drift\n\n**Status: `{status}`.** Frozen audit with age-invariant truth families, 10 age points, three richness values, 100 primary realizations per setting, and 50 realizations per sensitivity setting.\n\nThe generator and fitter use the same analytic isochrone surrogate, binary prescription, fixed field fraction ({F_FIELD:.2f}), photometric-noise settings, and age-dependent turn-off support. Only the truth MF shape differs from the fitted single power law in T1/T2. The magnitude-limited support is fixed at M >= {M_LO:.2f} with G_limit={G_LIMIT:.2f}.\n\n## Frozen gates\n\n- T0 control: every primary T0 curve must have age dynamic range < 0.10.\n- Main GO-1: at least one T1/T2 curve must have dynamic range > 0.20; at least half of all primary T1/T2 curves must pass for robustness.\n- The oracle curves are included to separate membership/field effects from the single-alpha estimand effect.\n\nPrimary dynamic ranges are in `r3a_dynamic_ranges.csv`; age curves are in `r3a_age_summary.csv`; the figure is `figure_r3a_moving_support.png`.\n\n## Interpretation\n\nThe audit is intentionally limited to moving-support parameterization. It does not test field covariate shift, added astrometry, marked point processes, or a production common-support model. A `NO-GO` closes the remaining MiMO-parameterization route rather than justifying another model expansion.\n"""
    (out / "report.md").write_text(report)
    print(json.dumps({"status": status, "t0_control_pass": t0_pass, "main_go": main_go, "robust": robust, "primary_curves": int(len(curves))}, indent=2))


if __name__ == "__main__":
    main()
