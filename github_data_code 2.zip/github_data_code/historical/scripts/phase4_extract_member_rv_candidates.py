#!/usr/bin/env python3
"""Extract source-id keyed RV candidates for independent Phase-IV inputs.

The output is still outcome-blind.  It contains only HR24 member-table fields
and is intended for optional APOGEE/GALAH/LAMOST supplementation by Gaia
source_id.  No MiMO chain, alpha, or MF-derived quantity is read.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
S = {
    "id": (29, 33), "source_id": (34, 53), "inrj": (54, 55),
    "inrt": (56, 57), "prob": (58, 78), "ra": (79, 103),
    "dec": (126, 148), "rv": (920, 942), "e_rv": (943, 963),
    "varflag": (1075, 1088), "nss": (1089, 1090), "rvs": (1091, 1092),
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def text(line: bytes, sl: tuple[int, int]) -> str:
    return line[sl[0]:sl[1]].decode("ascii", errors="ignore").strip()


def num(line: bytes, sl: tuple[int, int]) -> float:
    try:
        x = text(line, sl)
        return float(x) if x and x != "?" else math.nan
    except ValueError:
        return math.nan


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--members", type=Path, default=ROOT / "hunt24/members_full.dat")
    ap.add_argument("--match", type=Path, default=ROOT / "outputs/phase4/clock_input_match.csv")
    ap.add_argument("--out", type=Path, default=ROOT / "outputs/phase4")
    args = ap.parse_args(); args.out.mkdir(parents=True, exist_ok=True)
    match = pd.read_csv(args.match)
    match = match[match.match_status.eq("unique") & match.hunt_id.notna()]
    names = {int(r.hunt_id): str(r.cluster) for _, r in match.iterrows()}
    rows = []
    with args.members.open("rb") as fh:
        for line in fh:
            try:
                hid = int(float(text(line, S["id"])))
            except ValueError:
                continue
            if hid not in names:
                continue
            rv, erv = num(line, S["rv"]), num(line, S["e_rv"])
            p = num(line, S["prob"])
            if not (math.isfinite(rv) and math.isfinite(erv) and math.isfinite(p) and p > 0):
                continue
            rows.append({
                "cluster": names[hid], "hunt_id": hid, "gaia_source_id": text(line, S["source_id"]),
                "inrj": int(text(line, S["inrj"]) or -1), "inrt": int(text(line, S["inrt"]) or -1),
                "prob": p, "RA_deg": num(line, S["ra"]), "Dec_deg": num(line, S["dec"]),
                "RV_kms": rv, "RV_err_kms": erv,
                "VarFlag": text(line, S["varflag"]),
                "NSS": text(line, S["nss"]), "RVS": text(line, S["rvs"]),
            })
    out = pd.DataFrame(rows, columns=["cluster", "hunt_id", "gaia_source_id", "inrj", "inrt", "prob", "RA_deg", "Dec_deg", "RV_kms", "RV_err_kms", "VarFlag", "NSS", "RVS"])
    out.to_csv(args.out / "member_rv_candidates.csv", index=False, quoting=csv.QUOTE_MINIMAL)
    report = {
        "status": "PASS_SOURCE_ID_RV_EXTRACTION" if len(out) else "DATA_BLOCKED",
        "outcome_blind": True, "n_rows": int(len(out)), "n_clusters": int(out.hunt_id.nunique()) if len(out) else 0,
        "n_inrj": int((out.inrj == 1).sum()) if len(out) else 0,
        "n_inrj_ge3_by_cluster": int((out[out.inrj == 1].groupby("hunt_id").size() >= 3).sum()) if len(out) else 0,
        "inputs": {"members": str(args.members), "members_sha256": sha256(args.members), "match": str(args.match), "match_sha256": sha256(args.match)},
        "source_fields": "GaiaDR3 source_id, RV/e_RV, membership flags and probability copied from HR24 members table",
        "use": "optional source_id-keyed external spectroscopic crossmatch; not merged into a clock until provenance and quality gates pass",
        "exclusions": ["MiMO alpha", "MiMO chains", "alpha-derived quantities"],
    }
    (args.out / "member_rv_candidates_provenance.json").write_text(json.dumps(report, indent=2) + "\n")
    (args.out / "member_rv_candidates.md").write_text("\n".join([
        "# Source-id keyed member RV candidates", "", f"Status: **{report['status']}**; {report['n_rows']} RV rows from {report['n_clusters']} clusters.",
        f"The table contains {report['n_inrj']} `inrj=1` rows; {report['n_inrj_ge3_by_cluster']} clusters have at least three such RVs.",
        "The table is outcome-blind and is designed for optional source_id-keyed external spectroscopy supplementation. It is not a systemic-RV catalogue and is not merged into any physical clock in this audit.",
    ]) + "\n")
    print(json.dumps({k: report[k] for k in ("status", "n_rows", "n_clusters", "n_inrj", "n_inrj_ge3_by_cluster")}, indent=2))


if __name__ == "__main__":
    main()
