#!/usr/bin/env python3
"""Extract only MF-Prime MiMO FITS chains from the supplied archive."""

from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path

import pandas as pd


COLSPECS = [(0, 17), (18, 24), (25, 31), (32, 37), (38, 44), (45, 51), (52, 58), (59, 65), (66, 72), (73, 79), (80, 86), (87, 93), (94, 100), (101, 106), (107, 112), (113, 118), (119, 124), (125, 131), (132, 138), (139, 145), (146, 152), (153, 159), (160, 165), (166, 171)]
COLS = ["cluster", "logage_best", "logage50", "logage16", "logage84", "feh_best", "feh50", "feh16", "feh84", "dm_best", "dm50", "dm16", "dm84", "av_best", "av50", "av16", "av84", "alpha_best", "alpha50", "alpha16", "alpha84", "avgprior", "sigprior", "MFsamp"]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def main() -> None:
    p = argparse.ArgumentParser(); p.add_argument("--archive", type=Path, default=Path("cluster_params_posterior_chains.html")); p.add_argument("--catalog", type=Path, default=Path("data/mimo_catalog/table3.dat")); p.add_argument("--output-dir", type=Path, default=Path("data/mimo_chains_prime")); p.add_argument("--force", action="store_true")
    args = p.parse_args(); args.output_dir.mkdir(parents=True, exist_ok=True)
    d = pd.read_fwf(args.catalog, colspecs=COLSPECS, names=COLS)
    prime = d[pd.to_numeric(d.MFsamp, errors="coerce") == 1.0].cluster.astype(str).tolist()
    wanted = {f"post_chain_{name}.fits" for name in prime}
    manifest = {"archive": str(args.archive), "archive_sha256": sha256(args.archive), "catalog": str(args.catalog), "catalog_sha256": sha256(args.catalog), "requested": len(wanted), "files": []}
    with zipfile.ZipFile(args.archive) as z:
        available = set(z.namelist())
        missing = sorted(wanted - available)
        if missing: raise SystemExit(f"Missing {len(missing)} requested chains: {missing[:5]}")
        for name in sorted(wanted):
            out = args.output_dir / name
            if out.exists() and not args.force: continue
            with z.open(name) as src, out.open("wb") as dst:
                while True:
                    block = src.read(1 << 20)
                    if not block: break
                    dst.write(block)
            manifest["files"].append({"name": name, "size_bytes": out.stat().st_size, "sha256": sha256(out)})
    if len(manifest["files"]) != len(wanted):
        manifest["files"] = [{"name": n.name, "size_bytes": n.stat().st_size, "sha256": sha256(n)} for n in sorted(args.output_dir.glob("post_chain_*.fits"))]
    manifest["extracted"] = len(manifest["files"]); manifest["missing"] = missing
    (args.output_dir / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"requested": len(wanted), "extracted": manifest["extracted"], "missing": len(missing), "output_dir": str(args.output_dir)}, indent=2))


if __name__ == "__main__": main()
