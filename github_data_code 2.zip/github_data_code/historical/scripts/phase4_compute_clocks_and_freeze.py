#!/usr/bin/env python3
"""Compute alpha-blind Phase-IV clocks and create CLOCK_FREEZE_A.

Primary structure uses HR24 MassJ/NJ and the non-Jacobi projected half-mass
radius (Prob>=0.7, R<3*r50).  The 3D deprojection is a frozen nuisance draw.
The script reproduces Li et al. Appendix-C relaxation and dissolution forms,
stores alternative definitions, and refuses to read any MiMO product.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import spearmanr

ROOT = Path(__file__).resolve().parents[1]
G_PC3_MSUN_MYR2 = 4.498502151575286e-3


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def positive_normal(rng, center: float, sigma: float, n: int, floor: float) -> np.ndarray:
    sigma = max(float(sigma), 1e-6)
    x = rng.normal(center, sigma, n)
    bad = x <= floor
    for _ in range(8):
        if not bad.any():
            break
        x[bad] = rng.normal(center, sigma, int(bad.sum()))
        bad = x <= floor
    return np.maximum(x, floor)


def split_normal(rng, median: float, lo: float, hi: float, n: int, floor: float) -> np.ndarray:
    z = rng.normal(size=n)
    slo = max(median - lo, 0.01 * median)
    shi = max(hi - median, 0.01 * median)
    return np.maximum(median + np.where(z < 0, z * slo, z * shi), floor)


def q3(a: np.ndarray) -> tuple[float, float, float]:
    return tuple(map(float, np.quantile(a, [0.16, 0.50, 0.84])))


def add_summary(rec: dict, name: str, a: np.ndarray) -> None:
    finite = a[np.isfinite(a)]
    lo, med, hi = q3(finite) if len(finite) else (math.nan, math.nan, math.nan)
    rec[f"{name}_16"] = lo; rec[f"{name}_50"] = med; rec[f"{name}_84"] = hi


def trh(N: np.ndarray, M: np.ndarray, rh: np.ndarray, gamma: float) -> tuple[np.ndarray, np.ndarray]:
    tdyn = np.sqrt(np.power(rh, 3) / (G_PC3_MSUN_MYR2 * M))
    coulomb = np.log(np.maximum(gamma * N, 1.000001))
    return tdyn, 0.138 * N / coulomb * tdyn


def tdiss(N: np.ndarray, R: np.ndarray, Vc: np.ndarray, e: np.ndarray,
          gamma: float, beta: float, x: float) -> np.ndarray:
    coulomb = np.log(np.maximum(gamma * N, 1.000001))
    return beta * np.power(N / coulomb, x) * R / (Vc / 220.0) * np.maximum(1.0 - e, 0.02)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--member", type=Path, default=ROOT / "outputs/phase4/member_dynamics_summary.csv")
    ap.add_argument("--orbit", type=Path, default=ROOT / "outputs/phase4/orbit_mc_summary.csv")
    ap.add_argument("--rv", type=Path, default=ROOT / "outputs/phase4/systemic_rv_summary.csv")
    ap.add_argument("--orbit-draws", type=Path, default=ROOT / "outputs/phase4/orbit_draws")
    ap.add_argument("--external-relax", type=Path, default=ROOT / "hunt24/zhang26/clocks.tsv")
    ap.add_argument("--out", type=Path, default=ROOT / "outputs/phase4")
    ap.add_argument("--n-mc", type=int, default=5000)
    ap.add_argument("--seed", type=int, default=20260906)
    ap.add_argument("--gamma", type=float, default=0.02)
    ap.add_argument("--fdep-center", type=float, default=4.0 / 3.0)
    ap.add_argument("--fdep-sigma", type=float, default=0.08)
    args = ap.parse_args(); args.out.mkdir(parents=True, exist_ok=True)
    clock_draw_dir = args.out / "clock_draws"; clock_draw_dir.mkdir(parents=True, exist_ok=True)
    member = pd.read_csv(args.member); orbit = pd.read_csv(args.orbit); rv = pd.read_csv(args.rv)
    # Display names may differ across MiMO aliases and the HR24 accepted name;
    # the HR24 internal identifier is the immutable join key.
    d = member.drop(columns=["cluster"], errors="ignore").merge(
        orbit[["hunt_id", "cluster", "orbit_status", "n_mc_valid"]], on="hunt_id", validate="one_to_one")
    d = d.merge(rv[["hunt_id", "RVsys_kms", "RVsys_err_kms", "N_RV", "rv_tier"]],
                on="hunt_id", validate="one_to_one")
    d = d[d.orbit_status.eq("PASS") & d.rv_tier.isin(["A", "B"])].copy()
    rng = np.random.default_rng(args.seed)
    rows = []
    for _, row in d.sort_values("hunt_id").iterrows():
        opath = args.orbit_draws / f"hunt_{int(row.hunt_id):04d}.npz"
        if not opath.exists():
            continue
        od = np.load(opath)
        n = min(args.n_mc, len(od["Rperi_kpc"]))
        if n < int(0.95 * args.n_mc):
            continue
        # Independent HR24-corrected primary M/N.
        M = positive_normal(rng, row.hunt_MassJ, row.hunt_e_MassJ, n, 1.0)
        N0 = row.hunt_NJ if math.isfinite(row.hunt_NJ) and row.hunt_NJ > 50 else row.hunt_N
        # The adopted Coulomb logarithm ln(0.02 N) is not defined as a
        # positive relaxation factor for N<=50. Do not manufacture a value by
        # clipping such systems; they fail the clock-definition gate.
        if not math.isfinite(N0) or N0 <= 50:
            continue
        N = positive_normal(rng, N0, math.sqrt(max(N0, 1.0)), n, 51.0)
        # Non-Jacobi primary projected radius. Its uncertainty includes a
        # 0.05-dex floor and disagreement with the two frozen inrj variants.
        Rp = float(row.Rh_mass_proj_fixed3r50_p07_pc)
        variants = np.array([row.Rh_mass_proj_pc, row.Rh_mass_proj_inrj_p07_pc], dtype=float)
        diffs = np.abs(np.log10(variants[np.isfinite(variants) & (variants > 0)] / Rp))
        sigma_log_R = max(0.05, float(np.median(diffs)) if len(diffs) else 0.05)
        Rp_draw = Rp * np.power(10.0, rng.normal(0.0, sigma_log_R, n))
        fdep = positive_normal(rng, args.fdep_center, args.fdep_sigma, n, 1.05)
        fdep = np.minimum(fdep, 1.65)
        rh3d = Rp_draw * fdep
        tdyn_primary, trh_primary = trh(N, M, rh3d, args.gamma)

        # Zero-alpha observed-only sensitivity from member mass quantiles.
        Mobs = split_normal(rng, row.M_obs_prob_M50_fixed3r50_p07,
                            row.M_obs_prob_M16_fixed3r50_p07,
                            row.M_obs_prob_M84_fixed3r50_p07, n, 1.0)
        Nobs0 = float(row.N_eff_fixed3r50_p07)
        if Nobs0 > 50:
            Nobs = positive_normal(rng, Nobs0, math.sqrt(Nobs0), n, 51.0)
            _, trh_observed = trh(Nobs, Mobs, rh3d, args.gamma)
        else:
            Nobs = np.full(n, np.nan); trh_observed = np.full(n, np.nan)

        e = od["orbit_eccentricity"][:n]
        td_li_current = tdiss(N, od["Rcurrent_kpc"][:n], od["Vcirc_current_kms"][:n], e,
                              args.gamma, 1.91, 0.75)
        # BM03 eccentric-orbit form uses apocentre and orbital eccentricity.
        td_bm03_apo = tdiss(N, od["Rapo_kpc"][:n], od["Vcirc_apo_kms"][:n], e,
                            args.gamma, 1.91, 0.75)
        td_bm03_w07 = tdiss(N, od["Rapo_kpc"][:n], od["Vcirc_apo_kms"][:n], e,
                            args.gamma, 1.03, 0.82)
        omega_eff = np.sqrt(od["tidal_omega2"][:n])
        env_equivalent_kpc = 220.0 / np.maximum(omega_eff, 1e-9)
        td_orbit_average = tdiss(N, env_equivalent_kpc, np.full(n, 220.0), e,
                                 args.gamma, 1.91, 0.75)
        td_observed = tdiss(Nobs, od["Rapo_kpc"][:n], od["Vcirc_apo_kms"][:n], e,
                            args.gamma, 1.91, 0.75)
        arrays = {
            "M_hr24_Msun": M, "N_hr24": N, "Rh_proj_pc": Rp_draw, "f_deprojection": fdep,
            "Rh_3d_pc": rh3d, "tdyn_Myr": tdyn_primary, "trh_primary_Myr": trh_primary,
            "trh_observed_only_Myr": trh_observed, "tdiss_li_current_Myr": td_li_current,
            "tdiss_bm03_apo_Myr": td_bm03_apo, "tdiss_bm03_w07_Myr": td_bm03_w07,
            "tdiss_orbit_average_Myr": td_orbit_average,
            "tdiss_observed_only_Myr": td_observed,
        }
        np.savez_compressed(clock_draw_dir / f"hunt_{int(row.hunt_id):04d}.npz", **arrays)
        rec = {"cluster": row.cluster, "hunt_id": int(row.hunt_id), "rv_tier": row.rv_tier,
               "RVsys_kms": row.RVsys_kms, "RVsys_err_kms": row.RVsys_err_kms,
               "N_RV": int(row.N_RV), "n_clock_draws": n, "radius_sigma_log10": sigma_log_R,
               "clock_status": "PASS"}
        for name in ["Rperi_kpc", "Rapo_kpc", "orbit_eccentricity", "zmax_kpc",
                     "Rcurrent_kpc", "Rguide_kpc", "Vcirc_current_kms", "tidal_omega2",
                     "distance_pc"]:
            add_summary(rec, name, od[name][:n])
        for name, arr in arrays.items():
            add_summary(rec, name, arr)
        rows.append(rec)
    out = pd.DataFrame(rows)
    if args.external_relax.exists() and len(out):
        ext = pd.read_csv(args.external_relax, sep="\t", comment="#", dtype=str)
        ext["ID"] = pd.to_numeric(ext["ID"], errors="coerce")
        ext["trelax"] = pd.to_numeric(ext["trelax"], errors="coerce")
        ext = ext.dropna(subset=["ID", "trelax"])[["ID", "trelax"]].rename(
            columns={"ID": "hunt_id", "trelax": "trh_external_Zhang26_Myr"})
        ext["hunt_id"] = ext.hunt_id.astype(int)
        out = out.merge(ext, on="hunt_id", how="left", validate="one_to_one")
    out.to_csv(args.out / "clock_freeze_A.csv", index=False)
    try:
        out.to_parquet(args.out / "CLOCK_FREEZE_A.parquet", index=False)
        freeze_path = args.out / "CLOCK_FREEZE_A.parquet"
    except (ImportError, ValueError, OSError):
        freeze_path = args.out / "clock_freeze_A.csv"

    rank = {}
    if len(out):
        for a, b in [("trh_primary_Myr_50", "trh_observed_only_Myr_50"),
                     ("tdiss_li_current_Myr_50", "tdiss_bm03_apo_Myr_50"),
                     ("tdiss_bm03_apo_Myr_50", "tdiss_observed_only_Myr_50")]:
            ok = np.isfinite(out[a]) & np.isfinite(out[b])
            rank[f"rho_{a}_vs_{b}"] = float(spearmanr(out.loc[ok, a], out.loc[ok, b]).statistic) if ok.sum() >= 3 else math.nan
        ok_ext = out.trh_external_Zhang26_Myr.notna() if "trh_external_Zhang26_Myr" in out else np.zeros(len(out), dtype=bool)
        if np.sum(ok_ext) >= 3:
            rank["rho_trh_primary_vs_external_Zhang26"] = float(spearmanr(
                out.loc[ok_ext, "trh_primary_Myr_50"], out.loc[ok_ext, "trh_external_Zhang26_Myr"]).statistic)
            rank["n_external_Zhang26_matches"] = int(np.sum(ok_ext))
    status = "PASS_CLOCK_FREEZE_A" if len(out) >= 120 else "FAIL_CLOCK_COVERAGE"
    provenance = {
        "status": status, "outcome_blind": True, "n_clusters": int(len(out)), "n_mc": args.n_mc,
        "primary_radius": "Prob>=0.7 and R<3*r50pc; probability-weighted Mass50 half-mass radius",
        "deprojection_prior": {"distribution": "truncated normal", "mean": args.fdep_center,
                               "sigma": args.fdep_sigma, "bounds": [1.05, 1.65]},
        "primary_mass_N": "HR24 MassJ and NJ; Gaussian mass error and Poisson-scale N uncertainty",
        "relaxation_formula": "Li et al. 2026 Appendix C: tdyn=sqrt(rh^3/GM); trh=0.138*N/ln(gamma*N)*tdyn",
        "dissolution_primary": "Li Appendix-C coefficients beta=1.91,x=0.75 with current R_G, model V_circ, and orbital eccentricity factor (1-e)",
        "dissolution_sensitivities": ["BM03 apocentre/eccentricity form", "orbit-averaged circular-frequency field", "W0=7 beta=1.03,x=0.82", "observed-member-only M/N"],
        "gamma": args.gamma, "rank_stability": rank,
        "inputs": {str(p): sha256(p) for p in [args.member, args.orbit, args.rv, args.external_relax] if p.exists()},
        "freeze_file": str(freeze_path), "freeze_sha256": sha256(freeze_path),
        "clock_draw_directory": str(clock_draw_dir),
        "exclusions": ["MiMO alpha", "MiMO age", "MiMO posterior chains"],
        "definition_warning": "epsilon in the (1-epsilon) term is implemented as orbital eccentricity e, not circularity",
    }
    (args.out / "CLOCK_PROVENANCE_A.json").write_text(json.dumps(provenance, indent=2) + "\n")
    (args.out / "CLOCK_FREEZE_A.sha256").write_text(f"{sha256(freeze_path)}  {freeze_path.name}\n")
    (args.out / "clock_freeze_A.md").write_text("\n".join([
        "# CLOCK FREEZE A: dynamics only", "", f"Status: **{status}**; {len(out)} clusters.",
        f"Frozen file SHA-256: `{sha256(freeze_path)}`.",
        "This freeze contains no MiMO age, alpha, or posterior-chain field. Exposure coordinates are not yet computed.",
        "The Li/BM eccentricity factor is explicitly orbital eccentricity e; it is not labelled circularity.",
    ]) + "\n")
    print(json.dumps(provenance, indent=2))


if __name__ == "__main__":
    main()
