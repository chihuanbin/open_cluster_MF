#!/usr/bin/env python3
"""Fit outcome-blind robust systemic radial velocities for Phase IV.

The primary estimator uses HR24 members with ``inrj=1`` and ``Prob>=0.7``.
It fits a Student-t location model with heteroscedastic Gaia RV errors and an
intrinsic dispersion.  There is no iterative clipping and no MiMO quantity is
read.  A sensitivity fit excludes Gaia NSS sources and photometric variables.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import gammaln

ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def nll(theta: np.ndarray, y: np.ndarray, e: np.ndarray, p: np.ndarray, nu: float) -> float:
    mu, log_sig = theta
    sig = math.exp(log_sig)
    scale2 = np.square(e) + sig * sig
    z2 = np.square(y - mu) / scale2
    const = gammaln((nu + 1.0) / 2.0) - gammaln(nu / 2.0) - 0.5 * math.log(nu * math.pi)
    ll = const - 0.5 * np.log(scale2) - 0.5 * (nu + 1.0) * np.log1p(z2 / nu)
    # Membership probabilities are transparent fractional likelihood weights.
    out = -float(np.sum(p * ll)) + 0.5 * (sig / 20.0) ** 2
    return out if math.isfinite(out) else 1e100


def finite_hessian(fun, x: np.ndarray) -> np.ndarray:
    """Central finite-difference Hessian at a two-parameter optimum."""
    x = np.asarray(x, dtype=float)
    h = np.maximum(1e-4, 2e-4 * np.maximum(1.0, np.abs(x)))
    f0 = fun(x)
    H = np.zeros((2, 2), dtype=float)
    for i in range(2):
        ei = np.zeros(2); ei[i] = h[i]
        H[i, i] = (fun(x + ei) - 2.0 * f0 + fun(x - ei)) / h[i] ** 2
    e0 = np.array([h[0], 0.0]); e1 = np.array([0.0, h[1]])
    H[0, 1] = H[1, 0] = (
        fun(x + e0 + e1) - fun(x + e0 - e1)
        - fun(x - e0 + e1) + fun(x - e0 - e1)
    ) / (4.0 * h[0] * h[1])
    return H


def fit_one(d: pd.DataFrame, nu: float) -> dict[str, float | int | str]:
    y = d.RV_kms.to_numpy(float)
    e = np.maximum(d.RV_err_kms.to_numpy(float), 0.05)
    p = d.prob.to_numpy(float)
    med = float(np.median(y))
    mad = 1.4826 * float(np.median(np.abs(y - med)))
    sig0 = max(0.2, min(20.0, math.sqrt(max(0.0, mad * mad - float(np.median(e)) ** 2))))
    objective = lambda th: nll(th, y, e, p, nu)
    opt = minimize(objective, np.array([med, math.log(sig0)]), method="L-BFGS-B",
                   bounds=[(float(y.min()) - 50.0, float(y.max()) + 50.0), (math.log(0.02), math.log(100.0))])
    mu, log_sig = map(float, opt.x)
    sig = math.exp(log_sig)
    try:
        H = finite_hessian(objective, opt.x)
        cov = np.linalg.inv(H)
        se_mu = math.sqrt(max(0.0, float(cov[0, 0])))
        se_logsig = math.sqrt(max(0.0, float(cov[1, 1])))
    except (np.linalg.LinAlgError, ValueError, FloatingPointError):
        scale2 = np.square(e) + sig * sig
        info = np.sum(p * (nu + 1.0) / (nu + 3.0) / scale2)
        se_mu = math.sqrt(1.0 / info) if info > 0 else math.nan
        se_logsig = math.nan
    scale = np.sqrt(np.square(e) + sig * sig)
    standardized = np.abs(y - mu) / scale
    tier = "A" if len(d) >= 5 and se_mu < 2.0 else ("B" if len(d) >= 3 and se_mu < 5.0 else "FAIL")
    return {
        "RVsys_kms": mu, "RVsys_err_kms": se_mu,
        "sigma_int_RV_kms": sig, "sigma_log_sigma_int": se_logsig,
        "N_RV": int(len(d)), "N_eff_prob": float(p.sum()),
        "robust_outlier_fraction": float(np.mean(standardized > 3.0)),
        "fit_converged": bool(opt.success), "rv_tier": tier,
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", type=Path, default=ROOT / "outputs/phase4/member_rv_candidates.csv")
    ap.add_argument("--out", type=Path, default=ROOT / "outputs/phase4")
    ap.add_argument("--nu", type=float, default=4.0)
    ap.add_argument("--prob-min", type=float, default=0.7)
    args = ap.parse_args(); args.out.mkdir(parents=True, exist_ok=True)
    raw = pd.read_csv(args.input, dtype={"gaia_source_id": str})
    primary = raw[(raw.inrj == 1) & (raw.prob >= args.prob_min)].copy()
    sensitivity = primary.copy()
    if "NSS" in sensitivity:
        sensitivity = sensitivity[pd.to_numeric(sensitivity.NSS, errors="coerce").fillna(0).eq(0)]
    if "VarFlag" in sensitivity:
        vf = sensitivity.VarFlag.fillna("").astype(str).str.strip().str.upper()
        sensitivity = sensitivity[vf.isin(["", "NOT_AVAILABLE", "NAN"])]

    rows = []
    for hid, d in primary.groupby("hunt_id", sort=True):
        rec = {"hunt_id": int(hid), "cluster": str(d.cluster.iloc[0])}
        rec.update(fit_one(d, args.nu))
        ds = sensitivity[sensitivity.hunt_id.eq(hid)]
        if len(ds) >= 3:
            sens = fit_one(ds, args.nu)
            rec.update({f"sensitivity_{k}": v for k, v in sens.items()})
            rec["delta_RVsys_sensitivity_kms"] = float(sens["RVsys_kms"]) - float(rec["RVsys_kms"])
        else:
            rec["sensitivity_N_RV"] = int(len(ds))
            rec["delta_RVsys_sensitivity_kms"] = math.nan
        rows.append(rec)
    out = pd.DataFrame(rows)
    out.to_csv(args.out / "systemic_rv_summary.csv", index=False)
    n_good = int(out.rv_tier.isin(["A", "B"]).sum())
    report = {
        "status": "PASS_SYSTEMIC_RV" if n_good >= 120 else "FAIL_SYSTEMIC_RV_COVERAGE",
        "outcome_blind": True, "student_t_nu": args.nu,
        "selection": f"inrj=1 and Prob>={args.prob_min}; no iterative clipping",
        "n_clusters": int(len(out)), "n_tier_A": int(out.rv_tier.eq("A").sum()),
        "n_tier_B": int(out.rv_tier.eq("B").sum()), "n_fail": int(out.rv_tier.eq("FAIL").sum()),
        "n_good_orbit_RV": n_good,
        "median_RVsys_error_kms": float(out.RVsys_err_kms.median()),
        "input": str(args.input), "input_sha256": sha256(args.input),
        "sensitivity": "exclude NSS sources and non-empty Gaia photometric VarFlag",
        "limitations": ["Membership probabilities enter as fractional likelihood weights", "RV posterior propagated downstream using the local Laplace covariance"],
    }
    (args.out / "systemic_rv_provenance.json").write_text(json.dumps(report, indent=2) + "\n")
    (args.out / "systemic_rv_summary.md").write_text("\n".join([
        "# Outcome-blind robust systemic radial velocities", "",
        f"Status: **{report['status']}**.",
        f"Tier A/B/fail: {report['n_tier_A']}/{report['n_tier_B']}/{report['n_fail']}; median systemic-RV uncertainty {report['median_RVsys_error_kms']:.3f} km s^-1.",
        "The primary Student-t fit uses high-probability HR24 members inside the HR24 Jacobi radius, with no iterative clipping. MiMO age, alpha, and chains are not read.",
    ]) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
