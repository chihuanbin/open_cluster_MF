#!/usr/bin/env python3
"""Confirmatory, outcome-blind 6D orbit Monte Carlo for Phase IV.

Reads only frozen HR24 astrometry and robust systemic-RV products. It
propagates proper-motion covariance, HR24 split-normal distance uncertainty,
and systemic-RV uncertainty through a fixed Galactic potential. MiMO ages,
mass-function slopes, and posterior chains are never opened.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from galpy.orbit import Orbit
from galpy.potential import MWPotential2014, vcirc
from galpy.util import conversion

ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def split_normal(rng: np.random.Generator, median: float, lo: float, hi: float, n: int) -> np.ndarray:
    z = rng.normal(size=n)
    slo = max(median - lo, 0.01 * median)
    shi = max(hi - median, 0.01 * median)
    return median + np.where(z < 0, z * slo, z * shi)


def quantiles(a: np.ndarray) -> dict[str, float]:
    q = np.nanquantile(a, [0.16, 0.50, 0.84])
    return {"16": float(q[0]), "50": float(q[1]), "84": float(q[2])}


def process_cluster(row: pd.Series, rng: np.random.Generator, args, draw_dir: Path) -> dict:
    n = args.n_mc
    d_pc = split_normal(rng, row.distance50_pc, row.distance16_pc, row.distance84_pc, n)
    d_kpc = np.maximum(d_pc / 1000.0, 1e-4)
    pm_cov = np.array([[row.cov_pmra_pmra, row.cov_pmra_pmdec],
                       [row.cov_pmra_pmdec, row.cov_pmdec_pmdec]], dtype=float)
    pm_cov = (pm_cov + pm_cov.T) / 2.0
    eig = np.linalg.eigvalsh(pm_cov)
    if eig.min() <= 0:
        pm_cov += np.eye(2) * (abs(eig.min()) + 1e-10)
    pm = rng.multivariate_normal([row.pmRA_masyr, row.pmDec_masyr], pm_cov, size=n)
    rv = rng.normal(row.RVsys_kms, max(row.RVsys_err_kms, 0.05), size=n)
    vxvv = np.column_stack([np.full(n, row.RA_deg), np.full(n, row.Dec_deg), d_kpc,
                            pm[:, 0], pm[:, 1], rv])
    valid_input = np.isfinite(vxvv).all(axis=1) & (d_kpc > 0)
    vxvv = vxvv[valid_input]
    if len(vxvv) < max(100, int(0.9 * n)):
        return {"cluster": row.cluster, "hunt_id": int(row.hunt_id), "n_mc_requested": n,
                "n_mc_valid": 0, "orbit_status": "LOW_VALID_INPUT"}
    orbit = Orbit(vxvv, radec=True, ro=args.ro, vo=args.vo, zo=args.zo,
                  solarmotion=[args.usun, args.vsun, args.wsun])
    # galpy binds the observed initial condition to the first grid time.
    # Start at exactly zero; a static potential makes forward orbit extrema
    # equivalent to backward extrema without misplacing the present epoch.
    time_gyr = np.linspace(0.0, args.window_gyr, args.grid_points)
    time_native = time_gyr / conversion.time_in_Gyr(args.vo, args.ro)
    orbit.integrate(time_native, MWPotential2014, method=args.integrator,
                    progressbar=False, numcores=args.numcores)
    rperi = np.asarray(orbit.rperi(), dtype=float)
    rapo = np.asarray(orbit.rap(), dtype=float)
    ecc = (rapo - rperi) / np.maximum(rapo + rperi, 1e-12)
    zmax = np.asarray(orbit.zmax(), dtype=float)
    rnow = np.asarray(orbit.R(0.0), dtype=float)
    lz = np.asarray(orbit.Lz(0.0), dtype=float)
    try:
        rguide = np.asarray(orbit.rguiding(pot=MWPotential2014), dtype=float)
    except Exception:
        rguide = np.abs(lz) / args.vo
    vc_now = np.asarray(vcirc(MWPotential2014, rnow / args.ro), dtype=float) * args.vo
    vc_apo = np.asarray(vcirc(MWPotential2014, rapo / args.ro), dtype=float) * args.vo
    vc_guide = np.asarray(vcirc(MWPotential2014, rguide / args.ro), dtype=float) * args.vo
    rtrack = np.asarray(orbit.R(time_native), dtype=float)
    vctrack = np.asarray(vcirc(MWPotential2014, rtrack / args.ro), dtype=float) * args.vo
    tidal_omega2 = np.nanmean(np.square(vctrack / np.maximum(rtrack, 1e-6)), axis=-1)
    finite = np.isfinite(rperi + rapo + ecc + zmax + rnow + lz + rguide + vc_now + tidal_omega2)
    arrays = {
        "Rperi_kpc": rperi[finite], "Rapo_kpc": rapo[finite],
        "orbit_eccentricity": ecc[finite], "zmax_kpc": zmax[finite],
        "Lz_kpc_kms": lz[finite], "Rcurrent_kpc": rnow[finite],
        "Rguide_kpc": rguide[finite], "Vcirc_current_kms": vc_now[finite],
        "Vcirc_apo_kms": vc_apo[finite], "Vcirc_guide_kms": vc_guide[finite],
        "tidal_omega2": tidal_omega2[finite], "distance_pc": d_pc[valid_input][finite],
        "pmRA_masyr": pm[:, 0][valid_input][finite], "pmDec_masyr": pm[:, 1][valid_input][finite],
        "RVsys_kms": rv[valid_input][finite],
    }
    np.savez_compressed(draw_dir / f"hunt_{int(row.hunt_id):04d}.npz", **arrays)
    out = {"cluster": row.cluster, "hunt_id": int(row.hunt_id), "rv_tier": row.rv_tier,
           "n_mc_requested": n, "n_mc_valid": int(finite.sum())}
    for name, values in arrays.items():
        if name in {"distance_pc", "pmRA_masyr", "pmDec_masyr", "RVsys_kms"}:
            continue
        for qn, value in quantiles(values).items():
            out[f"{name}_{qn}"] = value
    qrp = quantiles(arrays["Rperi_kpc"])
    out["Rperi_fractional_sigma"] = (qrp["84"] - qrp["16"]) / (2.0 * max(qrp["50"], 1e-12))
    out["orbit_status"] = "PASS" if finite.sum() >= int(0.95 * n) else "LOW_VALID_MC"
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--astrometry", type=Path, default=ROOT / "outputs/phase4/astrometric_covariance.csv")
    ap.add_argument("--rv", type=Path, default=ROOT / "outputs/phase4/systemic_rv_summary.csv")
    ap.add_argument("--out", type=Path, default=ROOT / "outputs/phase4")
    ap.add_argument("--n-mc", type=int, default=5000)
    ap.add_argument("--window-gyr", type=float, default=2.0)
    ap.add_argument("--grid-points", type=int, default=201)
    ap.add_argument("--integrator", default="dop853_c")
    ap.add_argument("--numcores", type=int, default=1)
    ap.add_argument("--seed", type=int, default=20260906)
    ap.add_argument("--limit", type=int, default=None, help="Deterministic smoke-test limit; omit for confirmatory run")
    ap.add_argument("--ro", type=float, default=8.2)
    ap.add_argument("--vo", type=float, default=232.0)
    ap.add_argument("--zo", type=float, default=0.0208)
    ap.add_argument("--usun", type=float, default=11.1)
    ap.add_argument("--vsun", type=float, default=12.24)
    ap.add_argument("--wsun", type=float, default=7.25)
    args = ap.parse_args(); args.out.mkdir(parents=True, exist_ok=True)
    draw_dir = args.out / "orbit_draws"; draw_dir.mkdir(parents=True, exist_ok=True)
    ast = pd.read_csv(args.astrometry); rv = pd.read_csv(args.rv)
    d = ast.merge(rv, on=["hunt_id", "cluster"], validate="one_to_one")
    d = d[d.rv_tier.isin(["A", "B"])].copy()
    if args.limit is not None:
        d = d.sort_values("hunt_id").head(args.limit).copy()
    rng = np.random.default_rng(args.seed)
    rows = []
    for i, (_, row) in enumerate(d.iterrows(), start=1):
        try:
            rows.append(process_cluster(row, rng, args, draw_dir))
        except Exception as exc:
            rows.append({"cluster": row.cluster, "hunt_id": int(row.hunt_id), "rv_tier": row.rv_tier,
                         "n_mc_requested": args.n_mc, "n_mc_valid": 0,
                         "orbit_status": "ORBIT_ERROR", "error": f"{type(exc).__name__}: {exc}"})
        if i % 10 == 0:
            print(f"completed {i}/{len(d)}", flush=True)
    out = pd.DataFrame(rows); out.to_csv(args.out / "orbit_mc_summary.csv", index=False)
    n_pass = int(out.orbit_status.eq("PASS").sum())
    med_frac = float(out.loc[out.orbit_status.eq("PASS"), "Rperi_fractional_sigma"].median()) if n_pass else math.nan
    report = {
        "status": "PASS_ORBIT_QUALITY" if n_pass >= 120 and med_frac < 0.25 else "FAIL_ORBIT_QUALITY",
        "outcome_blind": True, "n_input_RV_tier_AB": int(len(d)), "n_orbit_pass": n_pass,
        "n_mc": args.n_mc, "window_gyr": args.window_gyr, "grid_points": args.grid_points,
        "median_Rperi_fractional_sigma": med_frac, "potential": "galpy MWPotential2014",
        "solar_parameters": {"ro_kpc": args.ro, "vo_kms": args.vo, "zo_kpc": args.zo,
                             "solarmotion_kms": [args.usun, args.vsun, args.wsun]},
        "integrator": args.integrator,
        "time_grid": "0 to +window_gyr; current observed state is t=0 in a static potential",
        "eccentricity_definition": "(Rapo-Rperi)/(Rapo+Rperi); orbital eccentricity e, not circularity",
        "Vcirc_definition": "galpy circular speed of MWPotential2014; cluster total space speed is not V_G",
        "inputs": {str(p): sha256(p) for p in [args.astrometry, args.rv]},
        "draw_directory": str(draw_dir),
        "exclusions": ["MiMO alpha", "MiMO age", "MiMO posterior chains"],
    }
    (args.out / "orbit_mc_provenance.json").write_text(json.dumps(report, indent=2) + "\n")
    (args.out / "orbit_mc_summary.md").write_text("\n".join([
        "# Outcome-blind confirmatory orbit Monte Carlo", "", f"Status: **{report['status']}**.",
        f"{n_pass}/{len(d)} Tier-A/B RV systems pass the 95% valid-draw gate with {args.n_mc} draws; median fractional Rperi uncertainty is {med_frac:.3f}.",
        "The stored e is geometric orbital eccentricity. V_G columns are circular speeds from the frozen Galactic potential, not cluster total velocities.",
        "No MiMO age, alpha, or chain is read.",
    ]) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
