#!/usr/bin/env python3
"""Run the frozen A2 calibration engine on the already-authorized real outcome.

This is a numerical engine-bridge check only. It does not replace the frozen
formal-posterior result or alter the A2 threshold/decision rule.
"""
import hashlib, json
from pathlib import Path
import numpy as np, pandas as pd
from hierarchical_mimo_summary import read_catalog
from phase4_a2_full_likelihood import fit_and_loo

ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'outputs/phase4'; RULE=OUT/'A2_REALDATA_RULES.yaml'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    expected=(OUT/'A2_REALDATA_RULES.sha256').read_text().split()[0]
    if sha(RULE)!=expected: raise SystemExit('A2 rules hash mismatch')
    d=read_catalog(ROOT/'data/mimo_catalog/table3.dat',prime_only=True)
    b=pd.read_parquet(OUT/'CLOCK_FREEZE_B.parquet')
    d=d.merge(b[['cluster','log_age_50','eta_diss_50']],on='cluster',validate='one_to_one').dropna()
    t=d.log_age_50.to_numpy(float); eta=d.eta_diss_50.to_numpy(float)
    X=np.column_stack([np.ones(len(t)),t-t.mean(),(t-t.mean())**2])
    z=eta-X@np.linalg.lstsq(X,eta,rcond=None)[0]; z/=z.std(ddof=1)
    y=d.alpha50.to_numpy(float); sy=np.maximum((d.alpha84-d.alpha16).to_numpy(float)/2,.02)
    rng=np.random.default_rng(20260907)
    c0=fit_and_loo(t,y,sy,z,False,rng,ndraw=64)
    c1=fit_and_loo(t,y,sy,z,True,rng,ndraw=64)
    out={'status':'A2_ENGINE_BRIDGE_COMPLETE','rules_sha256':sha(RULE),'n_clusters':len(d),
         'engine':'phase4_a2_full_likelihood.fit_and_loo; grid-profile + Laplace + PSIS',
         'M0_elpd':c0[2],'M1_elpd':c1[2],'delta_ELPD_calibration_engine':c1[2]-c0[2],
         'threshold':1.0245228723971231,'passes_threshold':bool(c1[2]-c0[2]>1.0245228723971231),
         'formal_delta_ELPD_M1_minus_M0':-4.237077631686608,
         'note':'Bridge statistic is diagnostic only; frozen formal posterior result and A2 verdict are unchanged.'}
    (OUT/'A2_ENGINE_BRIDGE.json').write_text(json.dumps(out,indent=2)+'\n')
    (OUT/'A2_ENGINE_BRIDGE.md').write_text('# A2 calibration-engine bridge\n\n'+json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__': main()
