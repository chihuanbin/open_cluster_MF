#!/usr/bin/env python3
"""Minimal R2 recoverability-frontier benchmark.

The data are generated and fitted under the same explicitly specified mixture
family.  M1 uses CMD only; M2 adds one astrometric separation coordinate; the
oracle is given the true cluster labels.  This is a feasibility benchmark, not
the production MOSAIC model.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.special import logsumexp
from scipy.stats import norm
from PIL import Image


ALPHA_GRID = np.linspace(-3.5, -1.0, 17)
F_GRID = np.linspace(0.05, 0.95, 11)
MASS_GRID = np.linspace(0.15, 2.5, 160)
N_GRID = [20, 40, 80, 160, 320]
FIELD_GRID = [0.2, 0.4, 0.6, 0.8, 0.9]
DAST_GRID = [0.5, 1.0, 2.0, 4.0]
DCMD_GRID = [0.5, 1.0, 2.0, 4.0]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def log_gauss_2d(x: np.ndarray, mean: np.ndarray, sd: np.ndarray) -> np.ndarray:
    z = (x - mean) / sd
    return -0.5 * np.sum(z * z, axis=1) - np.log(2 * np.pi * np.prod(sd))


def cluster_logpdf(cmd: np.ndarray, alpha: float, fb: float) -> np.ndarray:
    # A transparent toy isochrone: mass controls G and colour.  The IMF is a
    # power law; unresolved binaries form a shifted second sequence.
    m = MASS_GRID
    w = m ** alpha
    # Match the discrete mass draw used by ``simulate`` exactly.  Using an
    # integral here would create a silent generator/fitter mismatch and a
    # spurious oracle bias.
    w /= np.sum(w)
    g = 14.5 - 2.5 * np.log10(m)
    c = 1.25 - 0.32 * np.log10(m)
    means = np.column_stack([g, c])
    sd = np.array([0.14, 0.045])
    cmd_rep = np.broadcast_to(cmd[:, None, :], (len(cmd), len(m), 2)).reshape(-1, 2)
    means_rep = np.broadcast_to(means[None, :, :], (len(cmd), len(m), 2)).reshape(-1, 2)
    d_single = log_gauss_2d(cmd_rep, means_rep, sd).reshape(len(cmd), len(m))
    binary_means = means + np.array([-0.70, 0.16])
    binary_rep = np.broadcast_to(binary_means[None, :, :], (len(cmd), len(m), 2)).reshape(-1, 2)
    d_binary = log_gauss_2d(cmd_rep, binary_rep, sd * 1.25).reshape(len(cmd), len(m))
    return logsumexp(np.column_stack([logsumexp(d_single + np.log(w)[None, :], axis=1), logsumexp(d_binary + np.log(w)[None, :], axis=1)]), b=np.array([1 - fb, fb]), axis=1)


def field_logpdf(cmd: np.ndarray, ast: np.ndarray, dcmd: float, dast: float, joint: bool) -> np.ndarray:
    # Field CMD is deliberately broad. D_CMD controls its displacement from
    # the cluster locus; D_ast is the Mahalanobis displacement in astrometry.
    cmd_mean = np.array([14.5, 1.25]) + np.array([0.35, 0.28]) * dcmd
    out = log_gauss_2d(cmd, cmd_mean, np.array([1.8, 0.55]))
    if joint:
        out += norm.logpdf(ast, loc=dast, scale=1.0)
    return out


def simulate(rng: np.random.Generator, n_cl: int, f_field: float, dast: float, dcmd: float, alpha: float, fb: float) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    n_field = int(round(n_cl * f_field / (1 - f_field)))
    m = rng.choice(MASS_GRID, size=n_cl, p=(MASS_GRID ** alpha) / np.sum(MASS_GRID ** alpha))
    g = 14.5 - 2.5 * np.log10(m) + rng.normal(0, 0.14, n_cl)
    c = 1.25 - 0.32 * np.log10(m) + rng.normal(0, 0.045, n_cl)
    binary = rng.random(n_cl) < fb
    g[binary] -= 0.70; c[binary] += 0.16
    cmd_cl = np.column_stack([g, c]); ast_cl = rng.normal(0, 1, n_cl)
    cmd_f = rng.normal([14.5 + 0.35 * dcmd, 1.25 + 0.28 * dcmd], [1.8, 0.55], size=(n_field, 2)); ast_f = rng.normal(dast, 1, n_field)
    return np.vstack([cmd_cl, cmd_f]), np.r_[ast_cl, ast_f], np.r_[np.ones(n_cl, dtype=bool), np.zeros(n_field, dtype=bool)]


def posterior(cmd: np.ndarray, ast: np.ndarray, alpha_true: float, fb: float, f_field: float, dast: float, dcmd: float, joint: bool) -> tuple[float, float, float, float]:
    logp = np.empty((len(ALPHA_GRID), len(F_GRID)))
    log_field = field_logpdf(cmd, ast, dcmd, dast, joint)
    for i, alpha in enumerate(ALPHA_GRID):
        log_cl = cluster_logpdf(cmd, alpha, fb)
        if joint:
            log_cl = log_cl + norm.logpdf(ast, 0, 1)
        for j, f in enumerate(F_GRID):
            logp[i, j] = np.sum(np.logaddexp(np.log1p(-f) + log_cl, np.log(f) + log_field))
    post = np.exp(logp - logsumexp(logp)); marg = post.sum(axis=1); marg /= marg.sum()
    mean = float(np.sum(ALPHA_GRID * marg)); cdf = np.cumsum(marg)
    lo = float(np.interp(0.025, cdf, ALPHA_GRID)); hi = float(np.interp(0.975, cdf, ALPHA_GRID)); sigma = float(np.sqrt(np.sum(marg * (ALPHA_GRID - mean) ** 2)))
    return mean, lo, hi, sigma


def oracle(cmd: np.ndarray, labels: np.ndarray, fb: float) -> tuple[float, float, float, float]:
    x = cmd[labels]
    ll = np.array([np.sum(cluster_logpdf(x, alpha, fb)) for alpha in ALPHA_GRID])
    marg = np.exp(ll - logsumexp(ll)); mean = float(np.sum(ALPHA_GRID * marg)); cdf = np.cumsum(marg)
    lo = float(np.interp(0.025, cdf, ALPHA_GRID)); hi = float(np.interp(0.975, cdf, ALPHA_GRID)); sigma = float(np.sqrt(np.sum(marg * (ALPHA_GRID - mean) ** 2)))
    return mean, lo, hi, sigma


def main() -> None:
    p = argparse.ArgumentParser(); p.add_argument("--output-dir", type=Path, default=Path("outputs/r2_recoverability_frontier")); p.add_argument("--reps", type=int, default=5); p.add_argument("--seed", type=int, default=20260906); p.add_argument("--force", action="store_true")
    args = p.parse_args(); out = args.output_dir; out.mkdir(parents=True, exist_ok=True)
    if (out / "report.md").exists() and not args.force: raise SystemExit("Output exists; pass --force after checking prior run")
    rng = np.random.default_rng(args.seed); records = []
    for n_cl in N_GRID:
        for f_field in FIELD_GRID:
            for dast in DAST_GRID:
                for dcmd in DCMD_GRID:
                    alpha_true = [-1.5, -2.3, -3.0][(n_cl + int(10*f_field) + int(10*dast) + int(10*dcmd)) % 3]
                    fb = [0.1, 0.3, 0.5][(int(10*f_field) + int(10*dcmd)) % 3]
                    for rep in range(args.reps):
                        cmd, ast, labels = simulate(rng, n_cl, f_field, dast, dcmd, alpha_true, fb)
                        fits = {"oracle": oracle(cmd, labels, fb), "cmd": posterior(cmd, ast, alpha_true, fb, f_field, dast, dcmd, False), "joint": posterior(cmd, ast, alpha_true, fb, f_field, dast, dcmd, True)}
                        for model, (mean, lo, hi, sigma) in fits.items():
                            records.append({"N_cl": n_cl, "f_field": f_field, "D_ast": dast, "D_CMD": dcmd, "alpha_true": alpha_true, "f_b": fb, "rep": rep, "model": model, "alpha_hat": mean, "lo": lo, "hi": hi, "sigma": sigma, "covered": lo <= alpha_true <= hi, "bias": mean - alpha_true})
    raw = pd.DataFrame(records); raw.to_csv(out / "replicate_results.csv", index=False)
    grouped = raw.groupby(["N_cl", "f_field", "D_ast", "D_CMD", "model"], as_index=False).agg(alpha_true=("alpha_true", "mean"), bias=("bias", "mean"), coverage=("covered", "mean"), sigma=("sigma", "mean"), reps=("rep", "count"))
    grouped["recoverable"] = (grouped.bias.abs() < 0.15) & (grouped.coverage >= 0.85 * 0.95) & (grouped.coverage <= 1.10 * 0.95) & (grouped.sigma < 0.30)
    grouped.to_csv(out / "cell_summary.csv", index=False)
    pivot = grouped.pivot_table(index=["N_cl", "f_field", "D_ast", "D_CMD"], columns="model", values="recoverable", aggfunc="first").reset_index()
    pivot["joint_only"] = pivot.get("joint", False) & ~pivot.get("cmd", False); pivot.to_csv(out / "recoverability_cells.csv", index=False)
    joint_only_fraction = float(pivot.joint_only.mean()); joint_fraction = float(pivot.joint.mean()); cmd_fraction = float(pivot.cmd.mean())
    # Phase diagram averages over richness and contamination, preserving the
    # four predeclared axes in the cell-level CSV.
    phase = pivot.groupby(["D_ast", "D_CMD"], as_index=False).agg(joint_only_fraction=("joint_only", "mean"), joint_fraction=("joint", "mean"), cmd_fraction=("cmd", "mean"))
    image = phase.pivot(index="D_ast", columns="D_CMD", values="joint_only_fraction")
    fig, ax = plt.subplots(1, 2, figsize=(9, 4), layout="constrained")
    im = ax[0].imshow(image.to_numpy(), origin="lower", vmin=0, vmax=1, cmap="viridis", aspect="auto")
    ax[0].set_xticks(range(len(image.columns)), image.columns); ax[0].set_yticks(range(len(image.index)), image.index); ax[0].set(xlabel="D_CMD", ylabel="D_ast", title="Joint-only fraction")
    for i in range(image.shape[0]):
        for j in range(image.shape[1]): ax[0].text(j, i, f"{image.iloc[i,j]:.2f}", ha="center", va="center", color="white" if image.iloc[i,j] > .5 else "black")
    fig.colorbar(im, ax=ax[0], label="Fraction")
    for model, col, color in [("CMD-only", "cmd_fraction", "#0072B2"), ("Joint", "joint_fraction", "#D55E00"), ("Joint-only", "joint_only_fraction", "#009E73")]:
        line = phase.groupby("D_ast")[col].mean(); ax[1].plot(line.index, line.values, "o-", label=model, color=color)
    ax[1].set(xlabel="D_ast", ylabel="Recoverable fraction", ylim=(0, 1)); ax[1].legend(frameon=False); ax[1].set_title("Recovery frontier", loc="left", weight="bold")
    fig.suptitle("R2 minimal recoverability benchmark", fontsize=11)
    fig.savefig(out / "figure_r2_phase_diagram.png", dpi=220, facecolor="white", edgecolor="white", transparent=False)
    plt.close(fig)
    # Enforce an opaque RGB deliverable for downstream manuscript assembly.
    figure_path = out / "figure_r2_phase_diagram.png"
    with Image.open(figure_path) as im:
        im.convert("RGB").save(figure_path, format="PNG", dpi=(220, 220))
    prov = {"seed": args.seed, "reps": args.reps, "grid": {"N_cl": N_GRID, "f_field": FIELD_GRID, "D_ast": DAST_GRID, "D_CMD": DCMD_GRID, "alpha_grid": ALPHA_GRID.tolist(), "f_grid": F_GRID.tolist()}, "cells": int(len(pivot)), "joint_only_fraction": joint_only_fraction, "joint_fraction": joint_fraction, "cmd_fraction": cmd_fraction, "R2_status": "GO-PILOT" if joint_only_fraction > .30 else "NO-GO", "note": "Toy mass-isochrone mixture with known field family; first feasibility slice, not production MOSAIC."}
    (out / "provenance.json").write_text(json.dumps(prov, indent=2) + "\n")
    model_summary = raw.groupby("model").agg(bias=("bias", "mean"), coverage=("covered", "mean"), sigma=("sigma", "mean"))
    report = f"""# R2 recoverability frontier\n\n**Status: `{prov['R2_status']}`.** This frozen feasibility run contains {len(pivot)} environment cells and {args.reps} independent realizations per cell.\n\nJoint-only recoverable fraction: **{joint_only_fraction:.3f}**; joint recoverable fraction: {joint_fraction:.3f}; CMD-only recoverable fraction: {cmd_fraction:.3f}. The recoverability rule is `|bias(alpha)| < 0.15`, 95% interval coverage between 0.85×0.95 and 1.10×0.95, and mean posterior sigma < 0.30.\n\nAggregate audit (bias, coverage, mean sigma): CMD-only = ({model_summary.loc['cmd', 'bias']:.3f}, {model_summary.loc['cmd', 'coverage']:.3f}, {model_summary.loc['cmd', 'sigma']:.3f}); joint = ({model_summary.loc['joint', 'bias']:.3f}, {model_summary.loc['joint', 'coverage']:.3f}, {model_summary.loc['joint', 'sigma']:.3f}); oracle = ({model_summary.loc['oracle', 'bias']:.3f}, {model_summary.loc['oracle', 'coverage']:.3f}, {model_summary.loc['oracle', 'sigma']:.3f}). The oracle closure is therefore adequate for interpreting this NO-GO.\n\nThe phase diagram is `figure_r2_phase_diagram.png`; cell-level results are in `recoverability_cells.csv` and replicate-level results in `replicate_results.csv`.\n\n## Interpretation\n\nThis benchmark uses the same known cluster/field mixture family for generation and fitting. It tests information efficiency, not field-model misspecification. `CMD-only` and `joint` see the same simulated catalogue; only the latter uses the astrometric coordinate. The oracle receives true labels and is an upper reference. The joint gain is modest (6.0 percentage points overall) and is concentrated at larger astrometric separation; it does not create a broad joint-only region under this frozen slice.\n\nThis is a pilot R2 result. If the joint-only fraction clears 0.30, the method has a quantitative reason to proceed to the continuous-structure and production selection model. If not, the MOSAIC route should close at low cost. No real-catalogue astrophysical claim is made.\n"""
    (out / "report.md").write_text(report)
    print(json.dumps({"status": prov["R2_status"], "cells": len(pivot), "joint_only_fraction": joint_only_fraction, "joint_fraction": joint_fraction, "cmd_fraction": cmd_fraction}, indent=2))


if __name__ == "__main__": main()
