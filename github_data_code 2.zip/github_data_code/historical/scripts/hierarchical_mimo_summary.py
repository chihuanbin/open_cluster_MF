#!/usr/bin/env python3
"""Chain-based H-MiMO population-level pilot.

The script supports the supplied MiMO FITS chains (weighted resampling of the
joint age--MF posterior) and retains a summary-proxy fallback for provenance
tests. It is deliberately limited to constant/linear population audits;
formal decomposition, broken-line comparison, and physical-clock models are
separate gated analyses. No physical-clock claim is made.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import logsumexp
from scipy.stats import norm
from PIL import Image
from astropy.io import fits


COLSPECS = [(0, 17), (18, 24), (25, 31), (32, 37), (38, 44), (45, 51), (52, 58), (59, 65), (66, 72), (73, 79), (80, 86), (87, 93), (94, 100), (101, 106), (107, 112), (113, 118), (119, 124), (125, 131), (132, 138), (139, 145), (146, 152), (153, 159), (160, 165), (166, 171)]
COLS = ["cluster", "logage_best", "logage50", "logage16", "logage84", "feh_best", "feh50", "feh16", "feh84", "dm_best", "dm50", "dm16", "dm84", "av_best", "av50", "av16", "av84", "alpha_best", "alpha50", "alpha16", "alpha84", "avgprior", "sigprior", "MFsamp"]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def read_catalog(path: Path, prime_only: bool) -> pd.DataFrame:
    d = pd.read_fwf(path, colspecs=COLSPECS, names=COLS)
    numeric = [c for c in COLS if c != "cluster"]
    d[numeric] = d[numeric].apply(pd.to_numeric, errors="coerce")
    d = d.dropna(subset=["logage50", "alpha50", "alpha16", "alpha84"])
    if prime_only:
        d = d[d.MFsamp == 1.0].copy()
    return d.reset_index(drop=True)


def pseudo_draws(d: pd.DataFrame, nsamp: int, seed: int) -> tuple[np.ndarray, np.ndarray, pd.DataFrame]:
    """Summary-proxy draws; covariance is unavailable and set to zero."""
    rng = np.random.default_rng(seed)
    tau_sd = np.maximum((d.logage84.to_numpy() - d.logage16.to_numpy()) / 2.0, 0.003)
    alpha_sd = np.maximum((d.alpha84.to_numpy() - d.alpha16.to_numpy()) / 2.0, 0.02)
    tau = rng.normal(d.logage50.to_numpy()[:, None], tau_sd[:, None], (len(d), nsamp))
    alpha = rng.normal(d.alpha50.to_numpy()[:, None], alpha_sd[:, None], (len(d), nsamp))
    diag = pd.DataFrame({"cluster": d.cluster, "ess": np.nan, "weighted_corr": np.nan, "source": "summary_proxy"})
    return tau, alpha, diag


def chain_draws(d: pd.DataFrame, chain_dir: Path, nsamp: int, seed: int) -> tuple[np.ndarray, np.ndarray, pd.DataFrame]:
    """Read weighted FITS chains and resample joint (age, alpha) draws."""
    rng = np.random.default_rng(seed)
    tau = np.empty((len(d), nsamp)); alpha = np.empty((len(d), nsamp)); diagnostics = []
    for i, name in enumerate(d.cluster.astype(str)):
        path = chain_dir / f"post_chain_{name}.fits"
        with fits.open(path, memmap=False) as hdul:
            tab = hdul[1].data
            a = np.asarray(tab["alpha_mf"], dtype=float); t = np.asarray(tab["log_age"], dtype=float); lw = np.asarray(tab["logwt"], dtype=float)
        keep = np.isfinite(a) & np.isfinite(t) & np.isfinite(lw)
        a, t, lw = a[keep], t[keep], lw[keep]
        w = np.exp(lw - np.max(lw)); w /= np.sum(w)
        idx = rng.choice(len(a), size=nsamp, replace=True, p=w)
        tau[i], alpha[i] = t[idx], a[idx]
        cov = np.cov(t, a, aweights=w, ddof=0); corr = float(cov[0, 1] / np.sqrt(cov[0, 0] * cov[1, 1])) if cov[0, 0] > 0 and cov[1, 1] > 0 else np.nan
        order_a = np.argsort(a); order_t = np.argsort(t); ca = np.cumsum(w[order_a]); ct = np.cumsum(w[order_t])
        chain_a50 = float(np.interp(0.5, ca, a[order_a])); chain_t50 = float(np.interp(0.5, ct, t[order_t]))
        diagnostics.append({"cluster": name, "ess": float(1.0 / np.sum(w * w)), "weighted_corr": corr, "chain_alpha50": chain_a50, "table_alpha50": float(d.iloc[i].alpha50), "chain_logage50": chain_t50, "table_logage50": float(d.iloc[i].logage50), "source": "weighted_fits_chain", "n_chain": int(len(a))})
    return tau, alpha, pd.DataFrame(diagnostics)


def mu_model(tau: np.ndarray, pars: np.ndarray, model: str) -> np.ndarray:
    if model == "constant":
        return pars[0] + np.zeros_like(tau)
    if model == "linear":
        return pars[0] + pars[1] * (tau - 8.5)
    raise ValueError(model)


def recycled_loglike(pars: np.ndarray, tau: np.ndarray, alpha: np.ndarray, model: str) -> float:
    # pars = beta0[, beta1], log intrinsic scatter.  Uniform interim priors
    # are assumed, so the posterior-recycling ratio reduces to the population
    # density averaged over each cluster's approximate posterior draws.
    sigma = np.exp(pars[-1])
    if sigma < 1e-3 or sigma > 2.0:
        return -np.inf
    mu = mu_model(tau, pars, model)
    terms = norm.logpdf(alpha, mu, sigma)
    return float(np.sum(logsumexp(terms, axis=1) - np.log(alpha.shape[1])))


def fit_hierarchy(tau: np.ndarray, alpha: np.ndarray, model: str) -> dict:
    if model == "constant":
        x0, bounds = np.array([-2.3, np.log(0.2)]), [(-5, 1), (np.log(0.005), np.log(2))]
    else:
        x0, bounds = np.array([-2.3, 0.0, np.log(0.2)]), [(-5, 1), (-3, 3), (np.log(0.005), np.log(2))]
    result = minimize(lambda x: -recycled_loglike(x, tau, alpha, model), x0, method="Nelder-Mead", options={"maxiter": 800, "xatol": 1e-5, "fatol": 1e-5})
    pars = result.x
    # Local Laplace audit gives a provisional hyperparameter scale; it is not
    # a substitute for a full hyperposterior sampler.
    h = 2e-3; n = len(pars); H = np.zeros((n, n)); f = lambda x: -recycled_loglike(x, tau, alpha, model)
    for i in range(n):
        ei = np.zeros(n); ei[i] = h
        H[i, i] = (f(pars + ei) - 2 * f(pars) + f(pars - ei)) / h**2
        for j in range(i):
            ej = np.zeros(n); ej[j] = h
            H[i, j] = H[j, i] = (f(pars + ei + ej) - f(pars + ei - ej) - f(pars - ei + ej) + f(pars - ei - ej)) / (4 * h**2)
    try:
        cov = np.linalg.pinv(H); sd = np.sqrt(np.maximum(np.diag(cov), 0))
    except np.linalg.LinAlgError:
        sd = np.full(n, np.nan)
    return {"model": model, "beta0": float(pars[0]), "beta0_sd": float(sd[0]), "beta1": float(pars[1]) if model == "linear" else 0.0, "beta1_sd": float(sd[1]) if model == "linear" else 0.0, "sigma_int": float(np.exp(pars[-1])), "sigma_int_sd": float(np.exp(pars[-1]) * sd[-1]), "loglike": float(-result.fun), "success": bool(result.success)}


def weighted_point_fit(d: pd.DataFrame, model: str) -> dict:
    x = d.logage50.to_numpy() - 8.5; y = d.alpha50.to_numpy(); s = np.maximum((d.alpha84.to_numpy() - d.alpha16.to_numpy()) / 2.0, 0.02); w = 1 / s**2
    if model == "constant":
        X = np.ones((len(d), 1))
    elif model == "linear":
        X = np.column_stack([np.ones(len(d)), x])
    else:
        raise ValueError(model)
    cov = np.linalg.inv(X.T @ (w[:, None] * X)); beta = cov @ (X.T @ (w * y)); resid = y - X @ beta
    return {"model": model, "beta0": float(beta[0]), "beta1": float(beta[1]) if model == "linear" else 0.0, "sigma_int": float(np.sqrt(max(0, np.average(resid**2 - s**2, weights=w)))), "weighted_rmse": float(np.sqrt(np.average(resid**2, weights=w)))}


def main() -> None:
    p = argparse.ArgumentParser(); p.add_argument("--catalog", type=Path, default=Path("data/mimo_catalog/table3.dat")); p.add_argument("--chain-dir", type=Path, default=Path("data/mimo_chains_prime")); p.add_argument("--output-dir", type=Path, default=Path("outputs/h_mimo_summary")); p.add_argument("--draws", type=int, default=512); p.add_argument("--seed", type=int, default=20260906); p.add_argument("--all-clusters", action="store_true"); p.add_argument("--summary-proxy", action="store_true"); p.add_argument("--force", action="store_true")
    args = p.parse_args(); out = args.output_dir; out.mkdir(parents=True, exist_ok=True)
    if (out / "report.md").exists() and not args.force: raise SystemExit("Output exists; pass --force")
    d = read_catalog(args.catalog, prime_only=not args.all_clusters); d.to_csv(out / "catalog_summary.csv", index=False)
    chain_paths = sorted(args.chain_dir.glob("post_chain_*.fits")) if args.chain_dir.exists() else []
    use_chains = (not args.summary_proxy) and len(chain_paths) >= len(d)
    if use_chains:
        tau, alpha, diagnostics = chain_draws(d, args.chain_dir, args.draws, args.seed)
    else:
        tau, alpha, diagnostics = pseudo_draws(d, args.draws, args.seed)
    diagnostics.to_csv(out / "chain_diagnostics.csv", index=False)
    point = pd.DataFrame([weighted_point_fit(d, m) for m in ("constant", "linear")]); point.to_csv(out / "point_fit.csv", index=False)
    hierarchy = pd.DataFrame([fit_hierarchy(tau, alpha, m) for m in ("constant", "linear")]); hierarchy.to_csv(out / "hierarchical_fit.csv", index=False)
    # Posterior-recycled conditional mean curve (summary proxy), evaluated at
    # fixed ages using the best-fit hyperparameters.
    ages = np.linspace(7.0, 10.0, 121); curves = []
    for _, r in hierarchy.iterrows():
        curves.append(pd.DataFrame({"log_age": ages, "model": r.model, "mu_alpha": r.beta0 + r.beta1 * (ages - 8.5), "sigma_int": r.sigma_int}))
    curve = pd.concat(curves, ignore_index=True); curve.to_csv(out / "hierarchical_curves.csv", index=False)
    fig, ax = plt.subplots(figsize=(7.2, 4.4), layout="constrained")
    yerr = np.column_stack([d.alpha50 - d.alpha16, d.alpha84 - d.alpha50])
    ax.errorbar(d.logage50, d.alpha50, yerr=yerr.T, fmt="o", ms=3.2, alpha=.45, color="#555555", label=f"MiMO MF Prime summary (N={len(d)})")
    for model, color in [("constant", "#0072B2"), ("linear", "#D55E00")]:
        q = curve[curve.model == model]; ax.plot(q.log_age, q.mu_alpha, color=color, lw=2, label=f"posterior-recycled {model}")
    ax.set(xlabel="log age [yr]", ylabel="MF slope α", title="H-MiMO chain-based population audit"); ax.grid(alpha=.2); ax.legend(frameon=False, fontsize=8)
    fig_path = out / "figure_h_mimo_summary.png"; fig.savefig(fig_path, dpi=220, facecolor="white", edgecolor="white", transparent=False); plt.close(fig)
    with Image.open(fig_path) as im: im.convert("RGB").save(fig_path, format="PNG", dpi=(220, 220))
    chain_candidates = sorted(str(x) for x in chain_paths)
    readme = args.catalog.parent / "ReadMe"
    archive = Path("cluster_params_posterior_chains.html")
    prov = {"catalog": str(args.catalog), "catalog_sha256": sha256(args.catalog), "readme": str(readme) if readme.exists() else None, "readme_sha256": sha256(readme) if readme.exists() else None, "archive": str(archive) if archive.exists() else None, "archive_sha256": sha256(archive) if archive.exists() else None, "chain_dir": str(args.chain_dir), "n_clusters": int(len(d)), "prime_only": not args.all_clusters, "draws": args.draws, "seed": args.seed, "chain_candidates": chain_candidates, "full_joint_chains_available": bool(use_chains), "chain_mode": "weighted_fits_chain" if use_chains else "summary_proxy", "interim_prior_assumption": "alpha_mf and log_age uniform within MiMO bounds; logwt supplies posterior weights", "alpha_age_covariance": "retained from weighted FITS rows" if use_chains else "independence approximation; unavailable", "physical_clock_inputs": "not present; t_rh and t_diss hierarchy not run", "status": "PILOT-CHAIN-READY" if use_chains else "DATA-BLOCKED"}
    (out / "provenance.json").write_text(json.dumps(prov, indent=2) + "\n")
    mode_label = "weighted FITS chains" if use_chains else "summary proxy"
    abs_corr = diagnostics.weighted_corr.abs().to_numpy()
    h1_nontrivial = float(np.mean(abs_corr >= 0.05))
    point_slope = float(point.loc[point.model == "linear", "beta1"].iloc[0])
    hierarchy_slope = float(hierarchy.loc[hierarchy.model == "linear", "beta1"].iloc[0])
    hierarchy_slope_sd = float(hierarchy.loc[hierarchy.model == "linear", "beta1_sd"].iloc[0])
    report = f"""# H-MiMO population audit\n\n**Status: `{prov['status']}`.** Parsed {len(d)} {'MF Prime' if not args.all_clusters else 'catalog'} clusters and ran the population likelihood in **{mode_label}** mode.\n\nThe FITS chains contain `log_age`, `alpha_mf`, and `logwt`; weighted resampling preserves the observed alpha–age covariance. Posterior recycling assumes the MiMO interim priors for these two parameters are uniform within their published bounds, so the prior ratio is constant over the retained support.\n\nThe executed comparison is point-estimate weighted regression versus posterior-recycled constant/linear population likelihood. Physical-clock models using $t/t_{{\\rm rh}}$ or $t/t_{{\\rm diss}}$ were not run because the required cluster-level dynamical inputs are absent.\n\nSummary values: point constant $\\beta_0={point.loc[point.model == 'constant', 'beta0'].iloc[0]:.3f}$; point linear $\\beta_1={point.loc[point.model == 'linear', 'beta1'].iloc[0]:.3f}$; recycled constant $\\sigma_{{\\rm int}}={hierarchy.loc[hierarchy.model == 'constant', 'sigma_int'].iloc[0]:.3f}$; recycled linear $\\beta_1={hierarchy.loc[hierarchy.model == 'linear', 'beta1'].iloc[0]:.3f}$. These are a first chain-based audit, not yet the physical-clock result.\n\nResults: `point_fit.csv`, `hierarchical_fit_summary_proxy.csv`, `hierarchical_curves_summary_proxy.csv`, and `chain_diagnostics.csv`. Figure: `figure_h_mimo_summary.png`.\n\n## Gate status\n\n- H1 posterior dependence: **RUN** (see `chain_diagnostics.csv`).\n- H2 point-to-hierarchy shift: **RUN / PILOT**.\n- H3 clock superiority: **NOT TESTED**.\n- H4 differential attribution: **NOT TESTED**.\n- H5 robustness: **NOT TESTED**.\n\nThe physical-clock hierarchy requires cluster-level $t_{{\\rm rh}}$ and $t_{{\\rm diss}}$ inputs. Until those are supplied, do not interpret the fitted age slope as evidence for dynamical-clock separation.\n"""
    report = report.replace("hierarchical_fit_summary_proxy.csv", "hierarchical_fit.csv").replace("hierarchical_curves_summary_proxy.csv", "hierarchical_curves.csv")
    report += f"\n\nChain diagnostic: {h1_nontrivial:.1%} of clusters have |rho(log_age, alpha)| >= 0.05; median |rho| = {float(np.median(abs_corr)):.3f}. The point-to-hierarchy slope shift is {hierarchy_slope - point_slope:+.3f}; the local Laplace scale for the recycled slope is {hierarchy_slope_sd:.3f}. These are audit diagnostics, not a final model-comparison claim.\n"
    (out / "report.md").write_text(report)
    print(json.dumps({"status": prov["status"], "n_clusters": len(d), "chains_found": bool(chain_candidates), "point": point.to_dict("records"), "hierarchy": hierarchy.to_dict("records")}, indent=2))


if __name__ == "__main__": main()
