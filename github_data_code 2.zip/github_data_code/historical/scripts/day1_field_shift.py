#!/usr/bin/env python3
"""Day-1 test for kinematic-selection-induced CMD covariate shift.

This is deliberately a pilot, not a claim about the full Gaia field
population.  The Hunt & Reffert member table is a candidate-star catalogue;
therefore the low-probability stars used here are a *proxy* control sample.
The script keeps the complete filtering and uncertainty audit in machine-
readable outputs so that an independent Gaia control-field analysis can use
the same frozen thresholds.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from PIL import Image
from scipy.stats import binomtest, ks_2samp


CLUSTER_COLS = [
    (0, 20), (21, 25), (280, 281), (282, 293), (294, 300),
    (474, 487), (488, 499), (511, 523), (524, 535),
    (547, 559), (560, 571),
]
CLUSTER_NAMES = [
    "Name", "ID", "Type", "CST", "N", "pmRA", "s_pmRA", "pmDE",
    "s_pmDE", "Plx", "s_Plx",
]
MEMBER_COLS = [
    (0, 7), (8, 28), (29, 33), (58, 78),
    (220, 243), (244, 265), (266, 289), (290, 310),
    (311, 334), (335, 355), (788, 807), (828, 847), (848, 871),
]
MEMBER_NAMES = [
    "Seq", "Name", "ID", "Prob", "pmRA", "e_pmRA", "pmDE", "e_pmDE",
    "Plx", "e_Plx", "Gmag", "RPmag", "BP_RP",
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def read_cluster_table(path: Path) -> pd.DataFrame:
    table = pd.read_fwf(path, colspecs=CLUSTER_COLS, names=CLUSTER_NAMES)
    numeric = [c for c in CLUSTER_NAMES if c not in {"Name", "Type"}]
    table[numeric] = table[numeric].apply(pd.to_numeric, errors="coerce")
    # Frozen benchmark selection: accepted open clusters with enough stars and
    # a non-trivial astrometric significance. No post-hoc cluster filtering.
    keep = (
        (table["Type"] == "o")
        & (table["N"] >= 50)
        & (table["CST"] >= 10)
        & np.isfinite(table[["pmRA", "s_pmRA", "pmDE", "s_pmDE", "Plx", "s_Plx"]]).all(axis=1)
        & (table[["s_pmRA", "s_pmDE", "s_Plx"]] > 0).all(axis=1)
    )
    return table.loc[keep].set_index("ID").sort_index()


def read_candidate_stars(path: Path, clusters: pd.DataFrame, chunk_size: int = 250_000) -> pd.DataFrame:
    """Read only columns needed for the audit, retaining the frozen proxy range."""
    pieces: list[pd.DataFrame] = []
    for chunk in pd.read_fwf(
        path, colspecs=MEMBER_COLS, names=MEMBER_NAMES, chunksize=chunk_size
    ):
        chunk = chunk[chunk["ID"].isin(clusters.index)].copy()
        if chunk.empty:
            continue
        joined = chunk.merge(
            clusters[["pmRA", "s_pmRA", "pmDE", "s_pmDE", "Plx", "s_Plx"]],
            left_on="ID", right_index=True, how="inner", suffixes=("", "_cl"),
        )
        # Mahalanobis-like diagonal distance. It intentionally includes the
        # reported star-level errors and cluster dispersions; full Gaia
        # covariance is reserved for the follow-up joint model.
        d2 = (
            ((joined["pmRA"] - joined["pmRA_cl"]) / np.sqrt(joined["s_pmRA"] ** 2 + joined["e_pmRA"] ** 2)) ** 2
            + ((joined["pmDE"] - joined["pmDE_cl"]) / np.sqrt(joined["s_pmDE"] ** 2 + joined["e_pmDE"] ** 2)) ** 2
            + ((joined["Plx"] - joined["Plx_cl"]) / np.sqrt(joined["s_Plx"] ** 2 + joined["e_Plx"] ** 2)) ** 2
        )
        joined["d_ast"] = np.sqrt(d2)
        # Retain a broad, predeclared proxy range so threshold sensitivity is
        # evaluated without re-reading the 1.3M-row fixed-width table.
        proxy = (
            (joined["Prob"] >= 0.05)
            & (joined["Prob"] < 0.75)
            & np.isfinite(joined[["d_ast", "Gmag", "BP_RP"]]).all(axis=1)
            & joined["Gmag"].between(5.0, 21.0)
            & joined["BP_RP"].between(-1.0, 5.0)
        )
        pieces.append(joined.loc[proxy, ["ID", "Prob", "d_ast", "Gmag", "BP_RP"]])
    if not pieces:
        raise RuntimeError("No candidate stars passed the frozen proxy filters")
    return pd.concat(pieces, ignore_index=True)


def summarize(stars: pd.DataFrame, clusters: pd.DataFrame, *, pmax: float, near: float, far: float, min_n: int) -> pd.DataFrame:
    records = []
    selected = stars[(stars["Prob"] < pmax) & (stars["d_ast"] <= near)]
    control = stars[(stars["Prob"] < pmax) & (stars["d_ast"] >= far)]
    for cid, near_group in selected.groupby("ID"):
        far_group = control[control["ID"] == cid]
        if len(near_group) < min_n or len(far_group) < min_n:
            continue
        color_near = near_group["BP_RP"].to_numpy()
        color_far = far_group["BP_RP"].to_numpy()
        g_near = near_group["Gmag"].to_numpy()
        g_far = far_group["Gmag"].to_numpy()
        ks = ks_2samp(color_near, color_far, alternative="two-sided", mode="auto")
        records.append(
            {
                "ID": int(cid),
                "Name": clusters.loc[cid, "Name"],
                "n_near": int(len(color_near)),
                "n_far": int(len(color_far)),
                "median_color_near": float(np.median(color_near)),
                "median_color_far": float(np.median(color_far)),
                "delta_median_color": float(np.median(color_near) - np.median(color_far)),
                "mean_color_near": float(np.mean(color_near)),
                "mean_color_far": float(np.mean(color_far)),
                "delta_mean_color": float(np.mean(color_near) - np.mean(color_far)),
                "median_G_near": float(np.median(g_near)),
                "median_G_far": float(np.median(g_far)),
                "delta_median_G": float(np.median(g_near) - np.median(g_far)),
                "ks_D_color": float(ks.statistic),
                "ks_p_color": float(ks.pvalue),
            }
        )
    return pd.DataFrame.from_records(records)


def bootstrap_mean(values: np.ndarray, rng: np.random.Generator, n_boot: int = 10_000) -> tuple[float, float, float]:
    if len(values) == 0:
        return float("nan"), float("nan"), float("nan")
    draws = rng.integers(0, len(values), size=(n_boot, len(values)))
    means = values[draws].mean(axis=1)
    return float(values.mean()), float(np.quantile(means, 0.025)), float(np.quantile(means, 0.975))


def make_figure(summary: pd.DataFrame, stars: pd.DataFrame, sensitivity: pd.DataFrame, path: Path) -> None:
    plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})
    fig, axes = plt.subplots(2, 2, figsize=(8.3, 6.6), layout="constrained")
    ax = axes[0, 0]
    ordered = summary.sort_values("delta_median_color").reset_index(drop=True)
    y = np.arange(len(ordered))
    ax.axvline(0, color="0.45", lw=0.8)
    ax.scatter(ordered["delta_median_color"], y, s=18, color="#0072B2", zorder=2)
    ax.set(xlabel=r"Near $-$ far median $G_{BP}-G_{RP}$ (mag)", ylabel="Cluster rank")
    ax.set_title("A. Cluster-level CMD shift", loc="left", weight="bold")

    ax = axes[0, 1]
    # Equal-cluster weighting prevents the largest catalogue entries from
    # visually dominating the pooled diagnostic.
    rng = np.random.default_rng(20260906)
    curves = []
    for cid in summary.ID:
        n = stars[(stars.ID == cid) & (stars.Prob < 0.5) & (stars.d_ast <= 1)].BP_RP.to_numpy()
        f = stars[(stars.ID == cid) & (stars.Prob < 0.5) & (stars.d_ast >= 6)].BP_RP.to_numpy()
        if len(n) and len(f):
            grid = np.linspace(-1, 5, 121)
            curves.append((grid, np.array([(n <= x).mean() for x in grid]), np.array([(f <= x).mean() for x in grid])))
    if curves:
        grid = curves[0][0]
        ax.plot(grid, np.mean([x[1] for x in curves], axis=0), color="#D55E00", label="near")
        ax.plot(grid, np.mean([x[2] for x in curves], axis=0), color="#0072B2", label="far")
    ax.set(xlabel=r"$G_{BP}-G_{RP}$ (mag)", ylabel="Equal-cluster mean CDF", xlim=(-1, 5), ylim=(0, 1))
    ax.legend(frameon=False)
    ax.set_title("B. Pooled CMD proxy", loc="left", weight="bold")

    ax = axes[1, 0]
    # Keep the primary (pmax=0.5) grid in the figure; pmax sensitivity remains
    # fully recorded in the CSV and is part of the audit below.
    primary = sensitivity[sensitivity["pmax"] == 0.5]
    p = primary.pivot(index="near", columns="far", values="median_delta")
    image = ax.imshow(p.to_numpy(), origin="lower", aspect="auto", cmap="RdBu_r", vmin=-1, vmax=1)
    ax.set_xticks(np.arange(len(p.columns)), [str(x) for x in p.columns])
    ax.set_yticks(np.arange(len(p.index)), [str(x) for x in p.index])
    for i in range(p.shape[0]):
        for j in range(p.shape[1]):
            if np.isfinite(p.iloc[i, j]):
                ax.text(j, i, f"{p.iloc[i,j]:.2f}", ha="center", va="center", fontsize=8)
    ax.set(xlabel="Far threshold $d_{ast}$", ylabel="Near threshold $d_{ast}$")
    fig.colorbar(image, ax=ax, label="Median colour shift (mag)")
    ax.set_title("C. Threshold sensitivity", loc="left", weight="bold")

    ax = axes[1, 1]
    rng = np.random.default_rng(20260906)
    for label, mask, color in [
        ("near", (stars.Prob < 0.5) & (stars.d_ast <= 1), "#D55E00"),
        ("far", (stars.Prob < 0.5) & (stars.d_ast >= 6), "#0072B2"),
    ]:
        sub = stars.loc[mask]
        if len(sub) > 6000:
            sub = sub.iloc[rng.choice(len(sub), 6000, replace=False)]
        ax.scatter(sub.BP_RP, sub.Gmag, s=2, alpha=0.16, color=color, label=label, rasterized=True)
    ax.invert_yaxis()
    ax.set(xlabel=r"$G_{BP}-G_{RP}$ (mag)", ylabel="$G$ (mag)", xlim=(-1, 5), ylim=(21, 5))
    ax.legend(frameon=False, markerscale=4)
    ax.set_title("D. CMD candidates", loc="left", weight="bold")
    fig.suptitle("Day-1 pilot: kinematic-selection-induced CMD shift", fontsize=11)
    fig.patch.set_facecolor("white")
    fig.savefig(path, dpi=220, facecolor="white", edgecolor="white", transparent=False)
    # Matplotlib may still emit an RGBA PNG; convert explicitly so the
    # delivered diagnostic has an opaque, reproducible background.
    with Image.open(path) as image:
        image.convert("RGB").save(path, format="PNG", dpi=(220, 220), optimize=True)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--clusters", type=Path, default=Path("hunt24/clusters.dat"))
    parser.add_argument("--members", type=Path, default=Path("hunt24/members_full.dat"))
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/day1_field_shift"))
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    out = args.output_dir
    out.mkdir(parents=True, exist_ok=True)
    targets = [out / x for x in ["cluster_summary.csv", "sensitivity.csv", "figure1_day1.png", "report.md", "provenance.json"]]
    if not args.force and any(x.exists() for x in targets):
        raise SystemExit("Output exists; pass --force only after checking the previous run")

    clusters = read_cluster_table(args.clusters)
    stars = read_candidate_stars(args.members, clusters)
    summary = summarize(stars, clusters, pmax=0.5, near=1.0, far=6.0, min_n=10)
    if summary.empty:
        raise RuntimeError("No clusters passed the frozen two-sided minimum-count gate")
    rng = np.random.default_rng(20260906)
    mean_delta, lo, hi = bootstrap_mean(summary.delta_median_color.to_numpy(), rng)
    sign_p = float(binomtest(int((summary.delta_median_color > 0).sum()), len(summary), 0.5).pvalue)

    rows = []
    for pmax in (0.25, 0.5, 0.75):
        for near in (0.75, 1.0, 1.5):
            for far in (4.0, 6.0, 8.0):
                s = summarize(stars, clusters, pmax=pmax, near=near, far=far, min_n=10)
                rows.append({
                    "pmax": pmax, "near": near, "far": far, "n_clusters": len(s),
                    "median_delta": float(s.delta_median_color.median()) if len(s) else float("nan"),
                    "mean_delta": float(s.delta_median_color.mean()) if len(s) else float("nan"),
                    "positive_fraction": float((s.delta_median_color > 0).mean()) if len(s) else float("nan"),
                })
    sensitivity = pd.DataFrame(rows)
    # Underpowered threshold combinations are recorded but are not scored as
    # failures; the gate is evaluated only among grids with at least 20
    # clusters, as predeclared for the pilot.
    eligible = sensitivity[sensitivity.n_clusters >= 20]
    robust = (eligible.median_delta > 0) & (eligible.positive_fraction >= 0.75)
    robust_fraction = float(robust.mean()) if len(eligible) else 0.0
    status = "GO-PILOT" if len(summary) >= 20 and lo > 0 and sign_p < 0.01 and robust_fraction >= 2 / 3 else "NO-GO"

    summary.to_csv(out / "cluster_summary.csv", index=False)
    sensitivity.to_csv(out / "sensitivity.csv", index=False)
    make_figure(summary, stars, sensitivity, out / "figure1_day1.png")
    provenance = {
        "analysis": "Day-1 field-shift pilot",
        "status": status,
        "seed": 20260906,
        "raw_data": {
            "clusters": str(args.clusters), "clusters_sha256": sha256(args.clusters),
            "members": str(args.members), "members_sha256": sha256(args.members),
        },
        "frozen_filters": {
            "cluster": "Type == 'o', N >= 50, CST >= 10",
            "proxy": "0.05 <= Prob < 0.75, 5 <= G <= 21, -1 <= BP-RP <= 5",
            "main_near": "d_ast <= 1", "main_far": "d_ast >= 6",
            "main_min_count": 10,
        },
        "counts": {"clusters": int(len(clusters)), "proxy_stars": int(len(stars)), "main_clusters": int(len(summary))},
        "main_estimate": {"equal_cluster_mean_delta_median": mean_delta, "bootstrap95": [lo, hi], "sign_test_p": sign_p},
        "sensitivity_gate": {"eligible_configs": int(len(eligible)), "robust_configs": int(robust.sum()), "robust_fraction": robust_fraction},
        "caveat": "members_full is a candidate-star table, not an independent Gaia control field; this is a hypothesis-generating pilot.",
    }
    (out / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
    report = f"""# Day-1 field-shift pilot\n\n## Frozen result\n\n**Status: `{status}`.** The main proxy analysis contains {len(summary)} clusters. The equal-cluster mean of the per-cluster near-minus-far median colour difference is **{mean_delta:.3f} mag** (cluster bootstrap 95% interval {lo:.3f} to {hi:.3f}); the exact sign-test p-value is **{sign_p:.3g}**.\n\nThe sensitivity grid is in `sensitivity.csv`; the rendered diagnostic is `figure1_day1.png`. Of the {len(eligible)} sensitivity configurations with at least 20 clusters, {int(robust.sum())} meet the positive-shift criterion (fraction {robust_fraction:.3f}); underpowered grids remain recorded but are not scored as failures.\n\n## Definition\n\nFor accepted open clusters with `N >= 50` and `CST >= 10`, `d_ast` is a diagonal astrometric distance in (pmRA, pmDE, parallax), using the published cluster dispersions plus star-level errors. The proxy field sample is `0.05 <= Prob < 0.5`. “Near” means `d_ast <= 1`; “far” means `d_ast >= 6`. A cluster enters the summary only when both groups contain at least 10 stars. The estimator is the difference in medians of `BP-RP`; clusters receive equal weight.\n\n## Interpretation and gate\n\nThis supports a **pilot GO** only if the status is `GO-PILOT`; it does not establish the full Gaia claim because `members_full.dat` is itself a candidate-star catalogue produced by a cluster-search pipeline. The low-probability stars are therefore not an independent control field, and the PM/parallax distance is diagonal rather than the full Gaia covariance. No MiMO posterior is re-fit here.\n\nThe confirmatory G1 experiment must repeat the same frozen thresholds on independent Gaia control fields, stratified by `(l,b, parallax)` and with the field sample defined before inspecting CMD differences. Until that exists, the result is hypothesis-generating and must not be described as a measured population-level bias.\n\n## Reproducibility\n\nRun from the repository root with `/opt/anaconda3/bin/python scripts/day1_field_shift.py --force`. Raw-file SHA-256 hashes, filters, seed, counts, and caveats are in `provenance.json`.\n"""
    (out / "report.md").write_text(report)
    print(json.dumps({"status": status, "main_clusters": len(summary), "mean_delta": mean_delta, "bootstrap95": [lo, hi], "sign_test_p": sign_p}, indent=2))


if __name__ == "__main__":
    main()
