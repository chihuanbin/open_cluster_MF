#!/usr/bin/env python3
"""Frozen EIV mechanism closure for the H-MiMO Phase-II pilot.

The simulation uses the observed MF-Prime age and alpha uncertainty scales,
injects a fixed true slope beta=0.50, and compares (i) a point regression
that treats ages as exact with (ii) the Gaussian errors-in-variables
population likelihood. This is a mechanism closure, not the final broken
hyperposterior.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize

from hierarchical_mimo_summary import read_catalog


def fit_point(x, y, sy):
    w = 1.0 / np.maximum(sy, 0.02) ** 2
    X = np.column_stack([np.ones(len(x)), x - 8.5])
    beta = np.linalg.solve(X.T @ (w[:, None] * X), X.T @ (w * y))
    return float(beta[1])


def fit_eiv(x, y, sx, sy):
    sx = np.maximum(sx, 1e-4); sy = np.maximum(sy, 0.01)
    def nll(p):
        b0, b1, log_sig = p; sig = np.exp(log_sig)
        var = sig * sig + sy * sy + (b1 * sx) ** 2
        z = (y - b0 - b1 * (x - 8.5)) / np.sqrt(var)
        return float(0.5 * np.sum(z * z + np.log(2 * np.pi * var)))
    r = minimize(nll, [-2.0, 0.5, np.log(0.3)], method="L-BFGS-B", bounds=[(-5, 1), (-3, 3), (np.log(.005), np.log(2))])
    return float(r.x[1]), bool(r.success)


def main():
    p = argparse.ArgumentParser(); p.add_argument("--catalog", type=Path, default=Path("data/mimo_catalog/table3.dat")); p.add_argument("--output-dir", type=Path, default=Path("outputs/eiv_injection_closure")); p.add_argument("--n-sim", type=int, default=1000); p.add_argument("--seed", type=int, default=20260906); p.add_argument("--force", action="store_true")
    a = p.parse_args(); out = a.output_dir; out.mkdir(parents=True, exist_ok=True)
    if (out / "report.md").exists() and not a.force: raise SystemExit("Output exists; pass --force")
    d = read_catalog(a.catalog, prime_only=True)
    x0 = d.logage50.to_numpy(); sx = np.maximum((d.logage84.to_numpy() - d.logage16.to_numpy()) / 2.0, 0.003); sy = np.maximum((d.alpha84.to_numpy() - d.alpha16.to_numpy()) / 2.0, 0.02)
    rng = np.random.default_rng(a.seed); beta_true = 0.50; b0_true = -2.0; sig_true = 0.30; rows = []
    for k in range(a.n_sim):
        tau_true = x0.copy(); alpha_true = b0_true + beta_true * (tau_true - 8.5) + rng.normal(0, sig_true, len(d))
        x = tau_true + rng.normal(0, sx); y = alpha_true + rng.normal(0, sy)
        bp = fit_point(x, y, sy); be, ok = fit_eiv(x, y, sx, sy)
        rows.append({"rep": k, "beta_point": bp, "beta_eiv": be, "eiv_success": ok})
    r = pd.DataFrame(rows); r.to_csv(out / "replicates.csv", index=False)
    summary = {"beta_true": beta_true, "n_sim": a.n_sim, "point_mean": float(r.beta_point.mean()), "point_bias": float(r.beta_point.mean() - beta_true), "point_median": float(r.beta_point.median()), "eiv_mean": float(r.beta_eiv.mean()), "eiv_bias": float(r.beta_eiv.mean() - beta_true), "eiv_median": float(r.beta_eiv.median()), "eiv_success_rate": float(r.eiv_success.mean()), "point_bias_below_minus_0p10": float(np.mean(r.beta_point - beta_true < -0.10)), "eiv_abs_bias_below_0p05": float(np.mean(np.abs(r.beta_eiv - beta_true) < 0.05))}
    (out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    closure_status = "EIV-CLOSURE-NO-GO" if abs(summary["point_bias"]) < 0.10 else "EIV-CLOSURE-PASS-PILOT"
    (out / "provenance.json").write_text(json.dumps({"status": closure_status, "truth": {"beta": beta_true, "beta0": b0_true, "sigma_int": sig_true}, "n_clusters": len(d), "n_sim": a.n_sim, "seed": a.seed, "age_uncertainty_source": "table3 16/84 half-width", "alpha_uncertainty_source": "table3 16/84 half-width", "point_model": "weighted regression ignoring x uncertainty", "eiv_model": "Gaussian marginal likelihood with sigma_y^2 + beta1^2 sigma_x^2"}, indent=2) + "\n")
    (out / "report.md").write_text(f'''# EIV injection/recovery closure

Status: **`{closure_status}`**; {a.n_sim} simulations, {len(d)} MF Prime clusters per simulation.

Injected truth: beta1={beta_true:.2f}, beta0={b0_true:.2f}, intrinsic scatter={sig_true:.2f}. The age and alpha uncertainty scales are taken from the catalog 16/84 intervals. The point estimator ignores age uncertainty; the EIV estimator integrates it analytically in the Gaussian variance term.

| estimator | mean beta1 | bias |
|---|---:|---:|
| point | {summary['point_mean']:.4f} | {summary['point_bias']:+.4f} |
| EIV | {summary['eiv_mean']:.4f} | {summary['eiv_bias']:+.4f} |

Point bias below −0.10 occurs in {summary['point_bias_below_minus_0p10']:.1%} of replicates; EIV absolute bias below 0.05 occurs in {summary['eiv_abs_bias_below_0p05']:.1%}. Under this frozen Gaussian injection, the point estimator is not systematically attenuated, so the proposed classical EIV mechanism is **not confirmed**. This is an important negative control, not a substitute for the final chain-based broken hyperposterior.
''')
    print(json.dumps(summary, indent=2))


if __name__ == "__main__": main()
