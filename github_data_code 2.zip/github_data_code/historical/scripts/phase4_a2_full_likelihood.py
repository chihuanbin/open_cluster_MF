#!/usr/bin/env python3
"""Outcome-blind full broken-likelihood, null-calibrated PSIS--LOO A2.

No observed MF slope, alpha uncertainty, or MiMO chain is read.  Synthetic
outcomes are generated from a smoothly-broken age relation plus an optional
fixed-age exposure effect.  Each realization fits the nonlinear broken mean
and intrinsic scatter, draws a Laplace approximation to its posterior, and
uses Pareto-smoothed importance sampling for cluster-level LOO.
"""
from __future__ import annotations
import json
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize, least_squares
from scipy.special import logsumexp

ROOT = Path(__file__).resolve().parents[1]; OUT = ROOT / "outputs/phase4"

def mean_broken(t, p):
    y0, a, delta, x0, lw = p[:5]; w = np.exp(lw); z = (t-x0)/w
    return y0 + a*(t-x0) + delta*w*np.logaddexp(0.0, z)

def loglik(p, t, y, sy, z, use_exp):
    mu = mean_broken(t, p) + (p[5] * z if use_exp else 0.0)
    sint = np.exp(p[6] if use_exp else p[5]); s = np.sqrt(sy*sy + sint*sint)
    r = (y-mu)/s
    return float(-0.5*np.sum(r*r + np.log(2*np.pi*s*s)))

def jacobian_mu(p, t, z, use_exp):
    # Numerical derivatives are stable here and keep the exact nonlinear mean.
    k = 7 if use_exp else 6; J = np.empty((len(t), k)); base = mean_broken(t,p)
    for j in range(5):
        h = 1e-4 if j != 4 else 2e-4; q=p.copy(); q[j]+=h
        J[:,j]=(mean_broken(t,q)-base)/h
    if use_exp: J[:,5]=z
    # Derivative wrt log intrinsic scatter is not a mean derivative; Fisher term.
    J[:,-1]=0.0
    return J

def fit_and_loo(t, y, sy, z, use_exp, rng, ndraw=128):
    # Profile the nonlinear knot/width on a frozen grid; all remaining
    # coefficients and scatter are solved analytically.  This is the same
    # broken likelihood, but makes 6,000 design realizations tractable.
    best=None; sy0=float(sy[0]); grids=[(xx,ww) for xx in np.linspace(8.5,9.3,7) for ww in np.linspace(.25,.75,5)]
    for xx,ww in grids:
        B=np.column_stack([np.ones(len(t)), t-xx, ww*np.logaddexp(0,(t-xx)/ww)] + ([z] if use_exp else []))
        beta=np.linalg.lstsq(B,y,rcond=None)[0]; res=y-B@beta; sint=np.sqrt(max(np.mean(res*res)-sy0*sy0,1e-6)); s=np.sqrt(sy0*sy0+sint*sint)
        ll=-.5*np.sum((res/s)**2+np.log(2*np.pi*s*s))
        if best is None or ll>best[0]: best=(ll,B,beta,sint,xx,ww)
    if best is None: return np.nan,np.nan,np.nan,np.nan,False
    _,B,beta,sint,xx,ww=best; k=B.shape[1]+1; s=np.sqrt(sy0*sy0+sint*sint)
    cov=np.zeros((k,k)); cov[:k-1,:k-1]=s*s*np.linalg.pinv(B.T@B); cov[-1,-1]=1/(2*len(t))
    ev,U=np.linalg.eigh((cov+cov.T)/2); ev=np.maximum(ev,1e-10); cov=(U*ev)@U.T
    pp=np.r_[beta,np.log(sint)]; draws=rng.multivariate_normal(pp,cov,size=ndraw); draws[:,-1]=np.clip(draws[:,-1],-3,1.5)
    ll=np.empty((ndraw,len(t)))
    for i,q in enumerate(draws):
        mm=B@q[:-1]; ss=np.sqrt(sy*sy+np.exp(q[-1])**2)
        ll[i]=-.5*((y-mm)/ss)**2-.5*np.log(2*np.pi*ss*ss)
    # PSIS with a conservative generalized-Pareto tail fit (same construction
    # used by the independent Phase-III implementation).
    elpd=np.empty(len(t)); ks=[]
    for j in range(len(t)):
        lr=-ll[:,j]; m0=np.max(lr); w=np.exp(lr-m0); order=np.argsort(w); mtail=max(20,int(3*np.sqrt(ndraw))); idx=order[-mtail:]; thr=w[order[-mtail-1]]
        exc=np.maximum(w[idx]/max(thr,1e-300)-1,0); m1=exc.mean(); v=exc.var(ddof=1)
        kk=0.5*(1-m1*m1/v) if v>m1*m1 and v>0 else 0.0; kk=float(np.clip(kk,-.5,1.5)); scale=max(m1*(1-kk),1e-12)
        pp=(np.arange(1,mtail+1)-.5)/mtail
        qq=-scale*np.log1p(-pp) if abs(kk)<1e-8 else scale/kk*((1-pp)**(-kk)-1)
        sm=np.log(max(thr,1e-300)+qq); out=lr-m0; out[idx]=np.minimum(sm,np.max(out)); out-=logsumexp(out)
        elpd[j]=logsumexp(ll[:,j]+out); ks.append(kk)
    return float(beta[-1] if use_exp else 0), float(beta[-1]/np.sqrt(max(cov[-2,-2],1e-12)) if use_exp else 0), float(np.sum(elpd)), float(np.max(ks)), True

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--n-sim',type=int,default=1000); ap.add_argument('--posterior-draws',type=int,default=128); args=ap.parse_args()
    b=pd.read_parquet(OUT/'CLOCK_FREEZE_B.parquet'); t=b.log_age_50.to_numpy(float); eta=b.eta_diss_50.to_numpy(float)
    age_mu=mean_broken(t,np.array([0,-.15,.35,8.95,np.log(.4)])); A=np.column_stack([np.ones(len(t)),t-8.95,(t-8.95)**2]); er=eta-A@np.linalg.lstsq(A,eta,rcond=None)[0]; z=er/er.std(ddof=1)
    sy=np.full(len(t),.25); rng=np.random.default_rng(20260907); gammas=[0,.2,.4,.6,.8,1.0]; ns=args.n_sim
    # Fit age-only and age+exposure to every realization; the LOO contrast is
    # paired within realization, then calibrated against the null distribution.
    allres={g:[] for g in gammas}
    for g in gammas:
        for i in range(ns):
            y=age_mu+g*z+rng.normal(0,1.0,len(t))
            c0=fit_and_loo(t,y,sy,z,False,rng,ndraw=args.posterior_draws); c1=fit_and_loo(t,y,sy,z,True,rng,ndraw=args.posterior_draws)
            allres[g].append((c0,c1))
        print('completed gamma',g,flush=True)
    null=np.array([q[1][2]-q[0][2] for q in allres[0] if q[0][4] and q[1][4]])
    q95=float(np.quantile(null,.95)); q99=float(np.quantile(null,.99)); rows=[]
    for g in gammas:
        q=[x for x in allres[g] if x[0][4] and x[1][4]]; arr=np.array([[x[1][0],x[1][1],x[1][2]-x[0][2]] for x in q]);
        A=(arr[:,0]>.0)&(arr[:,1]>1.96)&(arr[:,0]>.3); B=arr[:,2]>q95
        rows.append({'gamma_star':g,'n_valid':len(arr),'conditional_hardA':float(A.mean()),'null_calibrated_hardB':float(B.mean()),'combined_power':float((A&B).mean()),'median_delta_elpd':float(np.median(arr[:,2]))})
    result={'status':'PHASE_IV_A2_FULL_LIKELIHOOD_CALIBRATED_OUTCOME_LOCKED','outcome_blind':True,'alpha_read':False,'n_clusters':len(t),'n_sim_per_gamma':ns,'posterior_draws_per_fit':args.posterior_draws,'measurement_error_template':'generic sy=0.25 for every cluster; intrinsic synthetic scatter=1','model':'nonlinear smoothly-broken mean with free knot, width, intrinsic scatter; exposure coefficient in alternative','loo':'Laplace posterior draws with Pareto-smoothed importance sampling, cluster-level','null_thresholds':{'q95_delta_elpd':q95,'q99_delta_elpd':q99,'fpr_combined_rule':rows[0]['combined_power']},'power':rows,'target_gamma_0p6_combined_power':next(x['combined_power'] for x in rows if x['gamma_star']==.6),'decision':'Do not unlock alpha. A2 unlock remains conditional on this calibration being independently reviewed and on FPR<=0.05 and target power>=0.80.'}
    (OUT/'A2_FULL_LIKELIHOOD_POWER.json').write_text(json.dumps(result,indent=2)+'\n'); pd.DataFrame(rows).to_csv(OUT/'A2_FULL_LIKELIHOOD_POWER.csv',index=False)
    (OUT/'A2_FULL_LIKELIHOOD_POWER.md').write_text('\n'.join(['# Phase IV-A2 full-likelihood power calibration','', '**Outcome remains locked.** No alpha or MiMO chain was read.','',f"Null-calibrated Q95(Delta ELPD) = {q95:.4f}; Q99 = {q99:.4f}.",f"Combined-rule null FPR = {rows[0]['combined_power']:.4f}.",f"Combined-rule power at gamma*=0.6 = {result['target_gamma_0p6_combined_power']:.4f}.", '', 'This is a synthetic full broken-likelihood/Laplace-PSIS design calibration with a generic uncertainty template; it is not a real-data outcome analysis.', '',pd.DataFrame(rows).to_string(index=False)])+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__': main()
