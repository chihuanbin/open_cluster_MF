#!/usr/bin/env python3
"""Frozen A2 real-data M0/M1/M2 analysis (first authorized alpha access).

Uses the hashed A2 rules file and reads the public MF summary alpha columns
only after verifying the hash.  The primary M1 is age plus orthogonal
dissolution exposure; M0 and M2 are the frozen comparators.  This is a formal
emcee posterior run with cluster-level PSIS-style importance LOO.  No clock or
sample definition is changed here.
"""
from __future__ import annotations
import hashlib, json
from pathlib import Path
import emcee, numpy as np, pandas as pd
from scipy.special import logsumexp
from scipy.stats import norm
from hierarchical_mimo_summary import read_catalog

ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'outputs/phase4'; RULE=OUT/'A2_REALDATA_RULES.yaml'
def sh(path):
 h=hashlib.sha256(); h.update(path.read_bytes()); return h.hexdigest()
def broken(x,p):
 y,a,d,x0,lw=p[:5]; w=np.exp(lw); return y+a*(x-x0)+d*w*np.logaddexp(0,(x-x0)/w)
def psis_norm(lr):
 lr=np.asarray(lr,float); n=len(lr); lw=lr-lr.max(); order=np.argsort(lw); m=min(max(20,int(3*np.sqrt(n))),n//2); idx=order[-m:]; thr=lw[order[-m-1]]; exc=np.maximum(np.exp(lw[idx]-thr)-1,0); m1=exc.mean(); v=exc.var(ddof=1); k=.5*(1-m1*m1/v) if v>m1*m1 and v>0 else 0.; k=float(np.clip(k,-.5,1.5)); scale=max(m1*(1-k),1e-12); p=(np.arange(1,m+1)-.5)/m; q=-scale*np.log1p(-p) if abs(k)<1e-8 else scale/k*((1-p)**(-k)-1); sm=thr+np.log1p(q); out=lw.copy(); out[idx]=np.minimum(sm,np.max(lw)); return out-logsumexp(out),k
def run_model(x,y,sy,z,kind,seed=20260907):
 use=kind=='M1'; xx=z if kind=='M2' else x; k=7 if use else 6
 def lp(p):
  if not(-5<p[0]<2 and -5<p[1]<5 and -5<p[2]<5 and 7<p[3]<10.2 and -2.5<p[4]<3.5 and -5<p[-1]<1.5): return -np.inf
  if use and not(-3<p[5]<3): return -np.inf
  mu=broken(xx,p)+(p[5]*z if use else 0); s=np.sqrt(sy*sy+np.exp(p[-1])**2); return float(np.sum(norm.logpdf(y,mu,s)))
 p0=np.array([-.5,-.2,.5,8.9,np.log(.4)]+([0.] if use else [])+[np.log(.3)])
 rng=np.random.default_rng(seed); pos=p0+1e-2*rng.normal(size=(32,k)); sampler=emcee.EnsembleSampler(32,k,lp); sampler.run_mcmc(pos,1200,progress=False); sampler.reset(); sampler.run_mcmc(None,2500,progress=False)
 draws=sampler.get_chain(flat=True,thin=5); ll=np.empty((len(draws),len(x)))
 for i,p in enumerate(draws):
  mu=broken(xx,p)+(p[5]*z if use else 0); s=np.sqrt(sy*sy+np.exp(p[-1])**2); ll[i]=norm.logpdf(y,mu,s)
 el=[]; ks=[]
 for j in range(len(x)):
  lw,kj=psis_norm(-ll[:,j]); el.append(float(logsumexp(ll[:,j]+lw))); ks.append(kj)
 return {'draws':draws,'ll':ll,'elpd':np.array(el),'pareto_k_max':float(np.nanmax(ks)),'acceptance':float(np.mean(sampler.acceptance_fraction)),'rhat_proxy':float(np.nanmax(np.std(sampler.get_chain()[-500:],axis=0)/np.maximum(np.std(sampler.get_chain()[:500],axis=0),1e-9)))}
def main():
 expected=(OUT/'A2_REALDATA_RULES.sha256').read_text().split()[0]
 if sh(RULE)!=expected: raise SystemExit('A2 rules hash mismatch; refusing alpha access')
 d=read_catalog(ROOT/'data/mimo_catalog/table3.dat',prime_only=True); b=pd.read_parquet(OUT/'CLOCK_FREEZE_B.parquet'); d=d.merge(b[['cluster','log_age_50','eta_diss_50']],left_on='cluster',right_on='cluster',validate='one_to_one').dropna()
 x=d.log_age_50.to_numpy(float); z0=d.eta_diss_50.to_numpy(float); A=np.column_stack([np.ones(len(x)),x-x.mean(),(x-x.mean())**2]); z=(z0-A@np.linalg.lstsq(A,z0,rcond=None)[0]); z/=z.std(ddof=1); y=d.alpha50.to_numpy(float); sy=np.maximum((d.alpha84-d.alpha16).to_numpy(float)/2,.02)
 fits={k:run_model(x,y,sy,z,k) for k in ['M0','M1','M2']}; el={k:v['elpd'] for k,v in fits.items()}; delta=float(np.sum(el['M1']-el['M0'])); gamma=fits['M1']['draws'][:,5]; ppos=float(np.mean(gamma>0)); gstar=float(np.median(gamma)/np.std(z,ddof=1)); result={'status':'A2_REALDATA_ANALYSIS_COMPLETE','rules_sha256':sh(RULE),'alpha_accessed_after_hash':True,'n_clusters':len(d),'models':['M0_age_only','M1_age_plus_orthogonal_dissolution','M2_dissolution_only'],'M1_gamma_median':float(np.median(gamma)),'M1_gamma_16_84':[float(np.quantile(gamma,.16)),float(np.quantile(gamma,.84))],'P_gamma_gt_0':ppos,'standardized_effect_gamma_star':gstar,'delta_ELPD_M1_minus_M0':delta,'primary_pass':bool(ppos>.975 and gstar>.30 and delta>1.0245),'sampler':'emcee formal posterior; 32 walkers, 2500 production steps, thin=5','loo':'cluster-level PSIS with generalized-Pareto tail smoothing from posterior draws','pareto_k_max':{k:float(v['pareto_k_max']) for k,v in fits.items()},'outcome_lock':'alpha access authorized by frozen hash; no clock/sample changes'}
 (OUT/'A2_REALDATA_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n'); pd.DataFrame([{'model':k,'acceptance':v['acceptance'],'n_draws':len(v['draws'])} for k,v in fits.items()]).to_csv(OUT/'A2_REALDATA_SAMPLER.csv',index=False); (OUT/'A2_REALDATA_RESULTS.md').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))
if __name__=='__main__': main()
