#!/usr/bin/env python3
"""Build the outcome-blind HR24 member-level dynamics summary.

Only Hunt--Reffert cluster/member products are read.  MiMO chains, alpha
columns, and any alpha-derived quantity are deliberately absent from this
program.  The output is therefore safe to freeze before merging an outcome
catalogue.  It reconstructs probability-weighted member count, observed mass,
projected half-number/half-mass radii, and Gaia-RVS systemic-velocity coverage.
It does not infer a 3-D half-mass radius or integrate an orbit.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
CLUSTER_SPECS = {
    "name": (0, 20), "id": (21, 25), "RAdeg": (319, 331), "DEdeg": (332, 344),
    "dist50": (599, 614), "N": (294, 300), "r50pc": (418, 431), "NJ": (1002, 1006),
    "MassJ": (1007, 1022),
    "e_MassJ": (1023, 1038), "MassTot": (1039, 1054), "e_MassTot": (1055, 1070),
}
MEMBER_SLICES = {
    "id": (29, 33), "inrj": (54, 55), "inrt": (56, 57), "prob": (58, 78),
    "ra": (79, 103), "dec": (126, 148), "rv": (920, 942), "e_rv": (943, 963),
    "mass16": (1114, 1134), "mass50": (1135, 1155), "mass84": (1156, 1176),
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def norm(x: object) -> str:
    return "".join(ch for ch in str(x).strip().lower() if ch.isalnum())


def read_clusters(path: Path) -> pd.DataFrame:
    names = list(CLUSTER_SPECS)
    d = pd.read_fwf(path, colspecs=[CLUSTER_SPECS[x] for x in names], names=names, dtype=str).fillna("")
    for c in names:
        if c != "name":
            d[c] = pd.to_numeric(d[c].str.strip().replace({"": np.nan, "?": np.nan}), errors="coerce")
    return d


def parse_float(line: bytes, sl: tuple[int, int]) -> float:
    try:
        value = line[sl[0]:sl[1]].decode("ascii", errors="ignore").strip()
        return float(value) if value and value != "?" else math.nan
    except (ValueError, UnicodeDecodeError):
        return math.nan


def parse_int(line: bytes, sl: tuple[int, int]) -> int:
    value = parse_float(line, sl)
    return int(value) if math.isfinite(value) else -1


def summarize_members(member_path: Path, targets: dict[int, dict[str, float]]) -> pd.DataFrame:
    # Lists are bounded by the HR24 target membership tables (not the entire
    # catalogue) and are needed to calculate radius order statistics.
    rows: dict[int, list[tuple[float, float, float, float, float, int, float, float, int, int]]] = {i: [] for i in targets}
    with member_path.open("rb") as fh:
        for line in fh:
            cid = parse_int(line, MEMBER_SLICES["id"])
            if cid not in targets:
                continue
            p = parse_float(line, MEMBER_SLICES["prob"])
            if not math.isfinite(p) or p <= 0:
                continue
            inrj = parse_int(line, MEMBER_SLICES["inrj"]) == 1
            inrt = parse_int(line, MEMBER_SLICES["inrt"]) == 1
            ra = parse_float(line, MEMBER_SLICES["ra"])
            dec = parse_float(line, MEMBER_SLICES["dec"])
            m50 = parse_float(line, MEMBER_SLICES["mass50"])
            m16 = parse_float(line, MEMBER_SLICES["mass16"])
            m84 = parse_float(line, MEMBER_SLICES["mass84"])
            rv = parse_float(line, MEMBER_SLICES["rv"])
            erv = parse_float(line, MEMBER_SLICES["e_rv"])
            if not (math.isfinite(ra) and math.isfinite(dec)):
                continue
            c = targets[cid]
            # Great-circle distance in radians, converted to projected pc.
            ra1, ra2 = math.radians(ra), math.radians(c["RAdeg"])
            dec1, dec2 = math.radians(dec), math.radians(c["DEdeg"])
            hav = math.sin((dec1 - dec2) / 2) ** 2 + math.cos(dec1) * math.cos(dec2) * math.sin((ra1 - ra2) / 2) ** 2
            theta = 2 * math.asin(min(1.0, math.sqrt(max(0.0, hav))))
            radius_pc = c["dist50"] * theta if math.isfinite(c["dist50"]) else math.nan
            rows[cid].append((p, m50, m16, m84, radius_pc, int(math.isfinite(rv) and math.isfinite(erv)), rv, erv, int(inrt), int(inrj)))

    records = []
    for cid, vals in rows.items():
        c = targets[cid]
        arr = pd.DataFrame(vals, columns=["prob", "mass50", "mass16", "mass84", "radius_pc", "has_rv", "rv", "e_rv", "inrt", "inrj"])
        arr = arr[np.isfinite(arr.radius_pc)]
        if arr.empty:
            records.append({"hunt_id": cid, "cluster": c["name"], "status": "NO_INRJ_MEMBERS"})
            continue
        # Radius estimator used throughout is probability-weighted and
        # observable-mass based.  The three masks are frozen sensitivities:
        # (B) HR24 inrj population, (A) high-probability inrj, and (C) a
        # non-Jacobi fixed 3*r50pc aperture with p>=0.7.
        def radius_stats(sub: pd.DataFrame) -> tuple[float, float, float, float, float, float]:
            if sub.empty:
                return math.nan, math.nan, 0.0, 0.0, 0.0, 0.0
            wt = sub.prob.to_numpy()
            mm = sub.mass50.to_numpy()
            mm16 = sub.mass16.to_numpy()
            mm84 = sub.mass84.to_numpy()
            gm = np.isfinite(mm) & (mm > 0)
            mw = wt * np.where(gm, mm, 0.0)
            order = np.argsort(sub.radius_pc.to_numpy())
            rr = sub.radius_pc.to_numpy()[order]
            cn = np.cumsum(wt[order]); cm = np.cumsum(mw[order])
            hn = float(rr[np.searchsorted(cn, 0.5 * cn[-1], side="left")]) if cn[-1] > 0 else math.nan
            hm = float(rr[np.searchsorted(cm, 0.5 * cm[-1], side="left")]) if cm[-1] > 0 else math.nan
            m16_sum = float(np.sum(wt * np.where(np.isfinite(mm16) & (mm16 > 0), mm16, 0.0)))
            m84_sum = float(np.sum(wt * np.where(np.isfinite(mm84) & (mm84 > 0), mm84, 0.0)))
            return hn, hm, float(wt.sum()), float(mw.sum()), m16_sum, m84_sum

        base = arr[arr.inrj.eq(1)]
        highp = base[base.prob.ge(0.7)]
        r50 = c.get("r50pc", math.nan)
        fixed = arr[arr.prob.ge(0.7)]
        if math.isfinite(r50) and r50 > 0:
            fixed = fixed[fixed.radius_pc.le(3.0 * r50)]
        rh_n, rh_m, n_eff, m_obs, m_obs16, m_obs84 = radius_stats(base)
        rh_n_a, rh_m_a, n_eff_a, m_obs_a, m_obs16_a, m_obs84_a = radius_stats(highp)
        rh_n_c, rh_m_c, n_eff_c, m_obs_c, m_obs16_c, m_obs84_c = radius_stats(fixed)
        weight = base.prob.to_numpy()
        rv_mask = base.has_rv.to_numpy(dtype=bool) & np.isfinite(base.rv.to_numpy()) & np.isfinite(base.e_rv.to_numpy())
        rv_vals, rv_err, rv_w = base.rv.to_numpy()[rv_mask], base.e_rv.to_numpy()[rv_mask], weight[rv_mask]
        rv_mean = float(np.average(rv_vals, weights=rv_w)) if len(rv_vals) else math.nan
        rv_var = float(np.average((rv_vals - rv_mean) ** 2, weights=rv_w)) if len(rv_vals) else math.nan
        records.append({
            "hunt_id": cid, "cluster": c["name"], "status": "OK", "n_rows_inrj": len(base),
            "N_eff_inrj": n_eff, "M_obs_prob_M16": m_obs16, "M_obs_prob_M50": m_obs, "M_obs_prob_M84": m_obs84,
            "mass50_finite_fraction": float(np.isfinite(base.mass50.to_numpy()).mean()), "Rh_number_proj_pc": rh_n,
            "Rh_mass_proj_pc": rh_m, "n_RV_inrj": int(len(rv_vals)),
            "N_eff_inrj_p07": n_eff_a, "M_obs_prob_M16_inrj_p07": m_obs16_a,
            "M_obs_prob_M50_inrj_p07": m_obs_a, "M_obs_prob_M84_inrj_p07": m_obs84_a,
            "Rh_number_proj_inrj_p07_pc": rh_n_a, "Rh_mass_proj_inrj_p07_pc": rh_m_a,
            "N_eff_fixed3r50_p07": n_eff_c, "M_obs_prob_M16_fixed3r50_p07": m_obs16_c,
            "M_obs_prob_M50_fixed3r50_p07": m_obs_c, "M_obs_prob_M84_fixed3r50_p07": m_obs84_c,
            "Rh_number_proj_fixed3r50_p07_pc": rh_n_c, "Rh_mass_proj_fixed3r50_p07_pc": rh_m_c,
            "n_RV_fixed3r50_p07": int((fixed.has_rv.to_numpy(dtype=bool) & np.isfinite(fixed.rv.to_numpy()) & np.isfinite(fixed.e_rv.to_numpy())).sum()),
            "RV_weighted_mean_kms": rv_mean, "RV_weighted_dispersion_kms": math.sqrt(max(0.0, rv_var)) if math.isfinite(rv_var) else math.nan,
            "RV_median_kms": float(np.median(rv_vals)) if len(rv_vals) else math.nan,
            "n_inrt": int(arr.inrt.sum()), "hunt_MassJ": c["MassJ"], "hunt_e_MassJ": c["e_MassJ"],
            "hunt_MassTot": c["MassTot"], "hunt_e_MassTot": c["e_MassTot"],
            "hunt_N": c["N"], "hunt_NJ": c["NJ"], "hunt_r50pc": c["r50pc"],
        })
    return pd.DataFrame(records)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--clusters", type=Path, default=ROOT / "hunt24/clusters.dat")
    ap.add_argument("--members", type=Path, default=ROOT / "hunt24/members_full.dat")
    ap.add_argument("--match", type=Path, default=ROOT / "outputs/phase4/clock_input_match.csv")
    ap.add_argument("--out", type=Path, default=ROOT / "outputs/phase4")
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    clusters = read_clusters(args.clusters)
    match = pd.read_csv(args.match)
    match = match[match.match_status.eq("unique") & match.hunt_id.notna()].copy()
    lookup = clusters.set_index("id").to_dict("index")
    targets = {int(row.hunt_id): lookup[int(row.hunt_id)] for _, row in match.iterrows() if int(row.hunt_id) in lookup}
    result = summarize_members(args.members, targets)
    result.to_csv(args.out / "member_dynamics_summary.csv", index=False)
    report = {
        "status": "PASS_MEMBER_RECONSTRUCTION" if len(result) >= 150 and (result.status == "OK").sum() >= 150 else "DATA_BLOCKED",
        "outcome_blind": True, "n_target_unique": len(targets), "n_summary_rows": len(result),
        "n_ok": int((result.status == "OK").sum()), "n_no_inrj": int((result.status != "OK").sum()),
        "inputs": {"clusters": str(args.clusters), "clusters_sha256": sha256(args.clusters), "members": str(args.members), "members_sha256": sha256(args.members), "match": str(args.match), "match_sha256": sha256(args.match)},
        "source_integrity": "The uncompressed member table is used because the local members.dat.gz is truncated (gzip integrity test fails); line count is 1,291,929, matching the HR24 ReadMe record count.",
        "definitions": {"population": "primary structure uses Prob>=0.7 within 3*r50pc; inrj variants are sensitivities", "mass": "sum Prob*Mass16/50/84; no MiMO alpha", "Rh_mass_proj": "projected radius enclosing 50 percent of probability-weighted Mass50", "Rh_mass_proj_inrj_p07": "p>=0.7 subset of inrj=1 members (sensitivity)", "Rh_mass_proj_fixed3r50_p07": "primary: p>=0.7 members inside 3 times the HR24 half-number radius; no Jacobi cut", "RV": "inrj high-probability Gaia member RVs are fitted separately with a robust model", "deprojection": "not applied here; treated as a downstream nuisance parameter"},
        "limitations": ["Jacobi selection is inherited from HR24 and therefore receives a sensitivity using inrt/fixed radius in a later stage", "Mass50 is a member-level HR24 stellar-mass posterior summary, not a MiMO MF extrapolation", "No orbit integration or t_rh/t_diss is performed here"],
        "next_action": "Freeze this outcome-blind table, add independent 3-D radius/deprojection and orbit inputs, then compute clocks without reading MiMO alpha.",
    }
    (args.out / "member_dynamics_provenance.json").write_text(json.dumps(report, indent=2) + "\n")
    (args.out / "member_dynamics_summary.md").write_text("\n".join([
        "# Outcome-blind member dynamics reconstruction", "", f"Status: **{report['status']}**.", "",
        f"Processed {report['n_target_unique']} unique HR24 matches; {report['n_ok']} have usable `inrj=1` member rows and {report['n_no_inrj']} do not.",
        "The table contains probability-weighted member count, observed Mass50 sum, three projected half-mass-radius variants, and member-level Gaia-RVS coverage. It reads no MiMO chain or alpha field.",
        "The primary radius is Prob>=0.7 inside 3 times the HR24 half-number radius. The two inrj-based definitions are retained as sensitivities.",
        "A projected half-mass radius is not silently converted to a 3-D half-mass radius. Deprojection, orbit integration, and (t_{\\rm rh}/t_{\\rm diss}) remain gated inputs.",
        "The uncompressed source was used because the local `members.dat.gz` fails gzip integrity; its 1,291,929 lines match the HR24 record count.",
    ]) + "\n")
    print(json.dumps({"status": report["status"], "n_ok": report["n_ok"], "n_no_inrj": report["n_no_inrj"]}, indent=2))


if __name__ == "__main__":
    main()
