#!/usr/bin/env python3
"""Report Phase-IV independent-input coverage before any outcome merge.

Only HR24-derived match/member/orbit-pilot tables are read.  The census is a
coverage report, not a physical-clock analysis and deliberately has no MiMO
alpha/chains as an input.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def finite_count(frame: pd.DataFrame, columns: list[str]) -> int:
    return int(frame[columns].apply(pd.to_numeric, errors="coerce").notna().all(axis=1).sum())


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--catalogue", type=Path, default=ROOT / "outputs/phase4/outcome_blind_dynamics_pilot.csv")
    ap.add_argument("--out", type=Path, default=ROOT / "outputs/phase4")
    args = ap.parse_args(); args.out.mkdir(parents=True, exist_ok=True)
    d = pd.read_csv(args.catalogue)
    n = len(d)
    coverage = {
        "matched_systems": n,
        "MassJ_finite": int(pd.to_numeric(d.MassJ_hr24_Msun, errors="coerce").notna().sum()),
        "MassTot_finite": int(pd.to_numeric(d.MassTot_hr24_Msun, errors="coerce").notna().sum()),
        "N_hr24_finite": int(pd.to_numeric(d.N_hr24, errors="coerce").notna().sum()),
        "member_mass50_finite": int(pd.to_numeric(d.M_obs_prob_M50_Msun, errors="coerce").notna().sum()),
        "Rh_mass_proj_primary_finite": int(pd.to_numeric(d.Rh_mass_proj_primary_pc, errors="coerce").notna().sum()),
        "Rh_mass_proj_inrj_p07_finite": int(pd.to_numeric(d.Rh_mass_proj_inrj_p07_pc, errors="coerce").notna().sum()),
        "Rh_mass_proj_fixed3r50_p07_finite": int(pd.to_numeric(d.Rh_mass_proj_fixed3r50_p07_pc, errors="coerce").notna().sum()),
        "cluster_or_member_RV_ge3": int(pd.to_numeric(d.n_RV_member, errors="coerce").ge(3).sum()),
        "full_6D_astrometry_plus_RV": finite_count(d, ["RA_deg", "Dec_deg", "distance_pc", "pmRA_masyr", "pmDec_masyr", "RV_member_weighted_kms"]),
        "orbit_pilot_rows": int(d.orbit_status.notna().sum()),
        "orbit_confirmatory_rows": int(d.quality_orbit.eq("confirmatory_threshold").sum()),
    }
    report = {
        "status": "D0_INPUT_RECONSTRUCTION_PASS_D1_ORBIT_MC_OPEN",
        "outcome_blind": True,
        "coverage": coverage,
        "radius_sensitivity": {
            "median_abs_log10_ratio_primary_vs_inrj_all": float(np.nanmedian(np.abs(np.log10(d.Rh_mass_proj_primary_pc / d.Rh_mass_proj_pc)))),
            "median_abs_log10_ratio_primary_vs_inrj_p07": float(np.nanmedian(np.abs(np.log10(d.Rh_mass_proj_primary_pc / d.Rh_mass_proj_inrj_p07_pc)))),
        },
        "input": {"path": str(args.catalogue), "sha256": sha256(args.catalogue)},
        "gates": {
            "D0.1_mass_radius": "PASS; non-Jacobi projected radius is primary and 3-D deprojection is a frozen nuisance draw",
            "D0.2_RV": "PASS for >=3 member RVs in the matched sample",
            "D0.3_6D_representativeness": "NOT TESTED; alpha is intentionally absent from the blind census",
            "D0.4_clock_stability": "NOT TESTED; no t_rh/t_diss computed",
        },
        "limitations": ["The catalogue passed to this Day-0 census may still contain the low-draw orbit path test", "Projected-to-3D conversion is a downstream nuisance draw", "No MiMO alpha/chains are read"],
        "next_action": "Complete the already-open 5000-draw orbit propagation, compute clocks, and create CLOCK_FREEZE_A.",
    }
    (args.out / "day0_coverage_census.json").write_text(json.dumps(report, indent=2) + "\n")
    c = coverage
    (args.out / "day0_coverage_census.md").write_text("\n".join([
        "# Phase-IV Day-0 independent-input coverage census", "",
        f"Status: **{report['status']}**; {n} HR24 matches.", "",
        f"MassJ/MassTot/N coverage: {c['MassJ_finite']}/{c['MassTot_finite']}/{c['N_hr24_finite']}.",
        f"Projected half-mass radius coverage: primary {c['Rh_mass_proj_primary_finite']}, Prob>=0.7 inrj {c['Rh_mass_proj_inrj_p07_finite']}, fixed 3r50 Prob>=0.7 {c['Rh_mass_proj_fixed3r50_p07_finite']}.",
        f"RV coverage: {c['cluster_or_member_RV_ge3']} systems have >=3 member RVs; full astrometry+member-RV 6D rows: {c['full_6D_astrometry_plus_RV']}.",
        f"Orbit pilot rows: {c['orbit_pilot_rows']}; confirmatory orbit rows: {c['orbit_confirmatory_rows']} (expected zero for the two-draw path test).",
        f"Relative to the non-Jacobi primary, median absolute log-radius differences are {report['radius_sensitivity']['median_abs_log10_ratio_primary_vs_inrj_all']:.3f} dex (all inrj) and {report['radius_sensitivity']['median_abs_log10_ratio_primary_vs_inrj_p07']:.3f} dex (inrj p>=0.7).",
        "This census is outcome-blind and does not test representativeness against alpha. D1 orbit MC is open; it is a computation gate, not a data block.",
    ]) + "\n")
    print(json.dumps({"status": report["status"], **coverage}, indent=2))


if __name__ == "__main__":
    main()
