#!/usr/bin/env python3
"""Fetch frozen independent Gaia DR3 annuli for Gate 1B.

The query is intentionally a thin data-acquisition layer.  It does not
compute any Gate 1B estimand and it never reads candidate-star photometry;
Hunt source IDs are used only after retrieval to mask known candidate rows.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import time
from io import StringIO
from pathlib import Path

import numpy as np
import pandas as pd
import requests
import yaml


TAP_URL = "https://gea.esac.esa.int/tap-server/tap/sync"
TARGET_COLS = [
    (0, 20), (21, 25), (280, 281), (282, 293), (294, 300), (319, 331),
    (332, 344), (370, 381), (474, 487), (488, 499), (511, 523),
    (524, 535), (547, 559), (560, 571),
]
TARGET_NAMES = [
    "Name", "ID", "Type", "CST", "N", "ra", "dec", "r50", "pmra", "s_pmra",
    "pmdec", "s_pmdec", "parallax", "s_parallax",
]


def file_hash(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def targets_from_catalog(path: Path, ids: list[int]) -> pd.DataFrame:
    table = pd.read_fwf(path, colspecs=TARGET_COLS, names=TARGET_NAMES)
    numeric = [c for c in TARGET_NAMES if c not in {"Name", "Type"}]
    table[numeric] = table[numeric].apply(pd.to_numeric, errors="coerce")
    table = table.set_index("ID")
    missing = sorted(set(ids) - set(table.index))
    if missing:
        raise ValueError(f"target IDs absent from clusters.dat: {missing}")
    target = table.loc[ids].copy()
    if not np.isfinite(target[["ra", "dec", "r50"]]).all(axis=1).all():
        raise ValueError("non-finite target coordinates or r50")
    if (target.r50 <= 0).any():
        raise ValueError("non-positive target r50")
    return target


def candidate_source_ids(path: Path) -> set[int]:
    # GaiaDR3 fixed-width bytes 35--53, retained as integers for exact mask.
    ids: set[int] = set()
    for chunk in pd.read_fwf(path, colspecs=[(34, 53)], names=["source_id"], chunksize=250_000):
        ids.update(pd.to_numeric(chunk.source_id, errors="coerce").dropna().astype("int64").tolist())
    return ids


def adql(row: pd.Series) -> str:
    ra, dec = float(row.ra), float(row.dec)
    inner, outer = 3.0 * float(row.r50), 5.0 * float(row.r50)
    return f"""SELECT source_id, ra, dec, l, b, parallax, parallax_error,
pmra, pmra_error, pmdec, pmdec_error, phot_g_mean_mag, bp_rp
FROM gaiadr3.gaia_source
WHERE CONTAINS(POINT('ICRS', ra, dec), CIRCLE('ICRS', {ra:.10f}, {dec:.10f}, {outer:.10f})) = 1
  AND CONTAINS(POINT('ICRS', ra, dec), CIRCLE('ICRS', {ra:.10f}, {dec:.10f}, {inner:.10f})) = 0
  AND phot_g_mean_mag BETWEEN 5.0 AND 21.0
  AND bp_rp BETWEEN -1.0 AND 5.0
  AND parallax IS NOT NULL AND parallax_error IS NOT NULL
  AND pmra IS NOT NULL AND pmra_error IS NOT NULL
  AND pmdec IS NOT NULL AND pmdec_error IS NOT NULL"""


def query_field(query: str, timeout: int) -> pd.DataFrame:
    response = requests.get(
        TAP_URL,
        params={"REQUEST": "doQuery", "LANG": "ADQL", "FORMAT": "csv", "QUERY": query},
        timeout=timeout,
    )
    response.raise_for_status()
    if response.text.lstrip().startswith("ERROR"):
        raise RuntimeError(response.text[:1000])
    frame = pd.read_csv(StringIO(response.text))
    if "source_id" not in frame.columns:
        raise RuntimeError(f"TAP response has unexpected columns: {frame.columns.tolist()}")
    return frame


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--freeze", type=Path, default=Path("gate1b_freeze.yaml"))
    p.add_argument("--clusters", type=Path, default=Path("hunt24/clusters.dat"))
    p.add_argument("--members", type=Path, default=Path("hunt24/members_full.dat"))
    p.add_argument("--output-dir", type=Path, default=Path("data/gate1b_gaia"))
    p.add_argument("--ids", type=int, nargs="*", help="optional subset for a service smoke test")
    p.add_argument("--timeout", type=int, default=180)
    p.add_argument("--retries", type=int, default=2)
    p.add_argument("--resume", action="store_true", help="reuse existing field_*.csv files")
    p.add_argument("--force", action="store_true")
    args = p.parse_args()
    freeze = yaml.safe_load(args.freeze.read_text())
    ids = args.ids if args.ids else list(freeze["target_ids"])
    if args.ids and any(i not in freeze["target_ids"] for i in args.ids):
        raise SystemExit("--ids must be a subset of frozen target_ids")
    targets = targets_from_catalog(args.clusters, ids)
    out = args.output_dir
    out.mkdir(parents=True, exist_ok=True)
    candidate_ids = candidate_source_ids(args.members)
    manifest = {
        "freeze_sha256": file_hash(args.freeze),
        "clusters_sha256": file_hash(args.clusters),
        "members_sha256": file_hash(args.members),
        "tap_url": TAP_URL,
        "targets": [],
        "candidate_ids_count": len(candidate_ids),
    }
    for cid, row in targets.iterrows():
        dest = out / f"field_{int(cid)}.csv"
        entry = {"ID": int(cid), "Name": str(row.get("Name", "")), "inner_deg": 3.0 * float(row.r50), "outer_deg": 5.0 * float(row.r50), "status": "pending"}
        if dest.exists() and not args.force:
            if not args.resume:
                raise SystemExit(f"{dest} exists; use --resume or --force after checking prior data")
            frame = pd.read_csv(dest)
            entry.update({"status": "resumed", "rows_after_candidate_mask": int(len(frame)), "sha256": file_hash(dest)})
            manifest["targets"].append(entry)
            print(json.dumps(entry, sort_keys=True))
            continue
        query = adql(row)
        for attempt in range(args.retries + 1):
            try:
                frame = query_field(query, args.timeout)
                # Exact post-retrieval mask of known candidate IDs; no colour or
                # kinematic information is used to decide this mask.
                frame["source_id"] = pd.to_numeric(frame["source_id"], errors="coerce").astype("Int64")
                before = len(frame)
                frame = frame[~frame.source_id.isin(candidate_ids)].copy()
                frame.to_csv(dest, index=False)
                entry.update({"status": "ok", "rows_raw": int(before), "rows_after_candidate_mask": int(len(frame)), "sha256": file_hash(dest), "attempt": attempt + 1})
                break
            except Exception as exc:  # leave a manifest trail for service failures
                entry.update({"status": "error", "error": repr(exc), "attempt": attempt + 1})
                if attempt < args.retries:
                    time.sleep(3 * (attempt + 1))
                else:
                    break
        manifest["targets"].append(entry)
        print(json.dumps(entry, sort_keys=True))
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    failed = [x for x in manifest["targets"] if x["status"] not in {"ok", "resumed"}]
    print(json.dumps({"ok": len(manifest["targets"]) - len(failed), "failed": len(failed), "output": str(out)}, indent=2))
    if failed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
