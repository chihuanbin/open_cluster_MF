#!/usr/bin/env python3
"""Compare primary and high-resolution outcome-blind orbit summaries."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--primary", type=Path, default=ROOT / "outputs/phase4/orbit_mc_summary.csv")
    ap.add_argument("--reference", type=Path, required=True)
    ap.add_argument("--out", type=Path, default=ROOT / "outputs/phase4")
    args = ap.parse_args(); args.out.mkdir(parents=True, exist_ok=True)
    a = pd.read_csv(args.primary); b = pd.read_csv(args.reference)
    d = a.merge(b, on="hunt_id", suffixes=("_primary", "_reference"), validate="one_to_one")
    rows = []
    for quantity in ["Rperi_kpc", "Rapo_kpc", "orbit_eccentricity", "zmax_kpc"]:
        x = d[f"{quantity}_50_primary"].to_numpy(float)
        y = d[f"{quantity}_50_reference"].to_numpy(float)
        if quantity == "orbit_eccentricity":
            delta = np.abs(x - y)
            metric = "absolute"
        else:
            delta = np.abs(np.log10(x / y))
            metric = "absolute_log10_ratio"
        rows.append({"quantity": quantity, "metric": metric, "n": len(delta),
                     "median": float(np.nanmedian(delta)), "p95": float(np.nanquantile(delta, 0.95)),
                     "maximum": float(np.nanmax(delta))})
    out = pd.DataFrame(rows); out.to_csv(args.out / "orbit_grid_convergence.csv", index=False)
    rp = out[out.quantity.eq("Rperi_kpc")].iloc[0]
    status = "PASS_ORBIT_GRID_CONVERGENCE" if rp["median"] < 0.02 and rp["p95"] < 0.05 else "FAIL_ORBIT_GRID_CONVERGENCE"
    report = {"status": status, "outcome_blind": True, "n_clusters": int(len(d)),
              "primary": str(args.primary), "reference": str(args.reference),
              "Rperi_gate": {"median_abs_log10_ratio_lt": 0.02, "p95_lt": 0.05}}
    (args.out / "orbit_grid_convergence.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2)); print(out.to_string(index=False))


if __name__ == "__main__":
    main()
