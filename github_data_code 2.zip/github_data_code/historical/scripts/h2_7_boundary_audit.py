#!/usr/bin/env python3
"""H2.7 audit of the smoothly-broken relation's a2 boundary."""

from __future__ import annotations

import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize

from h2_5_decomposition import load_raw_chains, log_normal
from hierarchical_mimo_summary import read_catalog


def broken_mean(tau,p):
    y0,a1,a2,x0,ls=p[:5]; s=np.exp(ls); return y0+a1*(tau-x0)+(a2-a1)*np.logaddexp(0,s*(tau-x0))/s


def fit(kind,d,chains,a2max,start):
    bounds=[(-5,1),(-5,3),(-5,a2max),(7,10.2),(np.log(.1),np.log(80)),(np.log(.005),np.log(2))]
    if kind=='point':
        tau=d.logage50.to_numpy(); alpha=d.alpha50.to_numpy(); sy=np.maximum((d.alpha84.to_numpy()-d.alpha16.to_numpy())/2,.02)
        def nll(p):
            sig=np.exp(p[-1]); z=(alpha-broken_mean(tau,p))/np.sqrt(sig*sig+sy*sy); return .5*np.sum(z*z+np.log(2*np.pi*(sig*sig+sy*sy)))
    else:
        def nll(p):
            sig=np.exp(p[-1]); return -sum(float(__import__('scipy').special.logsumexp(c['logw']+log_normal(c['alpha'],broken_mean(c['tau'],p),sig))) for c in chains)
    r=minimize(nll,start,method='Powell',bounds=bounds,options={'maxiter':700,'xtol':2e-5,'ftol':2e-5})
    return {'kind':kind,'a2_max':a2max,'y0':r.x[0],'a1':r.x[1],'a2':r.x[2],'x0':r.x[3],'s':np.exp(r.x[4]),'sigma_int':np.exp(r.x[5]),'objective':r.fun,'success':bool(r.success),'nfev':int(r.nfev)}


def main():
    p=argparse.ArgumentParser(); p.add_argument('--catalog',type=Path,default=Path('data/mimo_catalog/table3.dat')); p.add_argument('--chain-dir',type=Path,default=Path('data/mimo_chains_prime')); p.add_argument('--output-dir',type=Path,default=Path('outputs/h2_7_boundary_audit')); p.add_argument('--force',action='store_true')
    a=p.parse_args(); out=a.output_dir; out.mkdir(parents=True,exist_ok=True)
    if (out/'report.md').exists() and not a.force: raise SystemExit('Output exists; pass --force')
    d=read_catalog(a.catalog,True); chains=load_raw_chains(d,a.chain_dir); start=np.array([-2.478,-.232,3.0,8.83,np.log(5.87),np.log(.316)])
    rows=[]
    for upper in [3.0,5.0,8.0,12.0]:
        for kind in ['point','joint']:
            rows.append(fit(kind,d,chains,upper,start))
    df=pd.DataFrame(rows); df.to_csv(out/'boundary_fits.csv',index=False)
    # Compare the two highest bounds with the a2=3 baseline.
    piv=df.pivot(index='a2_max',columns='kind',values=['a2','x0','a1','sigma_int']); piv.to_csv(out/'boundary_summary.csv')
    prov={'status':'H2.7-COMPLETE-PILOT','a2_bounds':[3.0,5.0,8.0,12.0],'n_clusters':len(d),'caveat':'MAP boundary scan; full hyperposterior and reparameterized delta-a model remain pending'}
    (out/'provenance.json').write_text(json.dumps(prov,indent=2)+'\n')
    lines=['# H2.7 broken-relation boundary audit','',f'Status: **`H2.7-COMPLETE-PILOT`** on {len(d)} MF Prime clusters.','', 'The a2 upper bound was expanded from 3 to 5, 8, and 12 for both point and exact joint-chain fits.']
    for k in ['point','joint']:
        z=df[df.kind==k].sort_values('a2_max'); lines += ['',f'## {k}', '', z[['a2_max','a2','x0','a1','sigma_int','success']].to_string(index=False)]
    lines += ['', 'Interpretation: if a2 and x0 stabilize as the bound expands, the boundary is not controlling chronology. If a2 keeps increasing, its value is not identified and the final model must use a delta-a/width parameterization.']
    (out/'report.md').write_text('\n'.join(lines)+'\n')
    print(df.to_json(orient='records',indent=2))

if __name__=='__main__': main()
