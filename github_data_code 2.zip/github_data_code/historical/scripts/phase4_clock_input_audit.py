#!/usr/bin/env python3
"""Legacy pre-reconstruction audit for Phase-IV dynamical-clock inputs.

This catalogue-only audit is retained for provenance but is superseded by the
member-level D1 pipeline. Running it without external structure/orbit files can
still return DATA_BLOCKED and must not overwrite the current D0 gate decision.

This script is intentionally a data gate, not a clock-result generator.  It
cross-matches the 163 MiMO MF-Prime systems against the independent
Hunt--Reffert cluster catalogue and reports coverage of structural/mass fields
and of the separately supplied orbital table.  A dissolution/relaxation result
is emitted only when the required orbital columns are present and finite.

The script accepts a user-supplied orbital CSV so that a future Gaia/cluster
orbit product can be added without changing the frozen audit logic.  It never
uses MiMO alpha, alpha-derived mass, or MiMO candidate counts as a primary
clock input.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
MIMO_COLSPECS = [
    (0, 17), (18, 24), (25, 31), (32, 37), (38, 44), (45, 51),
    (52, 58), (59, 65), (66, 72), (73, 79), (80, 86), (87, 93),
    (94, 100), (101, 106), (107, 112), (113, 118), (119, 124),
    (125, 131), (132, 138), (139, 145), (146, 152), (153, 159),
    (160, 165), (166, 171),
]
MIMO_NAMES = [
    "cluster", "logage_best", "logage50", "logage16", "logage84",
    "feh_best", "feh50", "feh16", "feh84", "dm_best", "dm50",
    "dm16", "dm84", "av_best", "av50", "av16", "av84", "alpha_best",
    "alpha50", "alpha16", "alpha84", "avgprior", "sigprior", "MFsamp",
]

# Byte positions are taken from hunt24/ReadMe (converted to zero-based,
# half-open slices).  All fields are read as strings first so '?' remains
# auditable rather than silently becoming a numerical zero.
HUNT_SPECS = {
    "name": (0, 20), "id": (21, 25), "all_names": (26, 279), "type": (280, 281),
    "N": (294, 300), "Nt": (313, 318), "GLON": (345, 357),
    "GLAT": (358, 369), "r50pc": (418, 431), "rtpc": (446, 459),
    "dist16": (583, 598), "dist50": (599, 614), "dist84": (615, 631),
    "pmRA": (474, 487), "s_pmRA": (488, 499), "pmDE": (511, 523),
    "s_pmDE": (524, 535), "Plx": (547, 559), "s_Plx": (560, 571),
    "RV": (691, 704), "e_RV": (719, 732), "n_RV": (733, 737),
    "RAdeg": (319, 331), "DEdeg": (332, 344),
    "MassJ": (1007, 1022), "e_MassJ": (1023, 1038),
    "MassTot": (1039, 1054), "e_MassTot": (1055, 1070),
}

REQUIRED_INDEPENDENT = ["mass", "N", "r_h", "R_G", "V_G", "eccentricity"]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def key(value: object) -> str:
    """Normalise common catalogue naming variants for deterministic matching."""
    text = str(value).strip().lower()
    text = text.replace("+name_updated", "")
    return re.sub(r"[^a-z0-9]", "", text)


def read_mimo(path: Path) -> pd.DataFrame:
    d = pd.read_fwf(path, colspecs=MIMO_COLSPECS, names=MIMO_NAMES)
    for c in MIMO_NAMES[1:]:
        d[c] = pd.to_numeric(d[c], errors="coerce")
    d = d[d["MFsamp"].eq(1.0)].copy()
    if len(d) != 163:
        raise ValueError(f"Expected 163 MF-Prime rows, found {len(d)}")
    d["match_key"] = d["cluster"].map(key)
    return d.reset_index(drop=True)


def read_hunt(path: Path) -> pd.DataFrame:
    names = list(HUNT_SPECS)
    d = pd.read_fwf(path, colspecs=[HUNT_SPECS[n] for n in names], names=names, dtype=str)
    d = d.fillna("")
    for c in names:
        if c not in {"name", "all_names", "type"}:
            d[c] = pd.to_numeric(d[c].str.strip().replace({"": np.nan, "?": np.nan}), errors="coerce")
    d["match_key"] = d["name"].map(key)
    return d


def match_catalogue(mimo: pd.DataFrame, hunt: pd.DataFrame) -> pd.DataFrame:
    primary: dict[str, list[int]] = {}
    aliases: dict[str, list[int]] = {}
    for i, row in hunt.iterrows():
        k0 = key(row["name"])
        if k0:
            primary.setdefault(k0, []).append(i)
        for variant in str(row["all_names"]).split(","):
            k = key(variant)
            if k:
                aliases.setdefault(k, []).append(i)
    out = []
    for _, row in mimo.iterrows():
        # Prefer an exact primary catalogue name.  Alias collisions (for
        # example NGC/UPK/Theia cross-identifications) are not evidence of an
        # ambiguous match when the accepted name itself is unique.
        hits = sorted(set(primary.get(row["match_key"], [])))
        if not hits:
            hits = sorted(set(aliases.get(row["match_key"], [])))
        if len(hits) == 1:
            h = hunt.iloc[hits[0]]
            rec = {"cluster": row["cluster"], "hunt_name": h["name"], "match_status": "unique"}
            for c in HUNT_SPECS:
                if c not in {"name", "all_names"}:
                    rec[f"hunt_{c}"] = h[c]
        elif len(hits) == 0:
            rec = {"cluster": row["cluster"], "hunt_name": "", "match_status": "missing"}
        else:
            rec = {"cluster": row["cluster"], "hunt_name": ";".join(hunt.iloc[h]["name"] for h in hits), "match_status": "ambiguous"}
        out.append(rec)
    return pd.DataFrame(out)


def audit_orbit_table(path: Path | None) -> dict:
    required_aliases = {
        "cluster": {"cluster", "name", "id", "cluster_name"},
        "R_G": {"r_g", "rg", "galactocentric_radius", "guiding_radius"},
        "V_G": {"v_g", "vg", "galactocentric_speed", "circular_speed"},
        "eccentricity": {"eccentricity", "e", "orbital_eccentricity"},
        "pericenter": {"pericenter", "rperi", "r_peri"},
        "apocenter": {"apocenter", "rapo", "r_apo"},
    }
    if path is None:
        return {"provided": False, "path": None, "columns": [], "missing_required": list(required_aliases), "status": "DATA_BLOCKED"}
    tab = pd.read_csv(path)
    canonical = {key(c): c for c in tab.columns}
    found = {}
    for wanted, aliases in required_aliases.items():
        found[wanted] = next((canonical[key(a)] for a in aliases if key(a) in canonical), None)
    missing = [k for k, v in found.items() if v is None]
    # Eccentricity can be supplied directly or represented by pericentre and
    # apocentre.  Keep the alternative explicit so a future orbit table is not
    # rejected merely for using the latter convention.
    if found["eccentricity"] is None and found["pericenter"] and found["apocenter"]:
        missing = [k for k in missing if k != "eccentricity"]
    if found["pericenter"] and found["apocenter"]:
        missing = [k for k in missing if k not in {"pericenter", "apocenter"}]
    return {"provided": True, "path": str(path), "sha256": sha256(path), "rows": len(tab), "columns": list(tab.columns), "resolved_columns": found, "missing_required": missing, "status": "PASS" if not missing else "DATA_BLOCKED"}


def audit_structure_table(path: Path | None, n_target: int) -> dict:
    if path is None:
        return {"provided": False, "path": None, "status": "DATA_BLOCKED", "missing_required": ["cluster", "r_h"]}
    tab = pd.read_csv(path)
    canonical = {key(c): c for c in tab.columns}
    cluster_col = next((canonical[key(a)] for a in {"cluster", "name", "cluster_name", "id"} if key(a) in canonical), None)
    rh_col = next((canonical[key(a)] for a in {"r_h", "rh", "half_mass_radius", "half_mass_radius_pc"} if key(a) in canonical), None)
    missing = [name for name, value in (("cluster", cluster_col), ("r_h", rh_col)) if value is None]
    finite = int(pd.to_numeric(tab[rh_col], errors="coerce").notna().sum()) if rh_col else 0
    if rh_col and finite < n_target:
        missing.append(f"r_h finite coverage ({finite}/{n_target})")
    return {"provided": True, "path": str(path), "sha256": sha256(path), "rows": len(tab), "resolved_columns": {"cluster": cluster_col, "r_h": rh_col}, "finite_r_h": finite, "missing_required": missing, "status": "PASS" if not missing else "DATA_BLOCKED"}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mimo", type=Path, default=ROOT / "data/mimo_catalog/table3.dat")
    ap.add_argument("--hunt", type=Path, default=ROOT / "hunt24/clusters.dat")
    ap.add_argument("--orbit", type=Path, default=None, help="Independent orbit CSV; omit until supplied")
    ap.add_argument("--structure", type=Path, default=None, help="Independent half-mass-radius CSV; omit until supplied")
    ap.add_argument("--out", type=Path, default=ROOT / "outputs/phase4")
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    mimo = read_mimo(args.mimo)
    hunt = read_hunt(args.hunt)
    matched = match_catalogue(mimo, hunt)
    matched.to_csv(args.out / "clock_input_match.csv", index=False)
    orbit = audit_orbit_table(args.orbit)
    structure = audit_structure_table(args.structure, len(mimo))
    member_summary_path = args.out / "member_dynamics_provenance.json"
    member_reconstruction = None
    if member_summary_path.exists():
        try:
            member_reconstruction = json.loads(member_summary_path.read_text())
        except json.JSONDecodeError:
            member_reconstruction = {"status": "UNREADABLE"}
    numeric = [c for c in matched.columns if c.startswith("hunt_") and c not in {"hunt_name", "hunt_type"}]
    coverage = {c: int(pd.to_numeric(matched[c], errors="coerce").notna().sum()) for c in numeric}
    structural_missing = []
    if coverage.get("hunt_N", 0) < len(mimo):
        structural_missing.append("independent member count N")
    if coverage.get("hunt_MassJ", 0) == 0 and coverage.get("hunt_MassTot", 0) == 0:
        structural_missing.append("independent cluster mass")
    # r50pc in Hunt--Reffert is a half-number radius, not a half-mass radius;
    # it cannot silently be relabelled r_h for the primary relaxation clock.
    if structure["status"] != "PASS":
        structural_missing.append("half-mass radius r_h (Hunt field r50pc is half-number radius)")
    report = {
        "status": "PASS" if orbit["status"] == "PASS" and not structural_missing and matched["match_status"].eq("unique").all() else "DATA_BLOCKED",
        "scope": "Phase-IV clock-input integrity gate; no exposure result computed",
        "mimo": {"path": str(args.mimo), "sha256": sha256(args.mimo), "n_prime": len(mimo)},
        "hunt": {"path": str(args.hunt), "sha256": sha256(args.hunt), "n_rows": len(hunt)},
        "match": {"unique": int(matched["match_status"].eq("unique").sum()), "missing": int(matched["match_status"].eq("missing").sum()), "ambiguous": int(matched["match_status"].eq("ambiguous").sum())},
        "independent_hunt_field_coverage": coverage,
        "structural_input_gate": {"missing": structural_missing, "status": "PASS" if not structural_missing else "DATA_BLOCKED"},
        "required_primary_inputs": REQUIRED_INDEPENDENT,
        "orbit_audit": orbit,
        "structure_audit": structure,
        "member_reconstruction": member_reconstruction,
        "circularity_policy": "MiMO alpha and alpha-derived mass/member counts are excluded from primary clock inputs",
        "next_action": "Supply an independent half-mass radius table and a 6D orbit CSV with cluster identifier, Galactocentric radius/speed, and eccentricity or pericentre+apocentre; then rerun this gate before fitting clocks.",
    }
    (args.out / "clock_input_audit.json").write_text(json.dumps(report, indent=2) + "\n")
    lines = [
        "# Phase-IV clock-input audit",
        "",
        f"Status: **{report['status']}**.",
        "",
        f"The 163 MF-Prime systems were matched against the independent Hunt--Reffert catalogue: {report['match']['unique']} unique, {report['match']['missing']} missing, {report['match']['ambiguous']} ambiguous.",
        (f"The outcome-blind member reconstruction is {member_reconstruction.get('status')} for {member_reconstruction.get('n_ok')} systems." if member_reconstruction else "The outcome-blind member reconstruction has not yet been run."),
        "",
        "Hunt--Reffert supplies useful independent mass/structure fields (including `MassJ`, `MassTot`, `N`, `r50pc`, and `rtpc`) but `r50pc` is a half-number radius, not the half-mass radius required by the primary relaxation prescription. The catalogue also lacks the complete orbital quantities required for the primary dissolution clock. No $t_{\\rm rh}$, $t_{\\rm diss}$, ELPD, or physical-clock coefficient is computed by this audit.",
        "",
        "The gate remains **DATA_BLOCKED** until independent half-mass radii and an orbit table supply Galactocentric radius/speed and orbital eccentricity (or equivalent pericentre/apocentre information) for the matched systems. MiMO alpha and alpha-derived mass/member proxies are explicitly excluded from primary clocks.",
        "",
        "Outputs: `clock_input_match.csv` and `clock_input_audit.json`.",
    ]
    (args.out / "clock_input_audit.md").write_text("\n".join(lines) + "\n")
    print(json.dumps({"status": report["status"], "match": report["match"], "structure": structure["status"], "orbit": orbit["status"]}, indent=2))


if __name__ == "__main__":
    main()
