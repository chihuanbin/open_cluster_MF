#!/usr/bin/env python3
"""Numerical verification of the already-frozen A2 M0/M1/M2 fits.

This reports the omitted M2-versus-M0 predictive contrast and convergence
summary without changing the frozen sample, rules, or primary verdict.
"""
import hashlib, json
from pathlib import Path
import numpy as np, pandas as pd
from hierarchical_mimo_summary import read_catalog
from phase4_a2_realdata import run_model

ROOT = Path(__file__).resolve().parents[1]; OUT = ROOT / "outputs/phase4"
RULE = OUT / "A2_REALDATA_RULES.yaml"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    expected = (OUT / "A2_REALDATA_RULES.sha256").read_text().split()[0]
    if sha(RULE) != expected:
        raise SystemExit("A2 rules hash mismatch")
    d = read_catalog(ROOT / "data/mimo_catalog/table3.dat", prime_only=True)
    b = pd.read_parquet(OUT / "CLOCK_FREEZE_B.parquet")
    d = d.merge(b[["cluster", "log_age_50", "eta_diss_50"]], on="cluster", validate="one_to_one").dropna()
    x = d.log_age_50.to_numpy(float); z0 = d.eta_diss_50.to_numpy(float)
    A = np.column_stack([np.ones(len(x)), x-x.mean(), (x-x.mean())**2])
    z = z0 - A @ np.linalg.lstsq(A, z0, rcond=None)[0]; z /= z.std(ddof=1)
    y = d.alpha50.to_numpy(float); sy = np.maximum((d.alpha84-d.alpha16).to_numpy(float)/2, .02)
    fits = {k: run_model(x, y, sy, z, k) for k in ["M0", "M1", "M2"]}
    el = {k: float(np.sum(v["elpd"])) for k, v in fits.items()}
    g = fits["M1"]["draws"][:, 5]
    out = {
        "status": "A2_M2_NUMERICAL_VERIFICATION",
        "rules_sha256": sha(RULE), "n_clusters": len(d),
        "elpd_sum": el,
        "delta_ELPD_M1_minus_M0": el["M1"] - el["M0"],
        "delta_ELPD_M2_minus_M0": el["M2"] - el["M0"],
        "M1_gamma_95": [float(np.quantile(g, .025)), float(np.quantile(g, .975))],
        "rhat_proxy": {k: float(v["rhat_proxy"]) for k, v in fits.items()},
        "acceptance": {k: float(v["acceptance"]) for k, v in fits.items()},
        "note": "Existing frozen M0/M1/M2 pipeline; numerical reporting only. No clock, sample, rule, or primary verdict change."
    }
    (OUT / "A2_M2_COMPARISON.json").write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps(out, indent=2))

if __name__ == "__main__":
    main()
