"""Frozen smooth-transition parameterization and weighted projection family."""
import numpy as np

def mean(x,p):
    w=np.exp(p[...,4,None]); z=(x-p[...,3,None])/w
    return p[...,0,None]+p[...,1,None]*(x-p[...,3,None])+p[...,2,None]*w*np.logaddexp(0,z)

def derivative(x,p):
    from scipy.special import expit
    return p[...,1]+p[...,2]*expit((x-p[...,3])/np.exp(p[...,4]))

class Model:
    def __init__(self,df,rules,treatment,kappa=None):
        self.x=df.logage50.to_numpy(); self.y=df.alpha50.to_numpy()
        self.sy=np.maximum((df.alpha84.to_numpy()-df.alpha16.to_numpy())/2,.02)
        self.kind=treatment; self.kappa=kappa
        pars=rules['transition_model']
        self.bounds=np.asarray(list(pars['bounds'].values()))
        self.priors=np.asarray(list(pars['gaussian_prior_scales'].values()))
        self.shape=np.ones_like(self.sy) if kappa is None else (self.sy/np.exp(np.mean(np.log(self.sy))))**(2*kappa)

    def pointwise(self,p):
        p=np.asarray(p); sig=np.exp(p[...,5,None])
        v=self.sy**2+sig**2 if self.kind=='pointRE' else sig**2*self.shape
        return -.5*((self.y-mean(self.x,p))**2/v+np.log(2*np.pi*v))

    def logprob(self,p):
        p=np.atleast_2d(p)
        ok=np.all((p>self.bounds[:,0])&(p<self.bounds[:,1]),axis=1)
        lp=np.full(len(p),-np.inf)
        q=p[ok]
        lp[ok]=self.pointwise(q).sum(axis=1)-.5*np.sum(((q-self.priors[:,0])/self.priors[:,1])**2,axis=1)
        return lp
