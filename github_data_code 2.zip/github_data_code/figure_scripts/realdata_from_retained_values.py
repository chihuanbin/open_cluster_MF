"""Post-outcome visualizations of existing observations and calibrated M0 replay.

Contract: show the 156-cluster age--MF relation and its age residuals without
introducing a decision statistic. Quantitative grid, Python, 183 mm wide,
editable vector PDF/SVG and 300 dpi previews, no fabricated posterior bands.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
HERE=Path(__file__).resolve().parent
OUT=HERE.parent/'generated'; OUT.mkdir(exist_ok=True); DATA=HERE.parent/'accepted_diagnostics'
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','Helvetica','DejaVu Sans'],'font.size':9,'pdf.fonttype':42,
                     'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'legend.frameon':False})
def save(fig,name):
    fig.savefig(OUT/f'{name}.pdf',bbox_inches='tight')
    fig.savefig(OUT/f'{name}.svg',bbox_inches='tight')
    fig.savefig(OUT/f'{name}.png',dpi=600,bbox_inches='tight')
    plt.close(fig)

d=pd.read_csv(DATA/'realdata_visualization.csv')
c=np.load(DATA/'calibration_replay_M0.npz')
xx,ww=float(c['xx']),float(c['ww']);beta=c['beta']
def mu(t): return np.column_stack([np.ones(len(t)),t-xx,ww*np.logaddexp(0,(t-xx)/ww)])@beta
fig,axs=plt.subplots(1,2,figsize=(7.2,3.1),layout='constrained')
for ax in axs:
    ax.grid(alpha=.12)
axs[0].errorbar(d.log_age_50,d.alpha50,yerr=np.vstack([d.alpha50-d.alpha16,d.alpha84-d.alpha50]),
                fmt='none',ecolor='.7',elinewidth=.5,zorder=1)
sc=axs[0].scatter(d.log_age_50,d.alpha50,c=d.z_diss,cmap='cividis',s=15,zorder=2,linewidths=.2,edgecolors='.3')
tt=np.linspace(d.log_age_50.min(),d.log_age_50.max(),300)
axs[0].plot(tt,mu(tt),color='#944537',lw=1.7,label='Calibration M0 replay')
axs[0].set(xlabel=r'$\log_{10}(t_{\rm age}/{\rm yr})$',ylabel=r'Global MF slope $\alpha$')
axs[0].legend(fontsize=8,loc='upper left')
axs[1].scatter(d.z_diss,d.alpha50-d.mu_cal_M0,c=d.z_diss,cmap='cividis',s=15,edgecolors='.3',linewidths=.2)
zz=np.array([d.z_diss.min(),d.z_diss.max()])
axs[1].axhline(0,color='.5',lw=.8)
axs[1].plot(zz,.0613432892396054*zz,color='#944537',ls='--',label=r'Retained $\gamma_d z_{\rm diss}$ reference')
axs[1].set(xlabel=r'Age-residualized coordinate $z_{\rm diss}$',ylabel=r'$\alpha-\mu_{M0}$')
axs[1].legend(fontsize=8,loc='upper left')
cb=fig.colorbar(sc,ax=axs,shrink=.8,pad=.025);cb.set_label(r'$z_{\rm diss}$ (predictor SD)',fontsize=8)
for label,ax in zip(['a','b'],axs): ax.text(-.08,1.03,label,transform=ax.transAxes,fontweight='bold',va='bottom')
save(fig,'fig3_realdata_science')
