"""Deterministic AJ presentation of accepted facts; no fitting or sampling."""
from pathlib import Path
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
mpl.rcParams.update({"font.family":"sans-serif", "font.sans-serif":["DejaVu Sans"], "font.size":10, "pdf.fonttype":42, "svg.fonttype":"none", "axes.spines.top":False, "axes.spines.right":False})
out=Path(__file__).resolve().parent.parent/'generated'
out.mkdir(exist_ok=True)
def save(fig,name):
 fig.savefig(out/f'{name}.pdf',bbox_inches='tight',facecolor='white')
 fig.savefig(out/f'{name}.svg',bbox_inches='tight',facecolor='white')
 fig.savefig(out/f'{name}.png',dpi=300,bbox_inches='tight',facecolor='white')
 plt.close(fig)
# Figure contract: hypothesis -> independent observables -> conditional inference.
# Schematic-led, 7.2 inch width; no numerical or uncertainty estimation.
fig,ax=plt.subplots(figsize=(7.2,6.1)); ax.set(xlim=(0,1),ylim=(0,1)); ax.axis('off')
steps=[
 ('Observed phenomenon','Gaia open-cluster global MF-age turnover'),
 ('Physical prediction','At fixed age, stronger present-day dissolution processing\nshould correspond to a flatter global mass function'),
 ('Independent dynamical reconstruction','Gaia / Hunt-Reffert members, N, half-mass radius,\nvelocities, and Galactic environment'),
 ('Conditional coordinate','Remove the age trend from the present-day\ndissolution proxy; normalize its residual'),
 ('Prospectively frozen test','Compare age-only and age-plus-dissolution models'),
 ('Bounded inference','Present-day snapshot not established\nas an additional organizing coordinate')]
ys=[.90,.745,.59,.435,.28,.125]
for i,((heading,body),y) in enumerate(zip(steps,ys)):
 ax.add_patch(FancyBboxPatch((.035,y-.059),.93,.123,boxstyle='round,pad=0.006',linewidth=.8,edgecolor='#4b6978',facecolor='#edf3f5' if i in [1,5] else '#f8fafb'))
 ax.text(.5,y+.030,heading,ha='center',va='center',weight='bold',fontsize=11,color='#254e62')
 ax.text(.5,y-.017,body,ha='center',va='center',fontsize=10,linespacing=1.2)
 if i<5: ax.annotate('',xy=(.5,ys[i+1]+.068),xytext=(.5,y-.064),arrowprops={'arrowstyle':'->','color':'#4b6978','lw':1})
ax.text(.5,.002,'Local ordering: predictor-only check → second-stage rule freeze → MF comparison',ha='center',fontsize=8.5,color='#555555')
save(fig,'fig1_provenance_flow')
# Figure contract: native coefficient is descriptive; three-state decision logic.
# Quantitative interval plus scientific labels; no predictive contrast axis.
fig=plt.figure(figsize=(7.2,3.35)); gs=fig.add_gridspec(1,2,width_ratios=[1,1.45],wspace=.37)
ax=fig.add_subplot(gs[0]); ax.set_title('Retained conditional direction',fontsize=11,loc='left')
ax.axvline(0,color='#999999',lw=1)
ax.errorbar([.0613],[.6],xerr=[[.0613-.0294],[.0913-.0613]],fmt='o',color='#24617d',capsize=4,lw=2)
ax.set(xlim=(-.018,.115),ylim=(0,1),yticks=[])
ax.set_xlabel('MF-slope units\nper predictor SD',fontsize=9)
ax.text(.0613,.79,'0.0613',ha='center',fontsize=11)
ax.text(.5,.07,'16–84%: 0.0294–0.0913',transform=ax.transAxes,ha='center',fontsize=9)
ax.text(.5,.27,'Positive = flatter global MF',transform=ax.transAxes,ha='center',fontsize=9)
ax=fig.add_subplot(gs[1]); ax.axis('off'); ax.set_title('Frozen establishment rule',fontsize=11,loc='left')
rows=[('Directional evidence','NOT MET','P(positive) = 0.97469; required > 0.975'),('Predictive component','NOT ADJUDICABLE','No valid common calibrated decision scale'),('Standardized effect','NOT EVALUABLE','Authoritative outcome scale not retained'),('Frozen conjunction','DID NOT PASS','All three components were required')]
for y,(name,status,note) in zip([.88,.64,.40,.16],rows):
 ax.text(0,y,name,fontsize=10,weight='bold'); ax.text(0,y-.075,status,fontsize=10,color='#254e62'); ax.text(0,y-.14,note,fontsize=8.5,color='#555555')
save(fig,'fig5_a2_realdata')
