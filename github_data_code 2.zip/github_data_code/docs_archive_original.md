# Reproducibility materials for the Gaia open-cluster MF turnover test

This deposit-ready package separates retained evidence, historical executable code, and deterministic presentation. It has not been published; no repository URL or DOI is claimed. No raw Gaia source catalogue, HR24 member archive, MiMO chain download, journal PDF or credential is bundled. Author code is supplied for review; the author should select its redistribution licence before public deposition. Historical identifiers in immutable rule/provenance files are retained to preserve hashes and are not manuscript text.

## Safe deterministic reproduction
Use Python with matplotlib and numpy/pandas where needed. Recorded original package versions are in environment/; those are historical, not proof that the original random state can be recovered.
1. Verify `MANIFEST.sha256` using `shasum -a 256 -c MANIFEST.sha256` from this directory.
2. Run `python verify_accepted_results.py` to check retained summaries against their existing display values and classify the frozen rule. It reads retained products; it performs no fitting, sampling, LOO or calibration.
3. Run `MPLCONFIGDIR=/tmp/mf_plot_cache python figure_scripts/redesign_story.py` to regenerate the science schematic and decision figure solely from accepted constants. Output appears next to the script. Compare with accepted_figures/.
4. Other accepted figure PDFs are byte-identical frozen presentation assets. Historical plotting source is supplied where available. **Do not run all historical scripts as a build pipeline.** Several perform primary fitting, orbit integration or calibration. Exact rendering of Figure 3 can use accepted_diagnostics/realdata_visualization.csv and the stored calibration_replay_M0.npz, evaluating its fixed coefficients only; no re-fitting is needed. A dedicated safe script is supplied in figure_scripts/.
5. The separate source-only submission package is compiled with `latexmk -pdf main.tex` and `latexmk -pdf supplement.tex`. Copy all package assets together; scientific data are not build dependencies.

## Inputs and retrieval
MiMO: Li & Shao 2022, DOI 10.3847/1538-4357/ac5f4f; Li et al. 2025, DOI 10.3847/1538-3881/ae0cb6, CDS catalogue https://cdsarc.cds.unistra.fr/viz-bin/ReadMe/J/AJ/170/288 and the China-VO PaperData link specified there. Retrieve original catalogue and posterior products from their cited services, retaining upstream version and licences. The MF-Prime definition is described in Li et al. 2026, DOI 10.3847/2041-8213/ae78cc.
HR24: DOI 10.1051/0004-6361/202348662; CDS https://cdsarc.cds.unistra.fr/ftp/J/A+A/686/A42/ReadMe. Retrieve required member products through the article/data links and preserve their attribution and redistribution terms. Gaia DR3: DOI 10.1051/0004-6361/202243940; archive https://gea.esac.esa.int/archive/. No retrieval, fresh selection or orbital re-analysis was performed in manuscript preparation.

Derived clock tables and accepted scalar diagnostics are bundled. Paired exposure/orbit arrays and original MiMO chains are not all bundled; historical primary scripts need those upstream products and original workspace paths. They are documentation, not a claim of one-command exact scientific replay. Original formal dissolution posterior draws/pointwise arrays were not retained; exact replay and convergence assessment of that calculation are impossible from this archive.

## Inferential boundaries
Turnover values 8.9545 / 8.9551 remain primary; influence range and first deletion bound invariance. Directional probability 0.97469 does not meet >0.975; predictive NOT ADJUDICABLE; standardized effect NOT EVALUABLE; conjunction DID NOT PASS. Corrected 1.396974 and historical threshold 1.0245 have no common calibrated decision scale. No predictive contrast is primary evidence. Local logs/hashes provide no externally trusted timestamp. Post-outcome products are in accepted_diagnostics and explicitly described in the manuscript.
