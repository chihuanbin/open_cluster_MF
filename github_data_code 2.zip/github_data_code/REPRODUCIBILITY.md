# Reproduction scope and historical-label warning

## Executable without new science

`verify_manifest.py` checks SHA-256 integrity. `verify_accepted_results.py` checks retained native coefficient values and current classifications. The two scripts in `figure_scripts/` regenerate schematic/decision figures and the descriptive real-data figure from existing accepted constants and tables. No posterior fitting, selection, orbit integration, LOO, PSIS or calibration is invoked.

Other accepted figures are supplied as original assets; their historical plotting source may depend on unbundled inputs. This package does not promise a complete one-command replay of primary analyses.

## Immutable history versus final interpretation

The `historical/` files and their identifiers retain original bytes. In particular, `A2_REALDATA_RESULTS.json` contains an obsolete `standardized_effect_gamma_star` label: the stored number is a native alpha coefficient per predictor SD, not a recovered standardized effect. Its old `primary_pass` field does not describe the separate present-day adjudication statuses. Consult `accepted_results.json` for **directional NOT MET, predictive NOT ADJUDICABLE, standardized effect NOT EVALUABLE, conjunction DID NOT PASS**. Unresolved components are not failures.

Historical predictive values are not primary evidence. The corrected post-outcome fixed-draw statistic 1.396974 and historical threshold 1.0245 are on different calibrated decision scales. Their numerical inequality has NO decision-theoretic interpretation. The archived formal PSIS value -4.237 does not establish lack of predictive utility.

The single-deletion influence criterion was exceeded (0.0727 dex against 0.0485 dex). This establishes sensitivity under that criterion, not disappearance or single-cluster causation of the turnover.

## Missing inputs and provenance limits

Raw Gaia/HR24 members, full MiMO chains, paired exposure/orbit draws and other large upstream inputs are not all bundled. The original formal real-data posterior and pointwise likelihood arrays were not retained: exact replay and original chain convergence assessment cannot be recovered from scalar summaries. Local hashes/logs support local ordering but do not supply a trusted external timestamp. The recorded environment is a diagnostic environment, not proof of the original runtime.

Historical code includes primary analyses and workspace-specific paths. It is archived for inspection, not executed by the safe entry points. Packaging changes only deterministic figure output destinations and repository documentation; historical products are not rewritten.
