# Author action before public distribution

No open-source or data licence has been selected on the author's behalf. Before public upload, the rights holder must choose licences for author-owned code and derived data and confirm applicable upstream terms. Existing third-party rights remain in force. Public visibility alone does not grant permission to reuse or redistribute code. No raw third-party catalogue has been added to this package.
