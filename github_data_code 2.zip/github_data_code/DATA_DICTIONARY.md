# Key products

`accepted_results.json` records publication display precision, not newly calculated estimates. Native alpha per predictor SD is distinct from the unavailable standardized effect scale.

## accepted_diagnostics/realdata_visualization.csv

156 retained clusters; a descriptive post-outcome plotting table.

| Column | Meaning |
|---|---|
| cluster | Catalogue cluster identifier |
| log_age_50 | Median log10 age in years |
| alpha50 | Median global MF slope, with dN/dm proportional to m^alpha |
| alpha16, alpha84 | Retained 16th and 84th percentile MF slopes |
| z_diss | Age-residualized present-day dissolution coordinate, predictor SD units |
| alpha_sigma | Retained MF uncertainty summary used by the diagnostic |
| mu_cal_M0 | Retained age-only calibration-model reference, not a new fit |

`calibration_replay_M0.npz`: retained calibration material; the safe figure script reads only `xx`, `ww`, `beta`. These define the existing age-model curve; the file is not a formal real-data posterior archive.

## Other retained products

- `selection_covariates.csv`, `excluded_predictor_covariates.csv`, `selection_ranges.csv`: descriptive inclusion/exclusion covariates and ranges for the dynamical-match selection, not a survey selection function.
- `predictor_uncertainty_summary.json`, `engine_diagnostics.json`: retained secondary audits, not primary establishment evidence.
- `historical/outputs/phase4/CLOCK_FREEZE_A.parquet` and `CLOCK_FREEZE_B.parquet`: frozen predictor products at different provenance points; column names and associated rule/configuration files preserve original definitions.
- `historical/outputs/h2_6_weighting_audit/`: original weighting comparisons and diagnostics with original headers.
- `historical/outputs/phase3/`: retained population summaries and diagnostics with original headers.
- `historical/influence/`: frozen influence rules, retained deletion descriptors and stopping decision.

Historical tables are documented by their corresponding source code and frozen rules; do not infer new units or redefine fields from filenames. `REPRODUCIBILITY.md` identifies obsolete historical inference labels.
