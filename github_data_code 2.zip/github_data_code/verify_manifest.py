from pathlib import Path
import hashlib
r=Path(__file__).resolve().parent
for line in (r/'MANIFEST.sha256').read_text().splitlines():
    digest, name=line.split('  ',1)
    p=r/name
    assert p.is_file(), f'Missing: {name}'
    assert hashlib.sha256(p.read_bytes()).hexdigest()==digest, f'Changed: {name}'
print('All packaged files match MANIFEST.sha256.')
