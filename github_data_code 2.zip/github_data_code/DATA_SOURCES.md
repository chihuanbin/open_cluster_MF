# Data sources and retrieval

No raw catalogue download or credentials are included. Retrieve published inputs through the cited products, retain their versions, and follow upstream access and redistribution terms.

| Product | Authoritative reference / retrieval |
|---|---|
| MiMO method | https://doi.org/10.3847/1538-4357/ac5f4f |
| MiMO catalogue | https://doi.org/10.3847/1538-3881/ae0cb6 ; https://cdsarc.cds.unistra.fr/viz-bin/ReadMe/J/AJ/170/288 (also links to ChinaVO) |
| MF-Prime / published MF-age analysis | https://doi.org/10.3847/2041-8213/ae78cc |
| Hunt & Reffert 2024 catalogue | https://doi.org/10.1051/0004-6361/202348662 ; https://cdsarc.cds.unistra.fr/ftp/J/A+A/686/A42/ReadMe |
| Gaia DR3 | https://doi.org/10.1051/0004-6361/202243940 ; https://gea.esac.esa.int/archive/ |

Bundled CSV/parquet tables are retained derived analysis products, not an independently complete Galactic open-cluster census. Retrieval alone cannot restore the lost formal-posterior arrays. No new input selection, completeness correction or replication was performed during packaging.
